"""Independent native adapter checks on the root-owned synthetic cluster only."""
from __future__ import annotations

import hashlib
import json
import platform
import subprocess
import sys
import time
import traceback
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path
from threading import Barrier
from uuid import uuid4

import psycopg
from psycopg import sql

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from reconforge.domain.hcm_leave import HCMLeaveError, LeaveEntitlementBalance, LeaveRequest, approve_leave_request
from reconforge.infrastructure.postgres import set_local_tenant_scope
from reconforge.infrastructure.postgres_hcm_leave import POSTGRES_HCM_LEAVE_SCHEMA_SQL, PostgresHCMLeaveRepository

OUT = ROOT / "output/engineering-assurance-20261025-agent-b"
OUT.mkdir(parents=True, exist_ok=True)
STAMP = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
DB = "rf_hcm_assurance_" + uuid4().hex[:12]
ROLE = "rf_hcm_app_" + uuid4().hex[:12]
BASE = {"host": "127.0.0.1", "port": 55439, "connect_timeout": 5}
FILES = ("reconforge/domain/hcm_leave.py", "reconforge/infrastructure/postgres_hcm_leave.py")

def hashes():
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in FILES}

def admin(db=DB, **kwargs):
    return psycopg.connect(**BASE, dbname=db, user="assurance_admin", **kwargs)

def app():
    return psycopg.connect(**BASE, dbname=DB, user=ROLE, options="-c statement_timeout=5000 -c lock_timeout=5000")

def request(req, employee, days):
    return LeaveRequest(req, employee, "alice", "Annual", "2026-12-01", "2026-12-04", days, "Submitted", "Synthetic assurance")

def snapshot(req, employee):
    with admin() as connection:
        return {
            "request": list(connection.execute("SELECT * FROM reconforge.hcm_leave_requests WHERE tenant_id='tenant-a' AND request_id=%s", (req,)).fetchone()),
            "balance": list(connection.execute("SELECT * FROM reconforge.hcm_leave_entitlement_balances WHERE tenant_id='tenant-a' AND employee_id=%s", (employee,)).fetchone()),
        }

report = {
    "kind": "independent_native_hcm_adapter_contract", "synthetic": True,
    "qualification_limit": "HCM constant explicitly installed; not Alembic deployment, API end-to-end, whole-platform, or production qualification.",
    "git_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
    "source_files_before": hashes(), "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "started_at": datetime.now(UTC).isoformat(), "python": sys.version,
    "platform": platform.platform(), "checks": {}, "owned_database": DB, "owned_role": ROLE,
}
started = time.perf_counter()
created_db = created_role = False
passed = False
try:
    with admin("postgres", autocommit=True) as connection:
        connection.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(DB)))
        created_db = True
        connection.execute(sql.SQL("CREATE ROLE {} LOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE NOREPLICATION NOINHERIT").format(sql.Identifier(ROLE)))
        created_role = True
    with admin() as connection:
        report["postgres_version"] = connection.execute("SELECT version()").fetchone()[0]
        connection.execute("CREATE SCHEMA reconforge")
        connection.execute(POSTGRES_HCM_LEAVE_SCHEMA_SQL)
        connection.execute(sql.SQL("GRANT USAGE ON SCHEMA reconforge TO {}").format(sql.Identifier(ROLE)))
        connection.execute(sql.SQL("GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA reconforge TO {}").format(sql.Identifier(ROLE)))
        flags = connection.execute("SELECT relname,relrowsecurity,relforcerowsecurity FROM pg_class WHERE relnamespace='reconforge'::regnamespace AND relkind='r' ORDER BY relname").fetchall()
        assert len(flags) == 2 and all(row[1:] == (True, True) for row in flags)
        report["checks"]["force_rls_catalog"] = flags
    with app() as connection:
        role_flags = connection.execute("SELECT rolsuper,rolbypassrls,rolcreatedb,rolcreaterole,rolreplication FROM pg_roles WHERE rolname=current_user").fetchone()
        assert role_flags == (False,) * 5
        report["checks"]["restricted_role"] = list(role_flags)
        connection.rollback()
        repo = PostgresHCMLeaveRepository(connection, "tenant-a")
        for employee, available in (("rollback", 10), ("concurrent", 5)):
            repo.save_balance("ws", LeaveEntitlementBalance(employee, "Annual", 30, available, 0))
        for leave in (request("ROLLBACK", "rollback", 4), request("A", "concurrent", 4), request("B", "concurrent", 4)):
            repo.save_request("ws", leave, create_only=True)
        foreign = PostgresHCMLeaveRepository(connection, "tenant-b")
        foreign.save_balance("ws", LeaveEntitlementBalance("foreign", "Annual", 30, 10, 0))
        foreign.save_request("ws", request("FOREIGN", "foreign", 3), create_only=True)

    before = snapshot("ROLLBACK", "rollback")
    with admin() as connection:
        connection.execute("""CREATE FUNCTION reconforge.fail_balance_test() RETURNS trigger LANGUAGE plpgsql AS $$
            BEGIN IF NEW.employee_id='rollback' THEN RAISE EXCEPTION 'synthetic balance failure'; END IF; RETURN NEW; END $$;
            CREATE TRIGGER fail_balance_test BEFORE UPDATE ON reconforge.hcm_leave_entitlement_balances
            FOR EACH ROW EXECUTE FUNCTION reconforge.fail_balance_test();""")
    connection = app()
    repo = PostgresHCMLeaveRepository(connection, "tenant-a")
    try:
        try:
            with repo.mutation():
                leave = repo.get_request("ws", "ROLLBACK")
                balance = repo.get_balance("ws", "rollback", "Annual")
                approved, updated = approve_leave_request(leave, balance, "manager")
                repo.save_request("ws", approved)
                repo.save_balance("ws", updated)
            raise AssertionError("Injected second-write failure did not fail")
        except psycopg.errors.RaiseException as error:
            assert str(error).startswith("synthetic balance failure")
            report["checks"]["second_write_failure_sqlstate"] = error.sqlstate
    finally:
        repo.close()
    after = snapshot("ROLLBACK", "rollback")
    assert before == after
    report["checks"]["second_write_rollback"] = {"before": before, "after": after, "unchanged": True}

    connection = app()
    repo = PostgresHCMLeaveRepository(connection, "tenant-a")
    try:
        try:
            repo.save_request("ws", replace(request("ROLLBACK", "rollback", 4), employee_user_id="forged", status="Draft"), create_only=True)
            raise AssertionError("Duplicate create-only request succeeded")
        except HCMLeaveError as error:
            assert error.code == "leave_request_exists"
            report["checks"]["duplicate_create_only"] = error.code
    finally:
        repo.close()
    assert snapshot("ROLLBACK", "rollback") == before

    barrier = Barrier(2)
    def approve(req):
        connection = app()
        repo = PostgresHCMLeaveRepository(connection, "tenant-a")
        barrier.wait(timeout=5)
        try:
            with repo.mutation():
                leave = repo.get_request("ws", req)
                balance = repo.get_balance("ws", "concurrent", "Annual")
                approved, updated = approve_leave_request(leave, balance, "manager")
                repo.save_request("ws", approved)
                repo.save_balance("ws", updated)
            return {"request": req, "result": "approved"}
        except HCMLeaveError as error:
            return {"request": req, "result": error.code}
        finally:
            repo.close()
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(approve, ("A", "B")))
    assert sorted(row["result"] for row in results) == ["approved", "leave_insufficient_balance"]
    with admin() as connection:
        consumed = connection.execute("SELECT consumed_days FROM reconforge.hcm_leave_entitlement_balances WHERE tenant_id='tenant-a' AND employee_id='concurrent'").fetchone()[0]
        statuses = connection.execute("SELECT request_id,status FROM reconforge.hcm_leave_requests WHERE tenant_id='tenant-a' AND request_id IN ('A','B') ORDER BY request_id").fetchall()
    assert consumed == 4 and sorted(row[1] for row in statuses) == ["Approved", "Submitted"]
    report["checks"]["concurrent_approvals"] = {"workers": 2, "available_days": 5, "requested_days_each": 4, "results": results, "consumed_days": consumed, "statuses": statuses}

    with app() as connection:
        with connection.transaction():
            set_local_tenant_scope(connection, "tenant-a")
            assert connection.execute("SELECT request_id FROM reconforge.hcm_leave_requests WHERE tenant_id='tenant-b'").fetchall() == []
            assert connection.execute("UPDATE reconforge.hcm_leave_requests SET status='Cancelled' WHERE tenant_id='tenant-b'").rowcount == 0
            assert connection.execute("DELETE FROM reconforge.hcm_leave_requests WHERE tenant_id='tenant-b'").rowcount == 0
            try:
                with connection.transaction():
                    connection.execute("INSERT INTO reconforge.hcm_leave_entitlement_balances VALUES ('tenant-b','ws','FORGED','Annual',30,10,0,now())")
                raise AssertionError("Forged tenant insert succeeded")
            except psycopg.errors.InsufficientPrivilege as error:
                assert error.sqlstate == "42501"
        report["checks"]["tenant_boundary"] = {"cross_tenant_select": 0, "cross_tenant_update": 0, "cross_tenant_delete": 0, "forged_insert_sqlstate": "42501"}
    report["source_files_after"] = hashes()
    assert report["source_files_before"] == report["source_files_after"], "Tested HCM files changed during native verification"
    passed = True
except BaseException:
    report["error"] = traceback.format_exc()
    traceback.print_exc()
finally:
    try:
        with admin("postgres", autocommit=True) as connection:
            if created_db:
                connection.execute(sql.SQL("DROP DATABASE {} WITH (FORCE)").format(sql.Identifier(DB)))
            if created_role:
                connection.execute(sql.SQL("DROP ROLE {}").format(sql.Identifier(ROLE)))
            assert connection.execute("SELECT 1 FROM pg_database WHERE datname=%s", (DB,)).fetchone() is None
            assert connection.execute("SELECT 1 FROM pg_roles WHERE rolname=%s", (ROLE,)).fetchone() is None
        report["cleanup"] = "Only generated test-owned database/role removed; root cluster retained."
    except BaseException:
        passed = False
        report["cleanup_error"] = traceback.format_exc()
    report["passed"] = passed
    report["elapsed_seconds"] = time.perf_counter() - started
    report["completed_at"] = datetime.now(UTC).isoformat()
    target = OUT / f"hcm-native-{STAMP}.json"
    target.write_text(json.dumps(report, indent=2, default=str) + "\n", encoding="utf-8")
    print(json.dumps({"passed": passed, "report": str(target), "elapsed_seconds": report["elapsed_seconds"], "checks": list(report["checks"])}, indent=2))
sys.exit(0 if passed else 1)
