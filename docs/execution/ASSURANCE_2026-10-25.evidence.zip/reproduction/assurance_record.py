"""Capture local command evidence without converting missing prerequisites to passes."""
from __future__ import annotations

import hashlib
import json
import platform
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path('F:/reconforge-erp')
OUT = ROOT / 'output/assurance-20261025'
OUT.mkdir(parents=True, exist_ok=True)


def fingerprint() -> str:
    paths = subprocess.check_output(['git', 'ls-files', '-co', '--exclude-standard', '-z', '--',
        'reconforge', 'tests', 'alembic', 'apps/web/src', 'apps/web/e2e', '.github',
        'pyproject.toml', 'uv.lock', 'apps/web/package.json', 'apps/web/package-lock.json',
        'Dockerfile'], cwd=ROOT).split(b'\0')
    digest = hashlib.sha256()
    for name in sorted(set(filter(None, paths))):
        path = ROOT / name.decode('utf-8')
        digest.update(name + b'\0')
        digest.update(hashlib.sha256(path.read_bytes()).digest() if path.is_file() else b'MISSING')
    return digest.hexdigest()


name, *command = sys.argv[1:]
if command[:1] == ['--']:
    command = command[1:]
before = fingerprint()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
started_at = datetime.now(UTC).isoformat()
started = time.monotonic()
log = OUT / (name + '.log')
with log.open('w', encoding='utf-8') as stream:
    try:
        run = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, check=False)
        exit_code = run.returncode
    except OSError as exc:
        stream.write(str(exc))
        exit_code = None
after = fingerprint()
record = dict(name=name, command=command, source_commit=head, source_digest_before=before,
    source_digest_after=after, source_unchanged=before == after, started_at=started_at,
    duration_seconds=round(time.monotonic() - started, 3), exit_code=exit_code,
    platform=platform.platform(), python=sys.version, log=log.relative_to(ROOT).as_posix(),
    log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
(OUT / (name + '.json')).write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record, indent=2))
print('\n'.join(log.read_text(encoding='utf-8', errors='replace').splitlines()[-16:]))
raise SystemExit(exit_code if exit_code is not None else 127)
