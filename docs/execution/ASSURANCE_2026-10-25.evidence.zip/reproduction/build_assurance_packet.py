"""Retain bounded assurance evidence, including negative and environment outcomes."""
from __future__ import annotations

import hashlib
import json
import re
import subprocess
import zipfile
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path('F:/reconforge-erp')
OUT = ROOT / 'output/assurance-20261025'
DOCS = ROOT / 'docs/execution'
BASE = '7af61cddb1fc96a3f5f348257c772206171572c1'


def git(*args: str) -> str:
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


source_roots = ['reconforge', 'tests', 'apps/web', '.github', 'alembic', 'pyproject.toml', 'uv.lock', 'Dockerfile']
runtime_diff = git('diff', '--name-only', 'HEAD', '--', *source_roots)
untracked = git('ls-files', '--others', '--exclude-standard', '--', *source_roots)
assert not runtime_diff and not untracked, 'Runtime/test sources must be committed before sealing.'
code_commit = git('rev-parse', 'HEAD')
changed = git('diff', '--name-only', BASE, 'HEAD', '--', *source_roots).splitlines()
files = {name: digest((ROOT / name).read_bytes()) for name in changed}
web_paths = git('ls-files', '--', 'apps/web/src', 'apps/web/e2e', 'apps/web/package.json', 'apps/web/package-lock.json').splitlines()
web_hashes = {name: digest((ROOT / name).read_bytes()) for name in web_paths}
inputs: dict[str, Path] = {}
for source in [OUT, ROOT / 'output/engineering-assurance-20261025-agent-b']:
    for path in source.rglob('*'):
        relative = path.relative_to(source)
        if any(part in {'data', 'baseline-demo', 'generated-root-vitest-cache'} for part in relative.parts):
            continue
        if path.is_file() and path.suffix.lower() in {'.log', '.json', '.xml', '.txt'}:
            inputs[path.relative_to(ROOT).as_posix()] = path
for name in ['assurance_record.py', 'assurance_hcm_native.py', 'build_assurance_packet.py']:
    path = ROOT / '.tmp' / name
    if path.exists():
        inputs['reproduction/' + name] = path

capsule = DOCS / 'ASSURANCE_2026-10-25.evidence.zip'
entries = []
with zipfile.ZipFile(capsule, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, path in sorted(inputs.items()):
        raw = path.read_bytes()
        # Preserve originals locally. Expiring public-image CDN bearer queries
        # are unnecessary for review and are redacted only in the public copy.
        public = re.sub(rb'([?&](?:Signature|Key-Pair-Id|Expires)=)[^&\s\"\'<>]+', rb'\1REDACTED', raw)
        archive.writestr(name, public)
        entries.append(dict(path=name, raw_sha256=digest(raw), capsule_sha256=digest(public),
                            redacted=raw != public, bytes=len(public)))

commands = []
for path in sorted(OUT.glob('*.json')):
    record = json.loads(path.read_text(encoding='utf-8'))
    if 'command' not in record:
        continue
    commands.append({key: record.get(key) for key in ['name', 'command', 'source_commit', 'source_digest_before',
        'source_digest_after', 'source_unchanged', 'duration_seconds', 'exit_code', 'log', 'log_sha256']})

result = dict(schema_version=1, generated_at=datetime.now(UTC).isoformat(), entry_source=BASE,
    code_commit=code_commit, branch=git('branch', '--show-current'),
    normalized_runtime_diff_empty=True, untracked_runtime_sources=[],
    program_accepted=False, open_gates=['Q', 'S', 'U', 'P', 'I', 'R'],
    source_files_sha256=files, web_scope_sha256=digest(json.dumps(web_hashes, sort_keys=True).encode()),
    web_files_sha256=web_hashes,
    scope_notes=[
        'Command source_unchanged=false is never a frozen whole-source pass.',
        'Web files match the accepted component-test scope; later Python-only repairs are separately verified.',
        'Native HCM explicitly installs its schema; it does not establish Alembic deployment or live API qualification.',
        'Bandit and authorization-inventory gates retain failures; global pip-audit is not a locked application audit.',
        'No competitor benchmark, human UX study, production deployment, certification or full CI acceptance.',
    ],
    commands=commands,
    capsule=dict(path=capsule.relative_to(ROOT).as_posix(), sha256=digest(capsule.read_bytes()),
                 bytes=capsule.stat().st_size, entries=entries))
(DOCS / 'ASSURANCE_2026-10-25.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
with zipfile.ZipFile(capsule) as archive:
    assert archive.testzip() is None
    for entry in entries:
        assert digest(archive.read(entry['path'])) == entry['capsule_sha256']
print(json.dumps(dict(code_commit=code_commit, entries=len(entries), source_files=len(files),
    capsule_bytes=capsule.stat().st_size, capsule_sha256=result['capsule']['sha256'])))
