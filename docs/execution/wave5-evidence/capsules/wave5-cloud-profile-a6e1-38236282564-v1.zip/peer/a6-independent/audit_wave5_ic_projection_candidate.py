"""Static independent projection/migration audit; no app imports or native SQL."""
from __future__ import annotations

import ast
import hashlib
import json
import re
import sys
from pathlib import Path

OWN = Path(__file__).resolve().parent
OPS = Path(r"C:\Users\LOQ\.codex\worktrees\reconforge-operations-wave5\reconforge-erp")
ROOT = Path(r"C:\Users\LOQ\.codex\worktrees\reconforge-integration-wave5\reconforge-erp")
HELPER = "reconforge/infrastructure/postgres_intercompany_guard_projection.py"
MIGRATION = "alembic/versions/0137_postgres_intercompany_guard_projection.py"
TESTS = "tests/test_intercompany_guard_projection.py"
INDEX: dict[str, dict] = {}


def need(condition: object, message: str) -> None:
    if not condition:
        raise ValueError(message)


def captured(root: Path, relative: str) -> str:
    raw = (root / relative).read_bytes()
    INDEX[str(root / relative)] = {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}
    return raw.decode("utf-8")


def balanced(source: str, start: int) -> str:
    depth, quoted, index = 1, False, start
    while index < len(source):
        char = source[index]
        if char == "'":
            if quoted and index + 1 < len(source) and source[index + 1] == "'":
                index += 2
                continue
            quoted = not quoted
        elif not quoted:
            depth += (char == "(") - (char == ")")
            if depth == 0:
                return source[start:index]
        index += 1
    raise ValueError("Unclosed table definition")


def main() -> dict:
    schema_relative = "reconforge/infrastructure/postgres_intercompany_operations_schema.py"
    original_source = captured(OPS, schema_relative)
    need(original_source == captured(ROOT, schema_relative), "Published original IC schema drift")
    original_tree = ast.parse(original_source)
    schema = next(ast.literal_eval(node.value) for node in original_tree.body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "UPGRADE_SQL" for target in node.targets))
    start = "CREATE FUNCTION reconforge.ic_operation_reverse_close()"
    need(schema.count(start) == 1, "Ambiguous original function")
    original = start + schema.split(start, 1)[1].split("END $ic$;", 1)[0] + "END $ic$;"
    marker = "  selected:=changed->>'tenant_id';entry:=NULL;original:=NULL;"
    need(original.count(marker) == 1, "Ambiguous decision boundary")
    body = original.split(marker, 1)[1]
    keys = set(re.findall(r"changed->>'([a-z_]+)'", original))
    need(keys == {"tenant_id", "id", "entry_id", "entry_line_id", "reverses_posting_id", "reverses_effect_id", "entry_number", "entity_code", "plan_id", "object_id", "aggregate_id"}, "Original consumed-key contract changed")
    attachment = schema.split("EXECUTE format('CREATE CONSTRAINT TRIGGER intercompany_operation_owner_closure", 1)[0]
    table_clause = attachment.rsplit("FOREACH n IN ARRAY ARRAY[", 1)[1].split("] LOOP", 1)[0]
    installed = re.findall(r"'([a-z_]+)'", table_clause)
    need(len(installed) == len(set(installed)) == 16, "Installed trigger table contract differs")
    helper_source = captured(OPS, HELPER)
    helper_ast = ast.parse(helper_source)
    need(not any(isinstance(node, (ast.Import, ast.ImportFrom)) and isinstance(node, ast.Import) and any(alias.name != "re" for alias in node.names) for node in helper_ast.body), "Unexpected generator import")
    # Only the pure reviewed generator is evaluated. Remove application imports,
    # injecting the captured literal original SQL from its AST instead.
    pure = ast.Module(body=[node for node in helper_ast.body if not isinstance(node, ast.ImportFrom)], type_ignores=[])
    namespace = {"ORIGINAL_SCHEMA_SQL": schema, "__name__": "independent_static_projection_generator"}
    exec(compile(pure, HELPER, "exec"), namespace)
    upgrade, downgrade = namespace["UPGRADE_SQL"], namespace["DOWNGRADE_SQL"]
    need(upgrade.split(marker, 1)[1] == body, "Original full decision suffix changed")
    need(downgrade == original.replace("CREATE FUNCTION ", "CREATE OR REPLACE FUNCTION ", 1), "Rollback differs from original function")
    header = "CREATE OR REPLACE FUNCTION reconforge.ic_operation_reverse_close() RETURNS trigger LANGUAGE plpgsql SECURITY INVOKER SET search_path=pg_catalog AS $ic$"
    need(upgrade.startswith(header) and downgrade.startswith(header), "Same-signature INVOKER/search_path contract changed")
    registry = dict(namespace["TABLE_FIELD_PROJECTIONS"])
    need(set(registry) == set(installed), "Missing/extra typed table")
    definitions = {}
    for filename in ("postgres_intercompany_operations_schema.py", "postgres_finance_core.py", "postgres_finance_posting_schema.py", "postgres_domain.py", "postgres_ledger.py", "postgres_master_data.py", "postgres_master_data_application.py", "postgres_outbox.py", "outbox_fencing_schema.py"):
        relative = "reconforge/infrastructure/" + filename
        source = captured(OPS, relative)
        need(source == captured(ROOT, relative), "Published schema/authority source changed")
        for table in installed:
            for match in re.finditer(rf"CREATE TABLE(?: IF NOT EXISTS)? reconforge\.{table}\s*\(", source):
                need(table not in definitions, "Duplicate table declaration")
                columns = dict(re.findall(r"(?:^|,)\s*([a-z_][a-z_0-9]*)\s+(TEXT|BIGINT|INTEGER|SMALLINT|JSONB|BOOLEAN|DATE|TIMESTAMPTZ)\b", balanced(source, match.end())))
                definitions[table] = columns
            for name, kind in re.findall(rf"ALTER TABLE reconforge\.{table} ADD COLUMN(?: IF NOT EXISTS)? ([a-z_][a-z_0-9]*)\s+(TEXT|BIGINT|INTEGER|SMALLINT|JSONB|BOOLEAN|DATE|TIMESTAMPTZ)\b", source):
                need(table in definitions, "Column addition before declaration in audit traversal")
                definitions[table][name] = kind
    need(set(definitions) == set(installed), "Table declaration coverage missing")
    actual = {}
    groups = re.findall(r"(?:IF|ELSIF) TG_TABLE_NAME IN\(([^)]+)\) THEN\s+changes:=CASE TG_OP(.*?) END;", upgrade, flags=re.DOTALL)
    for names, cases in groups:
        selectors = {}
        for operation, expression in re.findall(r"WHEN '(INSERT|DELETE|UPDATE)' THEN(.*?)(?=\n|$)", cases):
            objects = re.findall(r"jsonb_build_object\(([^()]*)\)", expression)
            parsed = []
            for expression_object in objects:
                values = re.findall(r"'([a-z_]+)',(OLD|NEW)\.([a-z_]+)", expression_object)
                need(values and len({row for _, row, _ in values}) == 1 and all(key == column for key, _, column in values), "Wrong field/record selector")
                need(expression_object == ",".join(f"'{key}',{row}.{column}" for key, row, column in values), "Unparsed SQL field expression")
                parsed.append((values[0][1], [key for key, _, _ in values]))
            need([row for row, _ in parsed] == {"INSERT": ["NEW"], "DELETE": ["OLD"], "UPDATE": ["OLD", "NEW"]}[operation], "OLD/NEW event order changed")
            selectors[operation] = parsed
        need(set(selectors) == {"INSERT", "DELETE", "UPDATE"}, "Missing event operation")
        for table in re.findall(r"'([a-z_]+)'", names):
            need(table not in actual, "Table matched multiple generated cases")
            actual[table] = selectors
    need(set(actual) == set(installed), "Actual generated SQL table population differs")
    coverage = {}
    for table in installed:
        expected = set(definitions[table]) & keys
        need(set(registry[table]) == expected and all(definitions[table][key] == "TEXT" for key in expected), "Consumed fields missing/extra/nontext")
        for rows in actual[table].values():
            need(all(fields == list(registry[table]) for _, fields in rows), "Actual generated fields differ from table registry")
        coverage[table] = {"consumed_present_text_fields": sorted(expected), "event_records": {key: [row for row, _ in values] for key, values in actual[table].items()}}
    need("to_jsonb(NEW)" not in upgrade and "to_jsonb(OLD)" not in upgrade, "Full row serialization retained")
    for forbidden in ("SECURITY DEFINER", "row_security=off", "GRANT ", "REVOKE ", "ALTER TABLE", "DROP FUNCTION", "CREATE TRIGGER", "DROP TRIGGER", "INSERT INTO", "UPDATE reconforge", "DELETE FROM"):
        need(forbidden not in upgrade and forbidden not in downgrade, "Additional SQL mutation/security change")
    need("IF TG_OP IS NULL OR TG_OP NOT IN('INSERT','UPDATE','DELETE') THEN" in upgrade and "MESSAGE='Unsupported Intercompany deferred guard table'" in upgrade, "Unknown table/event not fail closed")
    migration_source = captured(OPS, MIGRATION)
    migration_ast = ast.parse(migration_source)
    assignments = {node.targets[0].id: ast.literal_eval(node.value) for node in migration_ast.body if isinstance(node, ast.Assign)}
    need(assignments == {"revision": "0137_pg_intercompany_projection", "down_revision": "0136_pg_inventory_scope", "branch_labels": None, "depends_on": None}, "Migration chain differs")
    migration_functions = [node for node in migration_ast.body if isinstance(node, ast.FunctionDef)]
    need([node.name for node in migration_functions] == ["upgrade", "downgrade"], "Migration lifecycle changed")
    for function, name in zip(migration_functions, ("UPGRADE_SQL", "DOWNGRADE_SQL"), strict=True):
        need(len(function.body) == 1 and ast.unparse(function.body[0]) == f"op.execute(sa.text({name}))", "Unexpected migration effect")
    test_source = captured(OPS, TESTS)
    names = {node.name for node in ast.parse(test_source).body if isinstance(node, ast.FunctionDef) and node.name.startswith("test_")}
    need({"test_projection_is_total_over_exact_original_installed_tables_and_consumed_columns", "test_complete_original_decision_body_parent_inverse_old_and_closure_obligations_are_exact", "test_null_empty_foreign_namespace_and_original_inverse_values_are_not_classified_away", "test_same_function_signature_invoker_search_path_and_exact_original_rollback"} <= names, "Important static regression absent")
    return {"schema_version": "wave5-intercompany-projection-independent-static-review-v1", "status": "no_static_blocker", "base_commit": "22ebfd78e293aafa13d81b3a0bbf287491951115", "candidate_state": "isolated uncommitted additive137; not integrated or measured", "actual_native_execution_by_reviewer": False, "application_imports_by_reviewer": False, "checks": {"all16_actual_installed_tables": True, "all11_consumed_keys_when_present": True, "all_projected_fields_native_TEXT": True, "INSERT_NEW_DELETE_OLD_UPDATE_OLD_then_NEW": True, "full_original_decision_suffix_byte_identical": True, "inverse_reversal_and_OLD_header_relevance_preserved": True, "current_parent_queries_authority_and_RLS_context_unchanged": True, "same_signature_INVOKER_search_path": True, "rollback_exact_published_function": True, "unknown_table_and_operation_fail_closed": True, "schema_and_authority_source_files_equal_frozen_root": True}, "field_mapping": coverage, "decision_suffix_sha256": hashlib.sha256(body.encode()).hexdigest(), "generated_upgrade_sql_sha256": hashlib.sha256(upgrade.encode()).hexdigest(), "generated_downgrade_sql_sha256": hashlib.sha256(downgrade.encode()).hexdigest(), "test_source_reviewed_functions": sorted(names), "required_before_acceptance": ["PostgreSQL actual upgrade/catalog/OID/ACL/search_path/SECURITY INVOKER/deferred attachments", "Actual INSERT/DELETE/UPDATE all16table coverage including absent parent and OLD IC1 rename/delete relevance", "Detached native inverse refusal and current-authority/workspace/RLS adversarial gates", "Actual downgrade restores original function and history; migration/backup/restore gates", "Current-source CPU/query/lock profile followed by same-workload retest; no speed or allocation gain inferred from source alone", "Any new schema head requires explicit new financial/restore/oracle source subjects; existing136 proofs must not be rebound"], "file_index": INDEX}


if __name__ == "__main__":
    output = Path(sys.argv[1]).resolve()
    need(output.parent == OWN and not output.exists(), "Fresh owned ignored output required")
    result = main()
    raw = (json.dumps(result, indent=2, ensure_ascii=True, allow_nan=False) + "\n").encode()
    with output.open("xb") as stream:
        stream.write(raw)
    print(json.dumps({"status": result["status"], "path": str(output), "sha256": hashlib.sha256(raw).hexdigest(), "native_execution": False}))
