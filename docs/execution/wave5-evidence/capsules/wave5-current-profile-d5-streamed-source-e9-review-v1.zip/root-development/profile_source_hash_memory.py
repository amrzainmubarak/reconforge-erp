from __future__ import annotations

import argparse
import hashlib
import json
import platform
from pathlib import Path
import statistics
import sys
import time
import tracemalloc


def full_read(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def streamed(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


parser = argparse.ArgumentParser()
parser.add_argument('--input', type=Path, required=True)
parser.add_argument('--expected-sha256', required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
if args.output.exists():
    raise ValueError('Refusing to overwrite a retained observation')
assert full_read(args.input) == streamed(args.input) == args.expected_sha256
rows = []
for repetition, variants in enumerate((('baseline', 'candidate'), ('candidate', 'baseline'), ('baseline', 'candidate')), 1):
    for variant in variants:
        action = full_read if variant == 'baseline' else streamed
        tracemalloc.start()
        try:
            wall_start, cpu_start = time.perf_counter(), time.process_time()
            supplied = action(args.input)
            cpu_seconds = time.process_time() - cpu_start
            seconds = time.perf_counter() - wall_start
            current, peak = tracemalloc.get_traced_memory()
        finally:
            tracemalloc.stop()
        if supplied != args.expected_sha256:
            raise ValueError('Actual original input byte fingerprint changed')
        rows.append({'repetition': repetition, 'variant': variant,
                     'wall_seconds': seconds, 'process_cpu_seconds': cpu_seconds,
                     'python_traced_current_bytes': current, 'python_traced_peak_bytes': peak,
                     'input_sha256': supplied})
medians = {variant: statistics.median(row['python_traced_peak_bytes'] for row in rows if row['variant'] == variant)
           for variant in ('baseline', 'candidate')}
report = {'schema_version': 'source-verification-allocation-microprobe-v1',
          'scope': 'One original evidence file SHA256, raw bytes identical; not an ERP financial workload.',
          'python': sys.version, 'platform': platform.platform(), 'input_path': str(args.input.resolve()),
          'input_bytes': args.input.stat().st_size, 'input_sha256': args.expected_sha256,
          'order': 'BC,CB,BC', 'warmup': 'One identical SHA256 per variant before six observations',
          'allocation_scope': 'Python allocations traced only inside the file-hashing call; not process RSS, OS caches or whole-host memory.',
          'wall_cpu_limit': 'Descriptive under acknowledged external host load, tracing overhead included; fair speed/resource-cost comparison unaccepted.',
          'raw_observations': rows, 'median_python_traced_peak_bytes': medians,
          'financial_posting_performance_accepted': False,
          'wall_cpu_comparison_accepted': False, 'monetary_cost': None}
args.output.write_bytes((json.dumps(report, indent=2) + '\n').encode('utf-8'))
print(json.dumps({'median_python_traced_peak_bytes': medians, 'input_bytes': report['input_bytes'],
                  'same_original_input_sha256': args.expected_sha256,
                  'report_sha256': hashlib.sha256(args.output.read_bytes()).hexdigest()}))
