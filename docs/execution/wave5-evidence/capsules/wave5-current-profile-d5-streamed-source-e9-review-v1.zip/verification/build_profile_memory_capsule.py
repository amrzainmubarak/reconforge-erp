from __future__ import annotations

import ast
import hashlib
import importlib.util
import json
import statistics
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

OWN = Path(__file__).resolve().parents[2]
ROOT = Path('C:/Users/LOQ/.codex/worktrees/reconforge-integration-wave5/reconforge-erp')
COMMERCIAL = Path('C:/Users/LOQ/.codex/worktrees/reconforge-manufacturing-wave5/reconforge-erp')
OUT = OWN / 'output/wave5-evidence-capsules-20261012-v1'
MATERIAL = OUT / 'source-material/profile-memory-d5-e9-v1'
D5 = 'd5c60f47ee3a7310f0097ca3a172e8384c365ba1'
BEFORE_D5 = '770b380a12a791a7d1a019168add6be5a485afa5'
A6 = 'a6b2b5b53383d045a0460dddb9f8444b9f4fc319'
E9 = 'e9dc608eee639bc5dc93f1c8d055fbf7214b4b47'
RUNNER = '.github/scripts/verify_postgres_writeback_recovery_compensation_matrix.py'
D5_FILES = [RUNNER, 'tests/test_postgres_writeback_recovery_compensation_matrix.py',
            'docs/schemas/postgres_writeback_recovery_compensation_matrix.v2.schema.json', 'MANIFEST.in']
E9_FILES = ['.github/scripts/benchmark_native_api_runtime.py', '.github/scripts/benchmark_enterprise_finance.py',
            'tests/test_intercompany_api_benchmark.py']
OLD_FILES = ['docs/schemas/postgres_writeback_recovery_compensation_matrix.schema.json',
             'docs/security/supply-chain-policy.v1.json', 'docs/security/postgres-current-images.wave5.v1.json',
             *[f'docs/execution/POSTGRES_WRITEBACK_RECOVERY_COMPENSATION_MATRIX_{day}.json'
               for day in ('2026-08-22', '2026-10-03', '2026-10-08')]]
PREVIOUS_CAPSULES = [
    ('wave5-wire-independent-native-retained-v1.zip', 'c37112e85881c1576755ff9c60223132e1d23e3cefb631020c743ff66b7c6be7'),
    ('wave5-profiles-interrupted-pair-12fe-v1.zip', '4fc20313342188c5669ee1e883372b2cdd6c52ea4790b423bc9ef4ce75bd78e9'),
    ('wave5-security-diagnostics-git-mirror-failures-v1.zip', '3e331ee8d1376a791e4228022f5a2b7df7ca5f26eaa521f1fe229a37918ab72f'),
    ('wave5-source-archive-verifications-8513-1a40-v1.zip', '90da9c492913be50ee0fb46fb43d56a8bf8d1d412dbd9c7c46071f5d33d0890d'),
    ('wave5-root-security-1a40-38196678518-v1.zip', '47235b63b71e3b8f18bfdb55a9acbea3d908abe66446c238252892636b74b73e'),
    ('wave5-fx-lifecycle-regression-34c92761-v1.zip', '13f1b533be762e845aa04cb5ffab1fd608770949f1f51551f9b4e7e0a777697e'),
    ('wave5-fx-wire-oracle-b6fcf71d-v1.zip', 'bdf88f3aece7eb90e5486fe5d549453debea76eb45a5d426178abbfc3c813e97'),
    ('wave5-ci-1a40-38195991061-v1.zip', 'e8aaee5f2536d4ad07342fe83c38a258ecc625b1af1d2e6b933da96e90d6be4b'),
    ('wave5-writeback-b6fc-failure-cleanup-fix-v1.zip', '0468b089af4c5d8614a114aa7a45446e79940ce9afb70c6f1bdbcb5b742033de'),
    ('wave5-frozen-security-d3e227b7-38202724005-v1.zip', '53309b4e347510e7bdc3227aec8f64b256c98fecc5b3146b4214b2d8f7867e85'),
    ('wave5-d3-python-failure-yaml-fix-writeback-success-v1.zip', 'd8bbf703907c9467692f08a5b4a97a42cb80b685c7eb2c0627d2cbb37d4697c9'),
]


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def file_sha(path: Path) -> str:
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def git(*args: str, root: Path = OWN) -> bytes:
    return subprocess.run(['git', *args], cwd=root, check=True, capture_output=True).stdout


def save(relative: str, raw: bytes) -> Path:
    path = MATERIAL / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == raw, 'An existing evidence input cannot be changed'
    else:
        path.write_bytes(raw)
    return path


def save_json(relative: str, value: object) -> Path:
    return save(relative, (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode())


def source_record(commit: str, name: str) -> dict:
    raw = git('show', f'{commit}:{name}')
    oid = git('rev-parse', f'{commit}:{name}').decode().strip()
    assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == oid
    path = save('git-sources/' + commit[:8] + '/' + name, raw)
    return {'commit': commit, 'repository_relative_path': name, 'git_blob_sha1': oid,
            'raw_sha256': sha(raw), 'bytes': len(raw), 'capsule_source_path': str(path)}


def counts(path: Path) -> dict:
    suite = ET.fromstring(path.read_bytes()).find('testsuite')
    assert suite is not None
    return {key: int(suite.attrib[key]) for key in ('tests', 'failures', 'errors', 'skipped')} | {'seconds': float(suite.attrib['time'])}


def main() -> None:
    selected = []

    def include(path: Path, entry: str, commit: str | None, attribution: str) -> None:
        selected.append((path, entry, commit, attribution))

    records = []
    for commit, names in ((D5, D5_FILES), (BEFORE_D5, [RUNNER]), (A6, E9_FILES), (E9, E9_FILES)):
        for name in names:
            record = source_record(commit, name)
            records.append(record)
            include(Path(record['capsule_source_path']), f'git-sources/{commit[:8]}/{name}', commit,
                    'Immutable original Git blob bytes; source snapshot, not a new workload acceptance.')
    for commit in (BEFORE_D5, D5, A6, E9):
        raw = git('cat-file', 'commit', commit)
        assert hashlib.sha1(b'commit ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == commit
        include(save(f'git-commits/{commit}.txt', raw), f'git-commits/{commit}.txt', commit,
                'Original exact Git commit object bytes; Amr author/committer and ancestry retained.')
    assert git('diff-tree', '--no-commit-id', '--name-only', '-r', D5).decode().splitlines() == sorted(D5_FILES)
    assert git('diff-tree', '--no-commit-id', '--name-only', '-r', E9).decode().splitlines() == sorted(E9_FILES)
    assert git('rev-parse', E9 + '^').decode().strip() == A6
    root_source = []
    for name in E9_FILES:
        raw = (ROOT / name).read_bytes()
        assert raw == git('show', f'{E9}:{name}')
        root_source.append({'path': name, 'captured_bytes': len(raw), 'raw_sha256': sha(raw),
                            'equals_committed_blob_at': E9})
    integrated_profile = []
    for name in D5_FILES:
        d5_raw = git('show', f'{D5}:{name}')
        assert d5_raw == git('show', f'{A6}:{name}') == git('show', f'{E9}:{name}')
        integrated_profile.append({'path': name, 'bytes': len(d5_raw), 'raw_sha256': sha(d5_raw),
                                   'exact_at_commits': [D5, A6, E9]})
    historical = []
    for name in OLD_FILES:
        raw = git('show', f'{BEFORE_D5}:{name}')
        assert raw == git('show', f'{D5}:{name}') == git('show', f'{A6}:{name}') == git('show', f'{E9}:{name}')
        historical.append({'path': name, 'bytes': len(raw), 'raw_sha256': sha(raw),
                           'unchanged_at_commits': [BEFORE_D5, D5, A6, E9]})
    baseline_ast = {node.name: node for node in ast.parse(git('show', f'{BEFORE_D5}:{RUNNER}')).body if isinstance(node, ast.FunctionDef)}
    current_ast = {node.name: node for node in ast.parse(git('show', f'{D5}:{RUNNER}')).body if isinstance(node, ast.FunctionDef)}
    reviewed_functions = ('_run_lifecycle', '_history', '_sqlite_observation', '_create_database_and_role',
                          '_grant_application_boundary', '_role_flags', '_mutation_checks', '_cleanup_owned_container')
    ast_records = []
    for name in reviewed_functions:
        left = ast.dump(baseline_ast[name], include_attributes=False).encode()
        right = ast.dump(current_ast[name], include_attributes=False).encode()
        assert left == right
        ast_records.append({'function_name': name, 'ast_without_locations_sha256': sha(left),
                            'exactly_equal': True, 'before_commit': BEFORE_D5, 'candidate_commit': D5})
    custody = save_json('git-source-custody.json', {'schema_version': 'reconforge-flat-source-custody-v1',
        'immutable_blob_records': records, 'integrated_profile_equivalence': integrated_profile,
        'streamed_source_current_checkout_equivalence': root_source, 'historical_contract_unchanged': historical,
        'reviewed_retained_lifecycle_ast_equivalence': ast_records,
        'test_attribution': '62-case development candidate on770b and59-case development candidate ona6b preceded their commits. Matching source bytes are mapped to d5/e9; these are not newly executed clean-final tests.'})
    include(custody, 'verification/git-source-custody.json', E9,
            'Read-only independent original Git blob/AST verification and exact commit-equivalence mapping; no app imports.')
    profile_xml = OWN / 'output/wave5-current-recovery-profile-review/targeted-final.xml'
    stream_xml = ROOT / 'output/wave5-streamed-source-targeted.xml'
    assert counts(profile_xml) == {'tests': 62, 'failures': 0, 'errors': 0, 'skipped': 0, 'seconds': 3.408}
    assert counts(stream_xml) == {'tests': 59, 'failures': 0, 'errors': 0, 'skipped': 0, 'seconds': 2.549}
    assert file_sha(profile_xml) == 'c4efef24a115805f9e1b405d71c136a794b6ef7d9991f7b67af87176777e6275'
    assert file_sha(stream_xml) == '65bf6b6eb99af21a778a9841a6eb6385735439411e27b4a4b02e6de92242826d'
    for name in ('targeted-final.xml', 'targeted-final.log', 'targeted.xml', 'targeted.log'):
        include(OWN / 'output/wave5-current-recovery-profile-review' / name, 'profile-targeted/' + name, D5,
                'Original development test output; final62 or explicitly provisional61 filename remains unchanged. Source-equal d5 mapping, not clean-final reexecution.')
    for name in ('profile_source_hash_memory.py', 'wave5-source-hash-memory-observations.json',
                 'wave5-streamed-source-targeted.xml', 'wave5-streamed-source-targeted.log'):
        include(ROOT / 'output' / name, 'root-development/' + name, E9,
                'Original root development record on a6b with candidate changes before e9 commit; source bytes mapped to e9, original raw headers retained.')
    observation_path = ROOT / 'output/wave5-source-hash-memory-observations.json'
    assert file_sha(observation_path) == 'c3dd2347f69f88e6482ecc20700e8f2b3b247eb560209a613e49ee300dc0fdc5'
    assert file_sha(ROOT / 'output/profile_source_hash_memory.py') == '4ac89bc1460ec4df5e09b98b1fc913acb8c4b76f704e2c1e71994b609228e417'
    observation = json.loads(observation_path.read_bytes())
    input_path = Path(observation['input_path'])
    assert input_path.is_relative_to(COMMERCIAL / 'output/wave5-d3-independent-acceptance-20261012')
    assert input_path.stat().st_size == observation['input_bytes'] == 22268230
    assert file_sha(input_path) == observation['input_sha256'] == '90a5b1d7afad3cba8f955c3f90ceca36b1b77f1cb5ed2aac1fb97ce59f354113'
    rows = observation['raw_observations']
    assert [(row['repetition'], row['variant']) for row in rows] == [(1, 'baseline'), (1, 'candidate'), (2, 'candidate'), (2, 'baseline'), (3, 'baseline'), (3, 'candidate')]
    assert all(row['input_sha256'] == observation['input_sha256'] for row in rows)
    medians = {variant: statistics.median(row['python_traced_peak_bytes'] for row in rows if row['variant'] == variant)
               for variant in ('baseline', 'candidate')}
    assert medians == observation['median_python_traced_peak_bytes'] == {'baseline': 22276896, 'candidate': 271537}
    assert observation['financial_posting_performance_accepted'] is False and observation['wall_cpu_comparison_accepted'] is False
    old = []
    for name, expected in PREVIOUS_CAPSULES:
        path = OUT / name
        assert file_sha(path) == expected
        old.append({'file_name': name, 'bytes': path.stat().st_size, 'sha256': expected, 'unchanged': True, 'embedded_again': False})
    reference = save_json('prior-capsules-and-input-reference.json', {'schema_version': 'reconforge-flat-external-artifact-reference-v1',
        'prior_eleven_capsules': old, 'microprobe_twelfth_capsule': {'original_path': str(input_path),
        'file_name': input_path.name, 'bytes': input_path.stat().st_size, 'sha256': file_sha(input_path),
        'embedded_again': False, 'trust_anchor': 'Previously reviewed commercial flat index/acceptance packet; original independently rehashed here.'},
        'allocation_observation_verification': {'raw_observation_count': 6, 'warmup_per_variant': 1,
        'alternating_pairs': 3, 'median_python_traced_peak_bytes': medians, 'financial_posting_performance_accepted': False,
        'wall_cpu_comparison_accepted': False, 'whole_host_or_process_rss_claim': False, 'monetary_cost': None}})
    include(reference, 'verification/prior-capsules-and-input-reference.json', None,
            'Flat, independently verified original artifact references; no large input duplicate and no new resource-cost acceptance.')
    peer = save_json('reciprocal-review-checkpoint.json', {'schema_version': 'reconforge-reciprocal-review-checkpoint-v1',
        'reviewer': '/root/commercial_review', 'profile_candidate_commit': D5, 'profile_review_result': 'No blocker; exact four-file final62 checkpoint approved.',
        'profile_xml_sha256': file_sha(profile_xml), 'profile_counts': counts(profile_xml),
        'profile_scope': 'Single-read captured normalized policy source/hash/parse; exact admitted pins before effects; offline closed V1/V2; retained lifecycle AST/policies/report bytes unchanged.',
        'streamed_source_commit': E9, 'streamed_source_parent': A6,
        'streamed_source_review_result': 'No blocker; binary rb/file_digest preserves sorted filename plus raw SHA digest formula, no cache.',
        'streamed_source_counts': counts(stream_xml), 'streamed_source_xml_sha256': file_sha(stream_xml),
        'execution_limits': 'No actual current16.15/17.11 lifecycle, financial API benchmark, local DB, or CI retry was executed by this packaging/review task.'})
    include(peer, 'verification/reciprocal-review-checkpoint.json', E9,
            'Recorded reviewer acknowledgement with independent byte/AST verification; no claim that reviewer reran tests or workloads.')
    include(Path(__file__), 'verification/build_profile_memory_capsule.py', None,
            'Packaging and read-only verification script; no app imports or workloads, does not execute the original microprobe.')
    spec = importlib.util.spec_from_file_location('existing_capsule_builder', OUT / 'build_capsules.py')
    assert spec and spec.loader
    builder = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(builder)
    builder.CAPTURE_SOURCE = E9
    result = builder.capsule('wave5-current-profile-d5-streamed-source-e9-review-v1.zip', selected,
        {'profile_commit': D5, 'integrated_profile_commit': A6, 'streamed_source_commit': E9,
         'profile_targeted_final': counts(profile_xml), 'streamed_source_development_targeted': counts(stream_xml),
         'source_custody': 'Immutable exact Git blobs and raw source SHA256, with development-run to later-commit equivalence mapping.',
         'prior_eleven_capsules_unchanged': True, 'twelfth_input_capsule_reference_only': True,
         'current_postgres_actual_lifecycle_acceptance': 'Pending final integrated source run.',
         'financial_posting_performance_accepted': False, 'wall_cpu_comparison_accepted': False,
         'python_traced_peak_bytes': medians})
    extension = OUT / 'capsule-index-extension-current-profile-and-streamed-source-v1.json'
    assert not extension.exists()
    builder.save_json(extension, {'schema_version': 'reconforge-flat-evidence-capsule-extension-v1',
        'prior_eleven_own_capsules_unchanged': True, 'twelfth_commercial_capsule_reference_only': True,
        'capsules': [result]})
    for name, expected in PREVIOUS_CAPSULES:
        assert file_sha(OUT / name) == expected
    print(json.dumps({'capsule': result, 'extension_name': extension.name, 'extension_sha256': file_sha(extension)}))


if __name__ == '__main__':
    main()
