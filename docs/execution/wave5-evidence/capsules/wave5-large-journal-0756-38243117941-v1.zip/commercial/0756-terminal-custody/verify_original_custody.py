"""Read-only file custody/arithmetic review; no application imports or workloads."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import re
import statistics
import xml.etree.ElementTree as ET
import zipfile

BASE = Path(__file__).resolve().parent
MEMBERS = BASE / "original-members"
ZIP_SHA = "0f482cf7dff400ef5b4cfe1660e6412f245f07f88da5391a4064689461329bd7"
SOURCE = "0756dc49b7f7b3cbb4f5434e735fac64bf845b99"
HARNESS = "7bce2382df24d439d39386f0e02c07bf362c4f451649dbd8d7f225c8a920396b"
LAUNCHER = "a9f60d01589bc68cf03eb24007f6b1a5a8d6f2c2bf29f439215653da713f3d5f"
HELPER = "24a2781b185123a3ea52b2108447936daa7a06b9fbb7c6f08fa1aa3fb2ca00d7"
IMAGE = "postgres:17.11-alpine@sha256:aa90e97ee862e558111d34cfb8b2c4bec768c2b039fb791341686928560263b3"
EXPECTED = {
    "baseline": ("6362724f2337a79c3d7569574f7bf9591a018524", "0132_pg_stock_inverse_dispatch"),
    "current": ("22ebfd78e293aafa13d81b3a0bbf287491951115", "0136_pg_inventory_scope"),
    "projection": (SOURCE, "0137_pg_intercompany_projection"),
}


def require(value, why):
    if not value:
        raise ValueError(why)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def no_duplicates(pairs):
    out = {}
    for key, value in pairs:
        require(key not in out, "Duplicate JSON key")
        out[key] = value
    return out


def load(path):
    return json.loads(path.read_bytes(), object_pairs_hook=no_duplicates,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def integer(value, expected=None):
    require(type(value) is int and value >= 0, "Non-exact nonnegative integer")
    if expected is not None:
        require(value == expected, "Integer differs")
    return value


def duration(value):
    require(type(value) in (int, float) and math.isfinite(value) and value >= 0, "Malformed timing")
    return value


def dt(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def main():
    original = BASE / "artifact-11746610473-original.zip"
    index = load(BASE / "original-artifact-member-index-v1.json")
    require(original.stat().st_size == 848014 and sha(original.read_bytes()) == ZIP_SHA, "Original ZIP differs")
    require(index["source_commit"] == SOURCE and index["run_id"] == 38243117941
            and index["artifact_id"] == 11746610473 and index["original_zip_sha256"] == ZIP_SHA
            and index["api_digest"] == "sha256:" + ZIP_SHA, "API/index source binding differs")
    records = {r["member"]: r for r in index["members"]}
    require(len(records) == len(index["members"]) == 129, "Member population differs")
    with zipfile.ZipFile(original) as z:
        require(set(z.namelist()) == set(records), "ZIP members differ")
        for name, row in records.items():
            parts = PurePosixPath(name)
            require(not parts.is_absolute() and ".." not in parts.parts, "Unsafe member")
            raw = z.read(name)
            require(len(raw) == row["bytes"] and sha(raw) == row["sha256"]
                    and (MEMBERS / name).read_bytes() == raw, "Member bytes/hash differs: " + name)
    require((MEMBERS / "workflow-source-commit.txt").read_text().strip() == SOURCE, "Workflow source differs")
    api = load(BASE / "artifacts-20261012T120000839760Z.json")
    artifact = next(row for row in api["artifacts"] if row["id"] == 11746610473)
    require(artifact["digest"] == "sha256:" + ZIP_SHA and artifact["size_in_bytes"] == 848014
            and artifact["workflow_run"]["head_sha"] == SOURCE, "Original artifact API binding differs")
    aggregate = load(MEMBERS / "diagnostics/diagnostics.json")
    require(aggregate["status"] == "passed" and aggregate["performance_comparison_accepted"] is False
            and aggregate["harness_sha256"] == HARNESS and aggregate["launcher_sha256"] == LAUNCHER
            and aggregate["ledger_helper"]["sha256"] == HELPER, "Original aggregate differs")
    selected = ["baseline", "current", "projection", "current", "projection", "baseline", "projection", "baseline", "current"]
    require(aggregate["selected_run_order"] == selected and [r["variant"] for r in aggregate["runs"]] == selected,
            "Latin balanced population differs")
    integer(aggregate["large_snapshot_repetitions"], 3)
    require(aggregate["projection_tree"]["reviewed_ancestor"] == "a4a5282aaf29ff89e182569888877fa606dde6a5"
            and aggregate["projection_tree"]["actual_commit"] == SOURCE, "Projection attribution differs")
    oracle = str(sum(1 + int(sha(f"enterprise-native-v1:{i}".encode())[:16], 16) % 1000000 for i in range(100)))
    require(oracle == "46669102", "Independent primary oracle differs")
    rows = []
    tenants, cids, processes, effects, entries = set(), set(), set(), set(), set()
    bare_effects, bare_entries = set(), set()
    previous_finish = None
    for selected_row in aggregate["runs"]:
        dirname = selected_row["directory"]
        p = MEMBERS / "diagnostics" / dirname
        d, r, spec = (load(p / n) for n in ("diagnostic.json", "native/result.json", "spec.json"))
        require(sha((p / "diagnostic.json").read_bytes()) == selected_row["diagnostic_sha256"]
                and sha((p / "native/result.json").read_bytes()) == d["original_result_sha256"], "Report SHA differs")
        variant = selected_row["variant"]
        source = aggregate["sources"][variant]
        require((source["commit"], source["revision"]) == EXPECTED[variant]
                and d["source_before"] == d["source_after"] == source
                and r["source_commit"] == r["source_commit_after"] == source["commit"]
                and r["source_sha256"] == r["source_sha256_after"] == source["tracked_sha256"]
                and r["revision"] == source["revision"] and r["source_unchanged"] is True, "Source mismatch")
        require(d["status"] == r["status"] == "passed" and r["owned_container_removed"] is True
                and d["process_cleanup"] == {"status": "verified_exited"}
                and d["container_cleanup"]["status"] == "verified_absent"
                and d["container_cleanup"]["deleted_by_parent"] is False, "Cleanup incomplete")
        identity = d["process"]
        for field in ("pid", "start_ticks", "session", "process_group"):
            integer(identity[field])
        require(identity["pid"] == identity["session"] == identity["process_group"]
                and identity["executable"] == aggregate["python_executable"], "Process custody differs")
        admission, intent, audit, response, created, origins, complete, capture, ledger = (
            load(p / n) for n in ("admission.json", "creation-intent.json", "creation-audit.json", "creation-response.json",
                                 "created-container.json", "origins.json", "worker-complete.json",
                                 "large-journal-ledger-capture.json", "large-journal-ledger.raw.json"))
        require(admission["process"] == intent["process"] == audit["process"] == response["process"]
                == origins["process"] == capture["source_process"] == identity
                and admission["retained_pidfd"] is True and audit["status"] == "matched"
                and intent["pre_spawn_exact_name_absent"] is True
                and audit["command_sha256"] == intent["command_sha256"]
                and response["intent_sha256"] == sha((p / "creation-intent.json").read_bytes())
                and response["audit_sha256"] == sha((p / "creation-audit.json").read_bytes())
                and response["returncode"] == 0, "Admission/creation bindings differ")
        cid = response["container_id"]
        require(re.fullmatch("[0-9a-f]{64}", cid) is not None
                and created["container_id"] == capture["container_id"] == d["container_cleanup"]["container_id"] == cid
                and created["name"] == "/" + intent["name"] and created["image"] == intent["image"] == IMAGE
                and created["cmd"] == intent["cmd"] and created["entrypoint"] == intent["entrypoint"]
                and created["owner_label"] == intent["label"]
                and created["auto_remove"] is True and created["restart_policy"]["Name"] == "no"
                and created["publish_all_ports"] is False and created["privileged"] is False
                and created["port_bindings"] == {"5432/tcp": [{"HostIp": "127.0.0.1", "HostPort": ""}]}
                and set(created["actual_ports"]) == {"5432/tcp"}
                and len(created["actual_ports"]["5432/tcp"]) == 1
                and created["actual_ports"]["5432/tcp"][0]["HostIp"] == "127.0.0.1"
                and dt(created["created_at"]) >= dt(intent["observed_at"]), "Container seal differs")
        require(origins["status"] == "passed" and origins["runtime_root"] == source["root"]
                and origins["foreign_modules"] == [] and origins["harness_sha256_after"] == HARNESS
                and all(o["module"].split(".")[0] in ("reconforge", "tests")
                        and o["path"].startswith(source["root"] + "/" + o["module"].split(".")[0] + "/")
                        for o in origins["origins"])
                and complete == {"exit_code": 0, "origin_status": "passed"}, "Module/process completion differs")
        require(spec["root"] == r["runtime_root"] == r["launch_cwd"] == source["root"]
                and spec["harness"] == r["harness_path"] == aggregate["sources"]["current"]["root"] + "/.github/scripts/benchmark_enterprise_finance.py"
                and spec["launcher_sha256"] == LAUNCHER and spec["ledger_helper"]["sha256"] == HELPER
                and r["harness_sha256"] == r["harness_sha256_after"] == HARNESS
                and r["command"][1:] == [spec["harness"], *spec["business_args"]], "Common harness command differs")
        for field, val in (("workers", 4), ("posting_warmup_cycles", 20), ("repetitions", 3), ("max_seconds", 1200), ("snapshot_lines", 1000)):
            integer(r[field], val)
        require(r["counts"] == [100] and type(r["counts"][0]) is int and r["image"] == IMAGE
                and r["runtime_role_flags"] == [False, False] and all(type(x) is bool for x in r["runtime_role_flags"])
                and r["cost_per_transaction"] is None and "posting_database_profile" not in r
                and all(r["postgres_configuration"][x] == "on" for x in ("fsync", "full_page_writes", "synchronous_commit")), "Runtime configuration differs")
        post, warm = r["posting"], r["posting_warmup"]
        for field in ("requested_cycles", "admitted_cycles", "completed_cycles"):
            integer(post[field], 100)
        for field in ("error_count", "not_admitted_cycles"):
            integer(post[field], 0)
        require(post["failed_cycles"] == [] and post["completed_indices"] == list(range(100))
                and all(type(x) is int for x in post["completed_indices"])
                and post["expected"] == dict.fromkeys(("debit_minor", "credit_minor", "cash_minor", "equity_minor"), oracle)
                and len(post["ordered_effect_ids"]) == len(set(post["ordered_effect_ids"])) == 100
                and len(post["raw_cycle_latency_seconds"]) == 100, "Primary financial population differs")
        integer(warm["completed_cycles"], 20)
        require(warm["status"] == "passed" and warm["indices"] == list(range(100, 120))
                and all(type(x) is int for x in warm["indices"]) and warm["outside_measured_population"] is True
                and len(warm["effect_ids"]) == len(set(warm["effect_ids"])) == 20, "Warm population differs")
        read = r["verified_reads"][0]
        require(len(r["verified_reads"]) == 1 and read["status"] == "passed" and read["expected"] == post["expected"]
                and read["dataset_effect_ids_sha256"] == sha(canonical(post["ordered_effect_ids"])), "Read source population differs")
        for mode, samples in read["samples"].items():
            require(mode in ("per_effect_baseline", "bounded_batch") and [s["repetition"] for s in samples] == [0, 1, 2], "Read schedule differs")
            for s in samples:
                require(s["status"] == "complete" and s["debit_minor"] == s["credit_minor"] == oracle
                        and s["effects_digest"] == read["financial_effects_digest"]
                        and len(s["raw_request_latency_seconds"]) == (100 if mode == "per_effect_baseline" else 1), "Read result differs")
        phases = r["posting_profile"]["raw_phase_observations"]
        require(len(phases) == 1080 and {(x["index"], x["phase"]) for x in phases}
                == {(i, f"{stage}.{phase}") for i in range(120) for stage in ("prepare", "review", "post")
                    for phase in ("identity_enter", "business", "transaction_exit")}
                and all(type(x["index"]) is int and x["failure_type"] is None for x in phases)
                and r["posting_profile"]["function_profile"]["enabled"] is False, "Phase population differs")
        for x in phases:
            duration(x["seconds"]); duration(x["thread_cpu_seconds"])
        snap = r["snapshot_reads"]
        require(snap["status"] == "passed" and snap["fixture_stage"] == "complete"
                and snap["outside_primary_posting_measurement"] is True and snap["expected_total_minor"] == "500", "Snapshot lifecycle differs")
        integer(snap["line_count"], 1000)
        for mode, samples in snap["samples"].items():
            require(mode in ("per_line_baseline", "joined_snapshot") and [s["repetition"] for s in samples] == [0, 1, 2], "Snapshot repetitions differ")
            for s in samples:
                require(s["status"] == "complete" and s["debit_minor"] == s["credit_minor"] == "500"
                        and s["validation_digest"] == snap["expected_validation_digest"], "Snapshot financial/digest differs")
                integer(s["lines"], 1000); integer(s["dimension_links"], 668)
                duration(s["seconds"]); duration(s["client_process_cpu_seconds"])
        require(ledger["database"] == "postgres" and ledger["read_only"] == "on" and ledger["isolation"] == "repeatable read"
                and ledger["revision"] == [source["revision"]] and ledger["app_role_flags"] == [False, False]
                and ledger["server_version_num"] == "170011", "Raw export source/database differs")
        require(len(ledger["headers"]) == len(ledger["effects"]) == 1 and len(ledger["lines"]) == 1000
                and len(ledger["dimension_links"]) == 668, "Raw native population differs")
        header, effect = ledger["headers"][0], ledger["effects"][0]
        tenant = header["tenant_id"]
        require(header["status"] == "Validated" and header["source_type"] == "Manual"
                and header["validation_digest"] == effect["validation_digest"] == snap["expected_validation_digest"]
                and effect["entry_id"] == effect["source_id"] == header["id"] and effect["tenant_id"] == tenant
                and effect["source_kind"] == "Manual" and effect["purpose"] == "operational_posting"
                and (header["preparer_actor_id"], header["validator_actor_id"], effect["posted_actor_id"])
                == ("erp-maker", "erp-checker", "erp-poster"), "Native ownership/three humans differ")
        integer(header["total_debit_minor"], 500); integer(header["total_credit_minor"], 500)
        account_codes = {a["id"]: a["account_code"] for a in ledger["accounts"]}
        ordered = sorted(ledger["lines"], key=lambda x: x["line_number"])
        require(len({x["id"] for x in ordered}) == 1000, "Duplicate native line")
        dimcounts = Counter(x["entry_line_id"] for x in ledger["dimension_links"])
        for i, line in enumerate(ordered):
            integer(line["line_number"], i + 1)
            integer(line["debit_minor"], 1 if i % 2 == 0 else 0)
            integer(line["credit_minor"], 0 if i % 2 == 0 else 1)
            require(line["tenant_id"] == tenant and line["entry_id"] == header["id"] and line["currency_code"] == "USD"
                    and account_codes[line["account_id"]] == ("CASH" if i % 2 == 0 else "EQUITY")
                    and dimcounts[line["id"]] == (2 if i % 3 == 0 else 0), "Independent alternating financial/dimensional oracle differs")
        require(all(x["tenant_id"] == tenant and x["entry_line_id"] in {l["id"] for l in ordered} for x in ledger["dimension_links"]), "Dimension custody differs")
        raw = (p / "large-journal-ledger.raw.json").read_bytes()
        require(capture["status"] == "passed" and capture["returncode"] == 0
                and capture["credentials_or_environment_captured"] is False
                and capture["raw_sha256"] == capture["stdout_sha256"] == d["live_ledger_raw_sha256"] == sha(raw)
                and capture["raw_bytes"] == capture["stdout_bytes"] == len(raw)
                and capture["command"] == ["docker", "exec", "--interactive", cid, "psql", "--username", "postgres", "--dbname", "postgres",
                                           "--no-psqlrc", "--quiet", "--tuples-only", "--no-align", "--set", "ON_ERROR_STOP=1"]
                and capture["command_sha256"] == sha(canonical(capture["command"]))
                and capture["verification"]["external_report_anchor"] is False
                and d["live_ledger_verification"]["external_report_anchor"] is True
                and d["live_ledger_verification"]["audit_chain_recomputed"] is False, "Original live export hash/command binding differs")
        ids = [*post["ordered_effect_ids"], *warm["effect_ids"], effect["id"]]
        require(len(ids) == len(set(ids)) == 121, "Within-tenant effects overlap")
        qualified = {(tenant, i) for i in ids}
        require(tenant not in tenants and cid not in cids and (identity["pid"], identity["start_ticks"]) not in processes
                and not effects & qualified, "Fresh owner/process/server/population overlaps")
        tenants.add(tenant); cids.add(cid); processes.add((identity["pid"], identity["start_ticks"]))
        effects.update(qualified); entries.add((tenant, header["id"])); bare_entries.add(header["id"]); bare_effects.update(ids)
        start, finish = dt(r["started_at"]), dt(r["finished_at"])
        require(finish > start and (previous_finish is None or start >= previous_finish), "Run intervals overlap")
        previous_finish = finish
        sampling = r["resource_sampling"]
        require(sampling["status"] == "complete" and sampling["errors"] == [] and sampling["thread_still_running"] is False
                and len(sampling["raw_samples"]) >= 2, "Observer incomplete")
        stages = snap["stage_measurements"]
        for measurement in stages.values():
            duration(measurement["seconds"]); duration(measurement["client_process_cpu_seconds"])
        rows.append({"directory": dirname, "variant": variant, "source": source, "started_at": r["started_at"], "finished_at": r["finished_at"],
                     "process": identity, "container_id": cid, "tenant_id": tenant, "entry_id": header["id"], "large_effect_id": effect["id"],
                     "original_result_sha256": sha((p / "native/result.json").read_bytes()), "original_native_export_sha256": sha(raw),
                     "original_diagnostic_sha256": sha((p / "diagnostic.json").read_bytes()),
                     "whole_journal_stages": stages, "whole_journal_seconds": sum(s["seconds"] for s in stages.values()),
                     "primary100_seconds": post["seconds"], "primary100_client_cpu_seconds": post["client_process_cpu_seconds"],
                     "legacy_snapshot_reader_median_seconds": snap["median_seconds_baseline"],
                     "existing_joined_reader_median_seconds": snap["median_seconds_optimized"],
                     "reported_within_run_legacy_reader_ratio": snap["measured_speedup"], "sample_count": len(sampling["raw_samples"]),
                     "process_cleanup": d["process_cleanup"], "container_cleanup": d["container_cleanup"]})
    require(len(tenants) == len(cids) == len(processes) == len(entries) == 9 and len(effects) == 1089, "Aggregate populations differ")
    junit = ET.parse(MEMBERS / "pure-contracts.xml").getroot()
    cases = list(junit.iter("testcase"))
    require(len(cases) == 189 and not list(junit.iter("failure")) and not list(junit.iter("error")) and not list(junit.iter("skipped")), "Original pure JUnit differs")
    summary = {}
    for variant in EXPECTED:
        group = [row for row in rows if row["variant"] == variant]
        summary[variant] = {"runs": 3, "source_commit": EXPECTED[variant][0],
                            "median_whole_journal_seconds": statistics.median(x["whole_journal_seconds"] for x in group),
                            "stage_wall_median_seconds": {s: statistics.median(x["whole_journal_stages"][s]["seconds"] for x in group)
                                                           for s in ("prepare", "review", "post")},
                            "stage_client_cpu_median_seconds": {s: statistics.median(x["whole_journal_stages"][s]["client_process_cpu_seconds"] for x in group)
                                                                 for s in ("prepare", "review", "post")},
                            "median_primary100_seconds": statistics.median(x["primary100_seconds"] for x in group)}
    result = {"schema_version": "wave5-large-journal-original-file-custody-review-v1", "status": "passed",
              "reviewed_at": datetime.now(timezone.utc).isoformat(), "review_method": "Standard-library original byte/index/ZIP/source/process/container/arithmetic checks; no application imports, test rerun or workload",
              "run_id": 38243117941, "job_id": 114790340943, "source_commit": SOURCE,
              "original_artifact_id": 11746610473, "original_zip_sha256": ZIP_SHA, "original_zip_bytes": 848014,
              "original_index_sha256": sha((BASE / "original-artifact-member-index-v1.json").read_bytes()), "verified_original_members": 129,
              "original_aggregate_sha256": sha((MEMBERS / "diagnostics/diagnostics.json").read_bytes()),
              "original_job_log_sha256": sha((BASE / "job-114790340943-20261012T120029961458Z.log").read_bytes()),
              "original_pure_cases": 189, "original_pure_failures_errors_skips": [0, 0, 0],
              "original_primary_cycles": 900, "original_warm_cycles": 180, "original_snapshot_journals": 9,
              "tenant_qualified_native_effects": 1089, "fresh_tenants_servers_process_births": [9, 9, 9],
              "bare_journal_ids_observed": len(bare_entries), "bare_effect_ids_observed": len(bare_effects),
              "original_primary_read_requests": 2727, "original_snapshot_reads": 54, "original_phase_observations": 9720,
              "independent_large_lines": 9000, "independent_large_dimension_links": 6012,
              "independent_large_debit_credit_minor": [4500, 4500], "original_runtime_rows": rows,
              "descriptive_cross_source_stage_medians": summary, "performance_comparison_accepted": False,
              "cost_per_transaction": None, "forced_timeout_exercised": False,
              "limits": ["Financial/custody diagnostic closure is distinct from fair performance or competitor acceptance.",
                         "Within-run legacy per-line versus joined snapshot ratio is an existing accepted636 reader difference, not new Wave5 gain.",
                         "Whole1000-line stage wall/client CPU are separate from primary100-cycle throughput and resource windows.",
                         "Original container/client CPU windows differ; no total host/process-tree CPU or monetary cost.",
                         "Observer samples span stages without dedicated per-snapshot-stage WAL/I/O attribution; track_io_timing=off zeros are unavailable I/O timing evidence.",
                         "Native original export is separately hash-bound; entire audit chain was not recomputed.",
                         "No timeout/forced cleanup occurred; normal verified process exit and original-harness container removal observed.",
                         "Operations independently owns18 standalone -I/-I-O full oracle verifications; this packet preserves separate file-custody/arithmetic review."]}
    output = BASE / "original-nine-run-custody-review-v1.json"
    require(not output.exists(), "Refusing to overwrite review")
    output.write_bytes(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2).encode() + b"\n")
    print(json.dumps({"status": "passed", "output": str(output), "sha256": sha(output.read_bytes()), "members": 129,
                      "runs": 9, "native_effects": 1089, "medians": summary}, sort_keys=True))


if __name__ == "__main__":
    main()
