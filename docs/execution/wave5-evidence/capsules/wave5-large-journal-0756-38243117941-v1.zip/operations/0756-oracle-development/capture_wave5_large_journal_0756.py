"""Exclusive one-download original artifact custody; no runtime/DB imports."""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import re
import stat
import subprocess
import zipfile
from pathlib import Path, PurePosixPath

SOURCE = "0756dc49b7f7b3cbb4f5434e735fac64bf845b99"
RUN = 38243117941
BASE = Path(__file__).resolve().parent / "wave5-large-journal-0756-38243117941"
REPO = "repos/amrzainmubarak/reconforge-erp"
PRIVATE = {
    "private-key": re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    "private-token": re.compile(rb"(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|AKIA[A-Z0-9]{16})"),
    "runtime-password-field": re.compile(rb'"(?:password|password_hash|password_salt|client_secret|access_token|refresh_token)"\s*:\s*"(?!\*\*\*|\[redacted\])[^"\r\n]+"', re.I),
    "unredacted-connection-credential": re.compile(rb"(?:postgres(?:ql)?|redis|rediss)://[^:/\s]+:(?!\*\*\*|\[redacted\])[^@\s]+@", re.I),
}


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def api(path: str) -> bytes:
    result = subprocess.run(["gh", "api", f"{REPO}/{path}"], capture_output=True, timeout=60, check=False)
    if result.returncode or len(result.stdout) > 32 * 1024 * 1024:
        raise RuntimeError("Bounded read-only artifact response unavailable")
    return result.stdout


def put(path: Path, raw: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(raw)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--artifact-id", required=True, type=int)
    args = parser.parse_args()
    assert args.artifact_id > 0
    BASE.mkdir(exist_ok=True)
    metadata_raw = api(f"actions/artifacts/{args.artifact_id}")
    metadata = json.loads(metadata_raw)
    assert metadata["id"] == args.artifact_id and metadata["expired"] is False
    assert metadata["workflow_run"]["id"] == RUN and metadata["workflow_run"]["head_sha"] == SOURCE
    assert metadata["name"] == f"wave5-large-journal-{SOURCE}-1"
    put(BASE / f"artifact-{args.artifact_id}-original-api.json", metadata_raw)
    raw = api(f"actions/artifacts/{args.artifact_id}/zip")
    assert metadata["digest"] == "sha256:" + sha(raw), "Original artifact differs from authenticated API byte pin"
    entries = []
    pending = []
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        infos = [info for info in archive.infolist() if not info.is_dir()]
        assert len(infos) <= 1000 and len({info.filename for info in infos}) == len(infos)
        assert sum(info.file_size for info in infos) <= 128 * 1024 * 1024
        for info in infos:
            path = PurePosixPath(info.filename)
            assert not path.is_absolute() and ".." not in path.parts and ":" not in info.filename and "\\" not in info.filename
            assert stat.S_IFMT(info.external_attr >> 16) != stat.S_IFLNK and not info.flag_bits & 1
            assert info.file_size <= 8 * 1024 * 1024
            data = archive.read(info)
            assert len(data) == info.file_size
            matches = {kind: len(pattern.findall(data)) for kind, pattern in PRIVATE.items() if pattern.search(data)}
            if matches:
                pending.append({"member": info.filename, "signature_types_and_counts": matches, "bytes": len(data), "sha256": sha(data)})
            entries.append({"member": info.filename, "bytes": len(data), "sha256": sha(data)})
        assert archive.read("workflow-source-commit.txt").decode().strip() == SOURCE
    review = {"source_commit": SOURCE, "run_id": RUN, "artifact_id": args.artifact_id,
              "original_zip_bytes": len(raw), "original_zip_sha256": sha(raw), "api_digest": metadata["digest"],
              "members": entries, "signature_review_pending": pending,
              "complete_original_zip_retained": not pending,
              "screen_scope": "Private key/token/password-field/connection credential signatures only; public literal references are not blanket secrets.",
              "performance_comparison_accepted": False}
    put(BASE / "original-artifact-member-index-v1.json", (json.dumps(review, indent=2) + "\n").encode())
    assert not pending, "Original artifact held in memory only pending literal/credential source classification"
    filename = f"artifact-{args.artifact_id}-original.zip"
    put(BASE / filename, raw)
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        for entry in entries:
            data = archive.read(entry["member"])
            assert sha(data) == entry["sha256"]
            put(BASE / "original-members" / entry["member"], data)
    print(json.dumps({"source_commit": SOURCE, "artifact_id": args.artifact_id, "file": filename,
                      "bytes": len(raw), "sha256": sha(raw), "members": len(entries), "private_signature_matches": 0}))


if __name__ == "__main__":
    main()
