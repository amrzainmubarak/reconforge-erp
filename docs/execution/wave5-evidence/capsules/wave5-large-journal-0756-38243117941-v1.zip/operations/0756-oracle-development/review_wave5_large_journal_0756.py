"""Independent file-only nine-population custody/resource-window review."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile
from collections import Counter
from pathlib import Path, PurePosixPath

SOURCE = "0756dc49b7f7b3cbb4f5434e735fac64bf845b99"
RUN = 38243117941
ORACLE_SHA = "24a2781b185123a3ea52b2108447936daa7a06b9fbb7c6f08fa1aa3fb2ca00d7"
HARNESS_SHA = "7bce2382df24d439d39386f0e02c07bf362c4f451649dbd8d7f225c8a920396b"
IMAGE = "postgres:17.11-alpine@sha256:aa90e97ee862e558111d34cfb8b2c4bec768c2b039fb791341686928560263b3"
HEADS = {"baseline": "6362724f2337a79c3d7569574f7bf9591a018524", "current": "22ebfd78e293aafa13d81b3a0bbf287491951115", "projection": SOURCE}
REVISIONS = {"baseline": "0132_pg_stock_inverse_dispatch", "current": "0136_pg_inventory_scope", "projection": "0137_pg_intercompany_projection"}
ORDER = (("baseline", "current", "projection"), ("current", "projection", "baseline"), ("projection", "baseline", "current"))
CHECKOUT = Path(__file__).resolve().parents[1]


def need(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def canonical(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode()


def unique(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        need(key not in result, "Duplicate artifact JSON member")
        result[key] = value
    return result


def decode(raw: bytes) -> dict:
    value = json.loads(raw, object_pairs_hook=unique,
                       parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Nonfinite JSON")))
    need(type(value) is dict, "Artifact JSON object required")
    return value


def put(path: Path, value: object) -> None:
    with path.open("xb") as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False).encode() + b"\n")


def number(value: object) -> bool:
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def percentile(raw: list, retained: dict) -> None:
    need(type(raw) is list and raw and all(number(value) for value in raw), "Original latency vector differs")
    values = sorted(raw)
    need(all(number(retained[key]) and retained[key] == values[math.ceil(len(values) * part) - 1]
             for key, part in (("p50", .5), ("p95", .95), ("p99", .99))), "Original retained percentile differs")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--zip", type=Path, required=True)
    parser.add_argument("--trusted-zip-sha256", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    zip_raw = args.zip.read_bytes()
    need(re.fullmatch(r"[0-9a-f]{64}", args.trusted_zip_sha256) is not None and sha(zip_raw) == args.trusted_zip_sha256,
         "Original archive differs from separately authenticated API SHA256")
    need(not args.output.exists(), "Fresh independent output required")
    args.output.mkdir()
    helper = subprocess.run(["git", "show", f"{SOURCE}:.github/scripts/verify_wave5_large_journal.py"], cwd=CHECKOUT,
                            capture_output=True, check=True, timeout=15).stdout
    need(sha(helper) == ORACLE_SHA, "Reviewed standalone oracle source differs")
    helper_path = args.output / "original-reviewed-0756-oracle.py"
    with helper_path.open("xb") as stream:
        stream.write(helper)
    tracked = {}
    for variant, commit in HEADS.items():
        filenames = subprocess.run(["git", "ls-tree", "-r", "--name-only", commit], cwd=CHECKOUT,
                                   capture_output=True, check=True, timeout=15).stdout.decode().splitlines()
        tracked[variant] = set(filenames)
    members, results = [], []
    with zipfile.ZipFile(args.zip) as archive:
        names = [info.filename for info in archive.infolist() if not info.is_dir()]
        need(len(names) == len(set(names)), "Repeated ZIP members")
        trusted = {name: sha(archive.read(name)) for name in names}
        for name in names:
            members.append({"member": name, "sha256": trusted[name], "bytes": len(archive.read(name))})

        def raw(name: str) -> bytes:
            data = archive.read(name)
            need(sha(data) == trusted[name], "Original archive member drift")
            return data

        def read(name: str) -> dict:
            return decode(raw(name))

        need(raw("workflow-source-commit.txt").decode().strip() == SOURCE, "Actual workflow source differs")
        pure = ET.fromstring(raw("pure-contracts.xml"))
        pure_cases = list(pure.iter("testcase"))
        need(len(pure_cases) == 189 and all(not list(case.iter("failure")) and not list(case.iter("error")) and not list(case.iter("skipped")) for case in pure_cases),
             "Actual hosted pure contracts not fully passed")
        report = read("diagnostics/diagnostics.json")
        need(report["status"] == "passed" and report["performance_comparison_accepted"] is False
             and report["schema_version"] == "wave5-linux-large-journal-diagnostics-v1"
             and report["large_snapshot_repetitions"] == 3 and report["large_snapshot_lines"] == 1000
             and report["selected_run_order"] == [variant for group in ORDER for variant in group] and len(report["runs"]) == 9,
             "Nine-population original top-level acceptance differs")
        need(report["harness_sha256"] == HARNESS_SHA and report["ledger_helper"]["sha256"] == ORACLE_SHA
             and report["business_seconds"] == 1200 and report["child_seconds"] == 1500 and report["overall_seconds"] == 3300
             and report["cleanup_reserve_seconds"] == 120, "Common harness/oracle/budget source differs")
        need(set(report["sources"]) == set(HEADS) and all(report["sources"][label]["commit"] == commit
             and report["sources"][label]["revision"] == REVISIONS[label] for label, commit in HEADS.items()), "Three exact runtime subjects differ")
        tenants, containers, qualified_effects, qualified_entries, bare_entries, bare_effects = set(), set(), set(), set(), set(), set()
        for repetition, order in enumerate(ORDER, 1):
            for variant in order:
                prefix = f"diagnostics/large-snapshot-r{repetition}-{variant}/"
                diagnostic = read(prefix + "diagnostic.json")
                packet = read(prefix + "native/result.json")
                capture = read(prefix + "large-journal-ledger-capture.json")
                response = read(prefix + "creation-response.json")
                intent = read(prefix + "creation-intent.json")
                creation = read(prefix + "created-container.json")
                admission = read(prefix + "admission.json")
                origins = read(prefix + "origins.json")
                spec = read(prefix + "spec.json")
                need(diagnostic["status"] == "passed" and diagnostic["performance_comparison_accepted"] is False
                     and diagnostic["source_before"] == diagnostic["source_after"] == report["sources"][variant]
                     and diagnostic["original_result_sha256"] == trusted[prefix + "native/result.json"], "Original per-run status/source/result binding differs")
                process = diagnostic["process"]
                need(process == admission["process"] == response["process"] == intent["process"] == capture["source_process"] == origins["process"]
                     and process["pid"] == process["session"] == process["process_group"] and process["executable"] == report["python_executable"],
                     "Original admitted process identity differs")
                cid = response["container_id"]
                need(re.fullmatch(r"[0-9a-f]{64}", cid) is not None and cid == capture["container_id"] == creation["container_id"]
                     and cid not in containers and creation["image"] == IMAGE and creation["name"] == "/" + intent["name"]
                     and response["intent_sha256"] == trusted[prefix + "creation-intent.json"]
                     and response["audit_sha256"] == trusted[prefix + "creation-audit.json"], "Original immutable creation custody differs")
                need(creation["auto_remove"] is True and creation["restart_policy"]["Name"] == "no"
                     and creation["publish_all_ports"] is False and creation["privileged"] is False
                     and creation["port_bindings"]["5432/tcp"][0]["HostIp"] == creation["actual_ports"]["5432/tcp"][0]["HostIp"] == "127.0.0.1"
                     and diagnostic["process_cleanup"]["status"] == "verified_exited" and diagnostic["container_cleanup"]["status"] == "verified_absent"
                     and diagnostic["container_cleanup"]["container_id"] == cid, "Owned cleanup/configuration differs")
                need(origins["status"] == "passed" and origins["foreign_modules"] == [] and origins["runtime_root"] == report["sources"][variant]["root"]
                     and origins["harness_sha256_after"] == HARNESS_SHA and spec["ledger_helper"]["sha256"] == ORACLE_SHA,
                     "Original runtime/stdlib helper origins differ")
                runtime_root = PurePosixPath(report["sources"][variant]["root"])
                origin_names = [row["module"] for row in origins["origins"]]
                need(len(origin_names) == len(set(origin_names)) and {"reconforge.infrastructure.postgres_finance_core",
                     "reconforge.infrastructure.postgres_finance_posting", "reconforge.benchmark.resource_sampling",
                     "tests.erp_expansion_browser_seed"} <= set(origin_names), "Actual module origin population differs")
                for row in origins["origins"]:
                    relative = PurePosixPath(row["path"]).relative_to(runtime_root)
                    need(".." not in relative.parts and relative.as_posix() in tracked[variant], "Original imported module is outside its tracked runtime")
                need(spec["root"] == packet["runtime_root"] == packet["launch_cwd"] == origins["runtime_root"], "Actual runtime/cwd origin differs")
                need(packet["status"] == "passed" and packet["source_unchanged"] is True and packet["owned_container_removed"] is True
                     and packet["source_commit"] == packet["source_commit_after"] == HEADS[variant]
                     and packet["source_sha256"] == packet["source_sha256_after"] == report["sources"][variant]["tracked_sha256"]
                     and packet["harness_sha256"] == packet["harness_sha256_after"] == HARNESS_SHA
                     and packet["image"] == IMAGE and packet["postgres_version"].split()[0] == "17.11"
                     and packet["revision"] == REVISIONS[variant] and packet["snapshot_lines"] == 1000
                     and packet["workers"] == 4 and packet["posting_warmup_cycles"] == 20 and packet["repetitions"] == 3,
                     "Original common financial workload/source differs")
                need(capture["status"] == "passed" and type(capture["returncode"]) is int and capture["returncode"] == 0
                     and capture["raw_sha256"] == trusted[prefix + "large-journal-ledger.raw.json"]
                     and capture["raw_bytes"] == len(raw(prefix + "large-journal-ledger.raw.json")) and capture["credentials_or_environment_captured"] is False,
                     "Original raw native export is detached from captured source")
                ledger_path = args.output / f"r{repetition}-{variant}-original-native-ledger.json"
                ledger_path.write_bytes(raw(prefix + "large-journal-ledger.raw.json"))
                oracle_outputs = []
                for flags, label in ((["-I"], "I"), (["-I", "-O"], "IO")):
                    output = args.output / f"r{repetition}-{variant}-oracle-{label}.json"
                    called = subprocess.run([sys.executable, *flags, str(helper_path), "--ledger", str(ledger_path),
                        "--expected-export-sha256", trusted[prefix + "large-journal-ledger.raw.json"],
                        "--expected-validation-digest", packet["snapshot_reads"]["expected_validation_digest"],
                        "--expected-revision", REVISIONS[variant], "--output", str(output)], capture_output=True, check=False, timeout=15)
                    need(called.returncode == 0, "Original pinned native ledger failed standalone oracle")
                    oracle_outputs.append(output.read_bytes())
                need(oracle_outputs[0] == oracle_outputs[1], "Isolated optimized oracle differs")
                verified = decode(oracle_outputs[0])
                need(verified["raw_export_anchor"] is True and verified["external_report_anchor"] is True
                     and verified["status"] == "passed" and verified["line_count"] == 1000 and verified["dimension_links"] == 668
                     and verified["debit_minor"] == verified["credit_minor"] == 500, "Independent native oracle population differs")
                tenant, entry = verified["tenant_id"], verified["entry_id"]
                need(tenant not in tenants and (tenant, entry) not in qualified_entries, "Fresh population tenant/journal reused")
                large = packet["snapshot_reads"]
                need(large["status"] == "passed" and large["fixture_stage"] == "complete" and large["line_count"] == 1000
                     and large["expected_total_minor"] == "500" and large["concurrency"] == 1 and large["outside_primary_posting_measurement"] is True
                     and set(large["stage_measurements"]) == {"prepare", "review", "post"}, "Original whole journal stages differ")
                need(all(number(value) for measurement in large["stage_measurements"].values() for value in measurement.values()), "Invalid whole stage observation")
                need(set(large["samples"]) == {"per_line_baseline", "joined_snapshot"}, "Both original read algorithms required")
                for mode, samples in large["samples"].items():
                    need([sample["repetition"] for sample in samples] == [0, 1, 2], "Three original read repetitions required")
                    need(all(sample["status"] == "complete" and sample["lines"] == 1000 and sample["dimension_links"] == 668
                             and sample["debit_minor"] == sample["credit_minor"] == "500" and sample["validation_digest"] == verified["validation_digest"]
                             and type(sample["client_execute_calls"]) is int and sample["client_execute_calls"] > 0
                             and type(sample["peak_python_allocated_bytes"]) is int and sample["peak_python_allocated_bytes"] >= 0
                             and number(sample["seconds"]) and number(sample["client_process_cpu_seconds"]) for sample in samples), "Original read population/source differs")
                primary = packet["posting"]
                expected = str(sum(1 + int(hashlib.sha256(f"enterprise-native-v1:{index}".encode()).hexdigest()[:16], 16) % 1_000_000 for index in range(100)))
                need(expected == "46669102" and all(primary["expected"][key] == expected for key in ("debit_minor", "credit_minor", "cash_minor", "equity_minor"))
                     and primary["requested_cycles"] == primary["admitted_cycles"] == primary["completed_cycles"] == 100
                     and primary["completed_indices"] == list(range(100)) and primary["failed_cycles"] == [] and primary["error_count"] == 0,
                     "Original primary financial population differs")
                percentile(primary["raw_cycle_latency_seconds"], primary["cycle_latency_seconds"])
                warm = packet["posting_warmup"]
                need(warm["status"] == "passed" and warm["completed_cycles"] == 20 and warm["indices"] == list(range(100, 120))
                     and warm["outside_measured_population"] is True, "Original warmup population differs")
                effects = [*primary["ordered_effect_ids"], *warm["effect_ids"], verified["effect_id"]]
                scoped = {(tenant, effect) for effect in effects}
                need(len(effects) == len(set(effects)) == 121 and not scoped & qualified_effects, "Scoped native effect population overlaps")
                sampling = packet["resource_sampling"]
                observations = sampling["raw_samples"]
                need(sampling["status"] == "complete" and sampling["thread_still_running"] is False and sampling["errors"] == []
                     and sampling["interval_seconds"] == 10 and len(observations) >= 2, "Original resource observations incomplete")
                need(all(number(row["elapsed_seconds"]) and number(row["client_cpu_seconds"]) for row in observations)
                     and all(first["elapsed_seconds"] < last["elapsed_seconds"] and first["client_cpu_seconds"] <= last["client_cpu_seconds"]
                             for first, last in zip(observations, observations[1:])), "Original resource window/order differs")
                need(packet["cost_per_transaction"] is None and "posting_database_profile" not in packet
                     and packet["posting_profile"]["function_profile"]["enabled"] is False, "Unapproved cost/SQL/CPU instrumentation differs")
                tenants.add(tenant)
                containers.add(cid)
                qualified_entries.add((tenant, entry))
                qualified_effects.update(scoped)
                bare_entries.add(entry)
                bare_effects.update(effects)
                results.append({"repetition": repetition, "variant": variant, "commit": HEADS[variant], "container_id": cid,
                    "tenant_id": tenant, "entry_id": entry, "large_effect_id": verified["effect_id"], "original_native_raw_sha256": trusted[prefix + "large-journal-ledger.raw.json"],
                    "isolated_oracle_output_sha256": sha(oracle_outputs[0]), "original_report_sha256": trusted[prefix + "native/result.json"],
                    "stage_measurements": large["stage_measurements"], "original_read_samples": large["samples"],
                    "resource_first_elapsed_seconds": observations[0]["elapsed_seconds"], "resource_last_elapsed_seconds": observations[-1]["elapsed_seconds"],
                    "resource_samples": len(observations), "process_lifetime_peak_rss_bytes": max(row["client_memory"]["process_lifetime_peak_rss_bytes"] for row in observations),
                    "standalone_financial_oracle": "passed", "owned_cleanup": "verified_absent"})
    need(len(results) == len(tenants) == len(containers) == len(qualified_entries) == 9 and len(qualified_effects) == 1089,
         "Complete nine fresh native populations required")
    review = {"status": "passed", "source_commit": SOURCE, "run_id": RUN, "original_zip_sha256": args.trusted_zip_sha256,
        "independent_file_only": True, "actual_native_journals": 9, "large_lines": 9000, "large_dimension_links": 6012,
        "large_debit_minor": 4500, "large_credit_minor": 4500, "qualified_native_effect_ids_reported": 1089,
        "distinct_bare_entry_ids": len(bare_entries), "distinct_bare_effect_ids": len(bare_effects), "identity_scope": "tenant_id plus native ID",
        "standalone_oracle_processes": 18, "reviewed_oracle_sha256": ORACLE_SHA, "populations": results,
        "resource_scope": ["Whole authenticated journal stage timers include identity/business/transaction exit and client process CPU only.",
            "Four-worker100 primary and20 warmup cycles precede each separate one-journal1000-line stage.",
            "Each reviewed snapshot reader has three runs and Python traced allocation peaks; these are not whole-ERP RAM peaks.",
            "Ten-second sampler starts after masters and covers primary/warm/read/large/end-provenance work until stop before readonly export/cleanup.",
            "Linux client RSS is process-lifetime getrusage peak; sampled windows cannot provide per-journal-stage WAL/I/O/backend CPU.",
            "Cumulative PostgreSQL/WAL and Docker counters are overlapping sampled/final windows, not isolated per-stage costs.",
            "No stable power/frequency/provider-neighbor observation or cross-hardware equivalence is established by this packet."],
        "performance_comparison_accepted": False, "force_rls_new_isolation_proof": False, "audit_chain_recomputed": False}
    put(args.output / "independent-nine-population-review.json", review)
    put(args.output / "original-zip-flat-member-records.json", {"source_commit": SOURCE, "records": members})
    print(json.dumps({"status": "passed", "native_journals": 9, "standalone_oracle_processes": 18, "performance_comparison_accepted": False}))


if __name__ == "__main__":
    main()
