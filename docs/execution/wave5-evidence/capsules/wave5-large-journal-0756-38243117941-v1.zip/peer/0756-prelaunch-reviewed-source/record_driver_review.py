"""Read-only large-journal launcher review and original gate custody."""
from __future__ import annotations

import ast
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path("C:/Users/LOQ/.codex/worktrees/reconforge-manufacturing-wave5/reconforge-erp")
OUT = Path(__file__).resolve().parent
BASE = "a6e1f6dfed845b5e72de9b681981db92020b03d5"
SCRIPT = ".github/scripts/benchmark_wave5_profile_diagnostics.py"
EXPECTED = {
    SCRIPT: "a9f60d01589bc68cf03eb24007f6b1a5a8d6f2c2bf29f439215653da713f3d5f",
    "tests/test_wave5_profile_diagnostics.py": "d42d12e961f78478aff733d0bb7e0194a4ea317c4a3ae9be2eca2a833af478cc",
    ".github/workflows/wave5-large-journal-diagnostics.yml": "99933495f56b294e0e425cfc06ab37d8e45bb3f1d213ea165f118c1704df53f0",
    "output/wave5-large-profile-driver-pure-qualified.xml": "ffc1626da2a7cb0af53b296750bebedd050f8c8029f7923c904d088c63dfe906",
}
UNCHANGED = (
    "require", "digest", "unique", "read", "save", "checked", "source", "projection_tree", "identity", "numeric",
    "exact_ints", "percentile", "docker_words", "verify_container", "cleanup", "stop",
)


def require(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def functions(raw: bytes) -> dict[str, str]:
    return {node.name: ast.dump(node, include_attributes=False) for node in ast.parse(raw).body if isinstance(node, ast.FunctionDef)}


def main() -> None:
    records = []
    for index, (relative, expected) in enumerate(EXPECTED.items(), 1):
        original = ROOT / relative
        raw = original.read_bytes()
        require(hashlib.sha256(raw).hexdigest() == expected, "Exact reviewed launcher checkpoint differs")
        retained = OUT / "driver-originals" / f"{index:04d}" / original.name
        retained.parent.mkdir(parents=True, exist_ok=True)
        with retained.open("xb") as stream:
            stream.write(raw)
        records.append({"original": str(original), "retained": str(retained), "bytes": len(raw), "sha256": expected})
    result = subprocess.run(["git", "show", f"{BASE}:{SCRIPT}"], cwd=ROOT, capture_output=True, timeout=10, check=False)
    require(result.returncode == 0, "Original committed launcher required")
    before, after = functions(result.stdout), functions((ROOT / SCRIPT).read_bytes())
    require(all(before[name] == after[name] for name in UNCHANGED), "Original custody/deadline/source function changed")
    original_target = OUT / "driver-originals" / "original-a6-launcher.py"
    with original_target.open("xb") as stream:
        stream.write(result.stdout)
    suites = ET.parse(ROOT / "output/wave5-large-profile-driver-pure-qualified.xml").getroot().findall("testsuite")
    counts = {key: sum(int(suite.attrib[key]) for suite in suites) for key in ("tests", "errors", "failures", "skipped")}
    require(counts == {"tests": 85, "errors": 0, "failures": 0, "skipped": 0}, "Original qualified native-identity gate differs")
    report = {
        "schema_version": "wave5-large-driver-independent-static-review-v1",
        "status": "no_static_blocker",
        "candidate_checkpoint": "Exact precommit source/test/workflow byte hashes; original pure gate is not an actual native performance run",
        "base_commit": BASE,
        "original_base_launcher_sha256": hashlib.sha256(result.stdout).hexdigest(),
        "original_base_launcher_retained": str(original_target),
        "unchanged_function_ast": list(UNCHANGED),
        "original_targeted_counts": counts,
        "original_targeted_seconds": sum(float(suite.attrib["time"]) for suite in suites),
        "resolved_review_findings": [
            "Pre-rm capture requires full retained immutable configuration plus CID/PID/intent/audit custody; missing seal records failure, does not query ledger, and still removes only exact acknowledged CID",
            "Native create_entry uses platform_id('GLE',workspace_id,entry_number): fixed work and BENCH-SNAPSHOT-DIMENSIONS repeat the same bare journal ID across fresh tenants",
            "Journal and effect aggregate admission uses native(tenant_id,id); realistic repeated bare entry/effect IDs across distinct tenants are accepted, within-owner duplicate effects refused",
        ],
        "reviewed_contract": {
            "order": ["baseline", "current", "projection", "current", "projection", "baseline", "projection", "baseline", "current"],
            "fresh_runs": 9, "fresh_tenants": 9, "fresh_servers": 9,
            "per_run": {"primary_cycles": 100, "warmups": 20, "workers": 4, "primary_verified_read_requests": 303,
                        "phase_observations": 1080, "extra_journals": 1, "extra_lines": 1000,
                        "debit_minor": 500, "credit_minor": 500, "dimension_links": 668, "snapshot_read_requests": 6},
            "scoped_native_effects": 1089,
            "business_seconds": 1200, "child_seconds": 1500, "overall_seconds": 3300, "cleanup_reserve_seconds": 120,
            "no_sql_or_cprofile_instrumentation_in_large_mode": True,
            "default_six_mode_semantics_preserved": True,
            "raw_capture_sha_cid_pid_status_required_before_final_admission": True,
            "helper_matches_original_review_digest_and_exact_runtime_revision": True,
        },
        "workflow_review": "Exact new experimental branch, fixed B636/C22/control SHA, pinned actions, contents-read, 65min job bound, mandatory pure modules, early original source artifact and always raw capture; no service or native suite repetition",
        "resource_windows": [
            "Extra journal prepare/review/post records whole authenticated wall and client process CPU independently",
            "Primary posting throughput/latency/client CPU excludes the extra journal and snapshot readers",
            "Sampler.stop and final Docker stats occur before independent readonly export, so sampled/final resource counters exclude that export",
            "Overall harness wall includes final readonly export and cleanup; no per-stage WAL/I/O attribution",
        ],
        "limits": ["Static review and original pure gates only; actual nine financial workloads not yet executed", "A 1000-line GL journal is not a 1000-line commercial order", "No performance superiority, causal regression, resource improvement or monetary cost accepted"],
        "records": records,
        "actual_workload_or_test_executed_by_reviewer": False,
        "performance_comparison_accepted": False,
    }
    target = OUT / "driver-independent-static-review-v1.json"
    with target.open("xb") as stream:
        stream.write(json.dumps(report, indent=2, allow_nan=False).encode() + b"\n")
    print(json.dumps({"report": str(target), "sha256": hashlib.sha256(target.read_bytes()).hexdigest(), "counts": counts}))


if __name__ == "__main__":
    main()
