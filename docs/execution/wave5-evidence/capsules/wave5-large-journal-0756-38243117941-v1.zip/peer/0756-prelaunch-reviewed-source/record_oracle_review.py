"""File-only independent source/test custody; never executes a workload."""
from __future__ import annotations

import ast
import hashlib
import json
import xml.etree.ElementTree as ET
from pathlib import Path

OPS = Path("C:/Users/LOQ/.codex/worktrees/reconforge-operations-wave5/reconforge-erp")
OUT = Path(__file__).resolve().parent
EXPECTED = {
    ".github/scripts/verify_wave5_large_journal.py": "24a2781b185123a3ea52b2108447936daa7a06b9fbb7c6f08fa1aa3fb2ca00d7",
    "tests/test_wave5_large_journal_oracle.py": "4aef6edaf792719ab3d5106a86460b99aa9d4c2d47b8f5ea20963caf3088d418",
    "output/wave5-large-journal-oracle-final.xml": "7c2a462c99b26acfd0fbc10a0221b2fc937031d07b7b70cec2c88447eb64a92d",
    "output/wave5-large-journal-oracle-final.log": "89abe0022556087d0a57f944305831e8ad25cc7666fb2db649b66fdcf70345b4",
}


def require(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def main() -> None:
    records = []
    for index, (relative, expected) in enumerate(EXPECTED.items(), 1):
        original = OPS / relative
        raw = original.read_bytes()
        require(hashlib.sha256(raw).hexdigest() == expected, "Exact reviewed original differs")
        retained = OUT / "originals" / f"{index:04d}" / original.name
        retained.parent.mkdir(parents=True, exist_ok=True)
        with retained.open("xb") as stream:
            stream.write(raw)
        records.append({"original": str(original), "retained": str(retained), "bytes": len(raw), "sha256": expected})
    tree = ast.parse((OPS / ".github/scripts/verify_wave5_large_journal.py").read_text(encoding="utf-8"))
    imports = {node.module.split(".")[0] for node in ast.walk(tree) if isinstance(node, ast.ImportFrom) and node.module}
    imports |= {alias.name.split(".")[0] for node in ast.walk(tree) if isinstance(node, ast.Import) for alias in node.names}
    require(imports <= {"__future__", "argparse", "datetime", "hashlib", "json", "re", "pathlib", "typing"}, "Only reviewed stdlib imports allowed")
    require(not any(isinstance(node, ast.Assert) for node in ast.walk(tree)), "Optimized runtime must retain oracle guards")
    suites = ET.parse(OPS / "output/wave5-large-journal-oracle-final.xml").getroot().findall("testsuite")
    counts = {key: sum(int(suite.attrib[key]) for suite in suites) for key in ("tests", "errors", "failures", "skipped")}
    require(counts == {"tests": 104, "errors": 0, "failures": 0, "skipped": 0}, "Original targeted gate differs")
    names = [case.attrib["name"] for suite in suites for case in suite.findall("testcase")]
    require(sum(name.startswith("test_coordinated_tenant_swap") for name in names) == 2, "Both retained isolated CLI negatives required")
    report = {
        "schema_version": "wave5-large-oracle-independent-static-review-v1",
        "status": "no_static_blocker",
        "review_scope": "Read-only source/schema/financial semantic review and original pure JUnit custody; no DB, Docker, workload or test rerun",
        "candidate_source_checkpoint": "Two uncommitted additive oracle files reviewed from experimental a6 ancestry; hashes above are exact, not a clean-runtime acceptance",
        "original_targeted_counts": counts,
        "original_targeted_seconds": sum(float(suite.attrib["time"]) for suite in suites),
        "only_stdlib_imports": sorted(imports),
        "optimized_runtime_assertion_guards": False,
        "source_financial_checks_reviewed": [
            "Fixed REPEATABLE READ READ ONLY SQL over original tables; no application imports, environment inspection or financial writes",
            "One native header/effect, 1000 ordered unique alternating USD one-minor lines: 500 debit and 500 credit",
            "668 unique links: exactly BENCH_A/B SYNTHETIC on every third original line, with native parent/master custody",
            "Original header snapshot enriched through exact org/entity masters; matches canonical posting snapshot contract",
            "Three independent exact maker/checker/poster actors; native Validated header and immutable Manual effect establish publication",
            "Closed 23-field effect schema and retained UTC timestamp match immutable original native table",
            "Canonical reviewed snapshot SHA, retained currency registry SHA, audit/outbox references, original request digest and complete command acknowledgement",
            "Mandatory standalone separately trusted raw export SHA before parse, plus separately trusted original reviewed digest and revision",
            "All-coordinated tenant mutation retaining financial seal refused by original raw SHA under -I and -I -O",
        ],
        "limits": [
            "Admin postgres read-only export proves financial consistency, not a new restricted-role RLS/authorization probe",
            "The original financial snapshot omits tenant_id; source tenant custody requires exact acknowledged CID/PID and original raw SHA metadata",
            "Audit chain is not recomputed; no complete backup/restore or performance result is asserted",
            "Owner driver requires full immutable container creation seal before live capture; driver population admission reviewed separately",
        ],
        "records": records,
        "financial_runtime_changed": False,
        "actual_native_or_benchmark_executed_by_reviewer": False,
        "performance_comparison_accepted": False,
    }
    target = OUT / "oracle-independent-static-review-v1.json"
    with target.open("xb") as stream:
        stream.write(json.dumps(report, indent=2, allow_nan=False).encode() + b"\n")
    print(json.dumps({"report": str(target), "sha256": hashlib.sha256(target.read_bytes()).hexdigest(), "counts": counts}))


if __name__ == "__main__":
    main()
