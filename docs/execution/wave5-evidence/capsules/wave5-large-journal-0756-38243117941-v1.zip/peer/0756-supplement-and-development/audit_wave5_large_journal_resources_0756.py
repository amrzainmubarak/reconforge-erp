"""Supplement original file-only nine-run review; no repeated oracle/workload."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import statistics
from pathlib import Path

OWN = Path(__file__).resolve().parent
PROOF = OWN / "wave5-large-journal-0756-independent-I/independent-review.json"
TRUSTED = "eff8fc934f753fd019786c2733b22fab7fd03ad0ff25dfb877cd3c4793d211e2"
PARSER = OWN / "audit_wave5_linux_profiles.py"
PARSER_SHA = "1331a336b5030b07f1b40fa8c2fee8f4265fc0ccaa560025bf873dfaf2b56023"


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def unique(values: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in values:
        need(key not in result, "Duplicate JSON member")
        result[key] = value
    return result


def read(path: Path) -> dict:
    return json.loads(path.read_bytes(), object_pairs_hook=unique,
                      parse_constant=lambda _: need(False, "Nonfinite original evidence"))


def spread(values: list[float | int]) -> dict:
    need(len(values) == 3, "Exactly three retained runs required")
    mean = statistics.mean(values)
    return {"raw": values, "minimum": min(values), "median": statistics.median(values), "maximum": max(values),
            "sample_standard_deviation": statistics.stdev(values), "coefficient_of_variation": statistics.stdev(values) / mean if mean else None}


def main() -> None:
    need(sha(PROOF.read_bytes()) == TRUSTED and sha(PARSER.read_bytes()) == PARSER_SHA, "Original independent evidence/parser differs")
    original = read(PROOF)
    spec = importlib.util.spec_from_file_location("retained_original_resource_parser", PARSER)
    need(spec is not None and spec.loader is not None, "Retained stdlib parser unavailable")
    parser = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(parser)
    runs = []
    for row in original["runs"]:
        key = f"diagnostics/{row['directory']}/native/result.json"
        member = original["original_member_index"][key]
        path = Path(member["extracted"])
        need(sha(path.read_bytes()) == member["sha256"] == row["original_report_sha256"], "Original report/member binding differs")
        packet = read(path)
        before, after = [parser.raw_counters(packet[name]) for name in ("posting_container_counters_before", "posting_container_counters_after")]
        network = {name: sum(counter[name] for counter in after["network_by_interface"].values()) - sum(counter[name] for counter in before["network_by_interface"].values())
                   for name in ("received_bytes", "transmitted_bytes")}
        samples = packet["resource_sampling"]["raw_samples"]
        database = {key: samples[-1]["postgres_database_counters"][key] - samples[0]["postgres_database_counters"][key]
                    for key in samples[0]["postgres_database_counters"]}
        need(all(value >= 0 for value in network.values()) and all(value >= 0 for value in database.values()), "Original cumulative counter decreased")
        metrics = {key: value for key, value in row["metrics"].items() if type(value) in (int, float)}
        metrics.update({f"primary_cgroup_{key}": value for key, value in row["metrics"]["primary_cgroup_io_delta"].items()})
        metrics.update({f"primary_cgroup_network_{key}": value for key, value in network.items()})
        metrics.update({f"sample_database_{key}": value for key, value in database.items()})
        phases = packet["posting_profile"]["raw_phase_observations"]
        measured = [phase for phase in phases if phase["index"] < 100]
        phase_cpu = sum(phase["thread_cpu_seconds"] for phase in measured)
        identity = sum(phase["thread_cpu_seconds"] for phase in measured if phase["phase"].endswith("identity_enter"))
        phases_by_name = {phase: {"count": len(group), "thread_cpu_seconds_sum": sum(value["thread_cpu_seconds"] for value in group)}
                          for phase in sorted({value["phase"] for value in measured}) if (group := [value for value in measured if value["phase"] == phase])}
        need(len(measured) == 900 and all(value["count"] == 100 for value in phases_by_name.values()), "Original primary phase population differs")
        metrics["primary_identity_share_of_phase_thread_cpu_percent"] = identity / phase_cpu * 100
        runs.append({"directory": row["directory"], "variant": row["variant"], "source": row["source"],
                     "original_report_sha256": row["original_report_sha256"], "metrics": metrics,
                     "primary_cgroup_network_delta": network, "sample_database_counter_deltas": database,
                     "primary_phase_thread_cpu": phases_by_name,
                     "original_host_processor_observations": [value.get("host_processor") for value in samples],
                     "original_docker_engine_resources": packet["docker_engine_resources"],
                     "original_postgres_configuration": packet["postgres_configuration"]})
    keys = list(runs[0]["metrics"])
    grouped = {variant: {key: spread([row["metrics"][key] for row in runs if row["variant"] == variant]) for key in keys}
               for variant in ("baseline", "current", "projection")}
    changes = {comparison: {key: (grouped[right][key]["median"] / grouped[left][key]["median"] - 1) * 100
                           if grouped[left][key]["median"] else None for key in keys}
               for comparison, left, right in (("current_vs_baseline", "baseline", "current"), ("projection_vs_current", "current", "projection"))}
    result = {"schema_version": "wave5-large0756-original-resource-supplement-v1", "status": "passed_descriptive_file_review",
              "original_independent_financial_source_review": str(PROOF), "original_independent_financial_source_review_sha256": TRUSTED,
              "actual_source": "0756dc49b7f7b3cbb4f5434e735fac64bf845b99", "runs": runs,
              "per_variant_three_run_resource_dispersion": grouped, "descriptive_median_changes_percent": changes,
              "standalone_oracles_or_workloads_rerun": False, "performance_comparison_accepted": False,
              "limits": ["Raw cgroup CPU/I/O/network brackets measured100 primary cycles after20 warmups and before the large journal/readers; observer/kernel probe overhead remains",
                         "Posting-end lifetime container memory includes startup/migration/warmup but is sampled before the later big-journal peak",
                         "Ten-second sampled client lifetime RSS and database/WAL counter windows span warmup/primary/reads/large journal differently; no per-stage backend resource attribution",
                         "Sampler.stop and final Docker stats occur before readonly export; overall wall includes export/cleanup",
                         "All native original reports and counter strings remain unchanged; all18 standalone oracle outputs already passed and are not rerun here",
                         "Primary raw phase thread CPU fractions are not pureKDF, whole-process or host CPU fractions",
                         "The legacy per-line versus joined reader exists in baseline636; its within-run ratio is not automatically a new Wave5 improvement",
                         "Medians and dispersion are three independent run statistics, not pooled percentiles or a confidence interval",
                         "Host power/frequency observations are unavailable on these Linux samples; no Windows quiet/power equality or inter-run physical isolation is inferred",
                         "No accepted causal regression/resource improvement/global superiority or monetary cost claim"]}
    target = OWN / "wave5-large-journal-0756-resource-supplement-v1.json"
    with target.open("xb") as stream:
        stream.write(json.dumps(result, indent=2, allow_nan=False).encode() + b"\n")
    print(json.dumps({"report": str(target), "sha256": sha(target.read_bytes()), "runs": len(runs)}))


if __name__ == "__main__":
    main()
