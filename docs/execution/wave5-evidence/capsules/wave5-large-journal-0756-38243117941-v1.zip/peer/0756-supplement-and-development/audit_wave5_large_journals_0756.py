"""Independent file-only original nine-journal evidence review.

No database, Docker, network or application imports. Only retained stdlib oracle
CLI files are executed, against separately pinned original ZIP member bytes.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import re
import statistics
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime
from pathlib import Path, PurePosixPath

OWN = Path(__file__).resolve().parent
COMMIT = "0756dc49b7f7b3cbb4f5434e735fac64bf845b99"
HEADS = {"baseline": "6362724f2337a79c3d7569574f7bf9591a018524", "current": "22ebfd78e293aafa13d81b3a0bbf287491951115", "projection": COMMIT}
TREES = {"baseline": "2947b63eff5c07ee58c7f37bd74ef5791fa4605a", "current": "5758db54102719605f88f7048c2e54000c8eaaa2", "projection": "77a8a95bc2878444067886afbcefed4ff87370a6"}
OLD_LINUX_SHA = {"baseline": "d548fb6285681ef8b0105f5279997ef99dc41a05c21269e88dd9f81f0a107345", "current": "acd60e50895d0d3b59af741ed4d36e5f62d98c205f0b48201a9eeb0a7beeba88"}
DRIVER = OWN / "wave5-large-journal-prelaunch-peer-review/driver-originals/0001/benchmark_wave5_profile_diagnostics.py"
HELPER = OWN / "wave5-large-journal-prelaunch-peer-review/originals/0001/verify_wave5_large_journal.py"
DRIVER_SHA = "a9f60d01589bc68cf03eb24007f6b1a5a8d6f2c2bf29f439215653da713f3d5f"
HELPER_SHA = "24a2781b185123a3ea52b2108447936daa7a06b9fbb7c6f08fa1aa3fb2ca00d7"
RAW_RESOURCES = OWN / "audit_wave5_linux_profiles.py"
RESOURCE_SHA = "1331a336b5030b07f1b40fa8c2fee8f4265fc0ccaa560025bf873dfaf2b56023"
MEMBERS: dict[str, dict] = {}


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def unique(values: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in values:
        need(key not in result, "Duplicate JSON member")
        result[key] = value
    return result


def read(path: Path, expected: str | None = None) -> dict:
    raw = path.read_bytes()
    need(expected is None or sha(raw) == expected, "Original file hash differs")
    return json.loads(raw, object_pairs_hook=unique,
                      parse_constant=lambda _: need(False, "Nonfinite original JSON"))


def module(path: Path, expected: str, name: str):
    need(sha(path.read_bytes()) == expected, "Retained original verifier bytes differ")
    spec = importlib.util.spec_from_file_location(name, path)
    need(spec is not None and spec.loader is not None, "Retained stdlib module absent")
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


class OriginalLinuxPath(PurePosixPath):
    def resolve(self, *args: object, **kwargs: object):
        need(self.is_absolute() and ".." not in self.parts, "Noncanonical original Linux path")
        return self


def numeric(value: object) -> bool:
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def dispersion(values: list[float]) -> dict:
    need(len(values) == 3 and all(numeric(value) for value in values), "Exactly three finite independent runs required")
    mean = statistics.mean(values)
    return {"raw": values, "minimum": min(values), "median": statistics.median(values), "maximum": max(values),
            "mean": mean, "sample_standard_deviation": statistics.stdev(values),
            "coefficient_of_variation": statistics.stdev(values) / mean if mean else None}


def metrics(packet: dict, resource_oracle) -> dict:
    posting, snapshot = packet["posting"], packet["snapshot_reads"]
    before, after = [resource_oracle.raw_counters(packet[key]) for key in ("posting_container_counters_before", "posting_container_counters_after")]
    need(set(before["block_io_by_device"]) == set(after["block_io_by_device"])
         and set(before["network_by_interface"]) == set(after["network_by_interface"]), "Original cgroup device population differs")
    io = {key: sum(value[key] for value in after["block_io_by_device"].values()) - sum(value[key] for value in before["block_io_by_device"].values())
          for key in ("rbytes", "wbytes", "rios", "wios", "dbytes", "dios")}
    need(all(type(value) is int and value >= 0 for value in io.values()), "Original cgroup I/O delta decreased")
    samples = packet["resource_sampling"]["raw_samples"]
    need(posting["native_postings_per_second"] == 100 / posting["seconds"] and posting["seconds"] > 0, "Original primary throughput arithmetic differs")
    result = {"primary_100_seconds": posting["seconds"], "primary_cycles_per_second": 100 / posting["seconds"],
              "primary_client_process_cpu_seconds": posting["client_process_cpu_seconds"],
              "primary_cgroup_cpu_seconds": (after["cpu_microseconds"]["usage_usec"] - before["cpu_microseconds"]["usage_usec"]) / 1_000_000,
              "primary_p50": posting["cycle_latency_seconds"]["p50"], "primary_p95": posting["cycle_latency_seconds"]["p95"],
              "primary_p99": posting["cycle_latency_seconds"]["p99"], "primary_raw_latency_seconds": posting["raw_cycle_latency_seconds"],
              "primary_cgroup_io_delta": io,
              "posting_end_container_lifetime_peak_memory_bytes": after["container_lifetime_peak_memory_bytes"],
              "sample_client_lifetime_peak_rss_bytes": max(row["client_memory"]["process_lifetime_peak_rss_bytes"] for row in samples),
              "sample_client_cpu_seconds_delta": samples[-1]["client_cpu_seconds"] - samples[0]["client_cpu_seconds"],
              "sample_wal_bytes_delta": int(samples[-1]["postgres_wal_counters"]["wal_bytes"]) - int(samples[0]["postgres_wal_counters"]["wal_bytes"]),
              "sample_elapsed_window": [samples[0]["elapsed_seconds"], samples[-1]["elapsed_seconds"]],
              "sample_count": len(samples), "host_processor_observations": [row.get("host_processor") for row in samples],
              "journal_stage_measurements": snapshot["stage_measurements"], "snapshot_original_raw_samples": snapshot["samples"]}
    for stage, row in snapshot["stage_measurements"].items():
        result[f"journal_{stage}_seconds"] = row["seconds"]
        result[f"journal_{stage}_client_cpu_seconds"] = row["client_process_cpu_seconds"]
    result["journal_three_authenticated_stages_seconds"] = sum(row["seconds"] for row in snapshot["stage_measurements"].values())
    result["journal_three_authenticated_stages_client_cpu_seconds"] = sum(row["client_process_cpu_seconds"] for row in snapshot["stage_measurements"].values())
    for label, rows in snapshot["samples"].items():
        result[f"snapshot_{label}_median_seconds"] = statistics.median(row["seconds"] for row in rows)
        result[f"snapshot_{label}_median_client_cpu_seconds"] = statistics.median(row["client_process_cpu_seconds"] for row in rows)
        result[f"snapshot_{label}_median_python_peak_bytes"] = statistics.median(row["peak_python_allocated_bytes"] for row in rows)
        result[f"snapshot_{label}_execute_calls"] = [row["client_execute_calls"] for row in rows]
    return result


def main(args: argparse.Namespace) -> dict:
    need(re.fullmatch(r"[0-9a-f]{64}", args.archive_sha256) is not None and sha(args.archive.read_bytes()) == args.archive_sha256,
         "Separately trusted original artifact ZIP hash differs")
    need(args.extracted.is_dir() and args.review.is_relative_to(OWN) and not args.review.exists(), "Fresh ignored review output required")
    args.review.mkdir()
    driver, helper = module(DRIVER, DRIVER_SHA, "reviewed_large_driver"), module(HELPER, HELPER_SHA, "reviewed_large_oracle")
    resource = module(RAW_RESOURCES, RESOURCE_SHA, "reviewed_original_resource_parser")
    driver.Path = OriginalLinuxPath  # Strict original POSIX comparisons; no original field/source rewrite.
    selected = driver.schedule(False, 3)
    required = {"workflow-source-commit.txt", "pure-contracts.xml", "diagnostics/diagnostics.json"}
    run_files = ("admission.json", "created-container.json", "creation-audit.json", "creation-intent.json", "creation-response.json",
                 "diagnostic.json", "large-journal-ledger.raw.json", "large-journal-ledger-capture.json", "origins.json", "spec.json",
                 "worker-complete.json", "worker.log", "native/migration.log", "native/result.json")
    required |= {f"diagnostics/{name}/{relative}" for _, _, name in selected for relative in run_files}
    with zipfile.ZipFile(args.archive) as archive:
        infos = archive.infolist()
        need(len(infos) == len(required) == 129 and {row.filename for row in infos} == required,
             "Original full nine-run artifact population differs; do not ignore negative/unexpected members")
        need(sum(row.file_size for row in infos) <= 128 * 1024 * 1024, "Bounded original ZIP population required")
        for row in infos:
            need(not row.is_dir() and not row.filename.startswith("/") and "\\" not in row.filename
                 and ".." not in PurePosixPath(row.filename).parts and row.file_size <= 16 * 1024 * 1024, "Unsafe original ZIP member")
            raw = archive.read(row)
            path = args.extracted / row.filename
            need(path.read_bytes() == raw, "Extracted original ZIP member changed")
            MEMBERS[row.filename] = {"sha256": sha(raw), "bytes": len(raw), "extracted": str(path)}
    need((args.extracted / "workflow-source-commit.txt").read_text().strip() == COMMIT, "Actual workflow source header differs")
    suites = ET.parse(args.extracted / "pure-contracts.xml").getroot().findall("testsuite")
    counts = {key: sum(int(row.attrib[key]) for row in suites) for key in ("tests", "failures", "errors", "skipped")}
    need(counts == {"tests": 189, "failures": 0, "errors": 0, "skipped": 0}, "Actual mandatory pure gate differs")
    overall = read(args.extracted / "diagnostics/diagnostics.json")
    need(overall["schema_version"] == "wave5-linux-large-journal-diagnostics-v1" and overall["status"] == "passed"
         and overall["performance_comparison_accepted"] is False and len(overall["runs"]) == 9
         and overall["launcher_sha256"] == DRIVER_SHA and overall["ledger_helper"]["sha256"] == HELPER_SHA,
         "Complete original nine-run status/source/helper contract differs")
    need([row["variant"] for row in overall["runs"]] == [row[1] for row in selected] == overall["selected_run_order"], "Balanced BCP/CPB/PBC order differs")
    need((overall["business_seconds"], overall["child_seconds"], overall["overall_seconds"], overall["cleanup_reserve_seconds"]) == (1200, 1500, 3300, 120), "Original resource deadline contract differs")
    elapsed = (datetime.fromisoformat(overall["finished_at"]) - datetime.fromisoformat(overall["started_at"])).total_seconds()
    need(0 < elapsed < 3300, "Original overall wall bound exceeded")
    need(overall["projection_tree"] == {"reviewed_ancestor": "a4a5282aaf29ff89e182569888877fa606dde6a5", "actual_commit": COMMIT,
         "operational_trees": {"reconforge": "afb58ccb6aaac97662672a6a869dd7ef01558f34", "alembic": "d6332f62681b29c9d825f83344771fab52187c77"}}, "Experimental operational tree changed")
    aggregate, runs, cli_records, previous_end = [], [], [], None
    common = None
    for run, (mode, variant, name) in zip(overall["runs"], selected, strict=True):
        folder = args.extracted / "diagnostics" / name
        need(run["status"] == "passed" and run["mode"] == mode and run["directory"] == name, "Original child admission differs")
        diagnostic = read(folder / "diagnostic.json", run["diagnostic_sha256"])
        packet = read(folder / "native/result.json", diagnostic["original_result_sha256"])
        source = overall["sources"][variant]
        need(source["commit"] == HEADS[variant] and source["git_tree"] == TREES[variant]
             and (variant == "projection" or source["tracked_sha256"] == OLD_LINUX_SHA[variant]), "Original Linux source subject differs")
        need(diagnostic["status"] == "passed" and diagnostic["source_before"] == diagnostic["source_after"] == source
             and diagnostic["performance_comparison_accepted"] is False, "Original clean source/child status differs")
        spec, admission, origins = [read(folder / relative) for relative in ("spec.json", "admission.json", "origins.json")]
        intent, creation, audit, sealed = [read(folder / relative) for relative in ("creation-intent.json", "creation-response.json", "creation-audit.json", "created-container.json")]
        process = diagnostic["process"]
        need(all(value["process"] == process for value in (admission, origins, intent, creation, audit))
             and process["pid"] == process["session"] == process["process_group"] and process["start_ticks"] > 0
             and process["executable"] == overall["python_executable"] and admission["retained_pidfd"] is True, "Original process/admission/session custody differs")
        need(read(folder / "worker-complete.json") == {"exit_code": 0, "origin_status": "passed"}
             and diagnostic["process_cleanup"] == {"status": "verified_exited"}, "Original worker completion/cleanup differs")
        need(creation["intent_sha256"] == MEMBERS[f"diagnostics/{name}/creation-intent.json"]["sha256"]
             and creation["audit_sha256"] == MEMBERS[f"diagnostics/{name}/creation-audit.json"]["sha256"]
             and type(creation["returncode"]) is int and creation["returncode"] == 0, "Original creation seals differ")
        cid = creation["container_id"]
        docker_command = ["docker", "run", "--detach", "--rm", "--name", intent["name"], "--label", driver.OWNER,
                          "-e", "POSTGRES_PASSWORD", "-p", "127.0.0.1::5432", driver.IMAGE,
                          "-c", "join_collapse_limit=8", "-c", "from_collapse_limit=8"]
        command_sha = sha(json.dumps(docker_command, separators=(",", ":")).encode())
        need(audit["status"] == "matched" and audit["command_sha256"] == intent["command_sha256"] == command_sha
             and intent["pre_spawn_exact_name_absent"] is True and intent["image"] == driver.IMAGE
             and intent["label"] == driver.OWNER, "Original typed immutable creation audit differs")
        need(re.fullmatch(r"[a-f0-9]{64}", cid) is not None and sealed["container_id"] == cid
             and sealed["name"] == "/" + intent["name"] and sealed["image"] == driver.IMAGE
             and sealed["cmd"] == ["-c", "join_collapse_limit=8", "-c", "from_collapse_limit=8"]
             and sealed["entrypoint"] == ["docker-entrypoint.sh"] and sealed["auto_remove"] is True
             and sealed["privileged"] is False and sealed["publish_all_ports"] is False and sealed["restart_policy"]["Name"] == "no",
             "Original immutable server configuration differs")
        need(datetime.fromisoformat(sealed["created_at"].replace("Z", "+00:00")) >= datetime.fromisoformat(intent["observed_at"]),
             "Original server predates typed admission")
        for key in ("port_bindings", "actual_ports"):
            bindings = sealed[key]
            need(set(bindings) == {"5432/tcp"} and len(bindings["5432/tcp"]) == 1
                 and bindings["5432/tcp"][0]["HostIp"] == "127.0.0.1", "Original listener is not one loopback binding")
        need(sealed["owner_label"] == driver.OWNER, "Original retained owner label differs")
        need(diagnostic["container_cleanup"] == {"status": "verified_absent", "container_id": cid, "deleted_by_parent": False}, "Original successful exact-ID cleanup differs")
        need(origins["status"] == "passed" and origins["foreign_modules"] == [] and origins["runtime_root"] == source["root"]
             and driver.REQUIRED_MODULES <= {row["module"] for row in origins["origins"]}
             and all(row["path"].startswith(source["root"] + "/") for row in origins["origins"]), "Original source import closure differs")
        harness = overall["sources"]["current"]["root"] + "/.github/scripts/benchmark_enterprise_finance.py"
        args_original = driver.arguments(OriginalLinuxPath(source["root"]), mode, OriginalLinuxPath(spec["directory"] + "/native"))
        retained_aliases = {overall["sources"]["projection"]["root"] + "/.venv/bin/" + name for name in ("python", "python3", "python3.12")}
        # Native command records sys.executable's venv alias; /proc/identity and
        # the top-level admission record retain its physical resolved base.
        # Do not rewrite those different original strings as if identical.
        need(spec["business_args"] == args_original and spec["harness"] == harness and spec["ledger_helper"] == overall["ledger_helper"]
             and packet["command"][0] in retained_aliases and packet["command"][1:] == [harness, *args_original], "Original command/helper/source differs")
        verified = driver.verify_financial(packet, source, mode, packet["command"], OriginalLinuxPath(harness))
        need(verified == diagnostic["verification"], "Original financial/phase/read verifier output differs")
        raw_ledger = folder / "large-journal-ledger.raw.json"
        raw_sha = MEMBERS[f"diagnostics/{name}/large-journal-ledger.raw.json"]["sha256"]
        captured = read(folder / "large-journal-ledger-capture.json")
        ledger = helper.load(raw_ledger)
        internal = helper.verify_export(ledger)
        external = helper.verify_export(ledger, expected_validation_digest=packet["snapshot_reads"]["expected_validation_digest"], expected_revision=packet["revision"])
        need(captured["status"] == "passed" and type(captured["returncode"]) is int and captured["returncode"] == 0
             and captured["container_id"] == cid and captured["source_process"] == process and captured["raw_sha256"] == raw_sha
             and captured["raw_bytes"] == MEMBERS[f"diagnostics/{name}/large-journal-ledger.raw.json"]["bytes"]
             and captured["stderr_bytes"] == 0 and captured["stderr_sha256"] == sha(b"")
             and captured["sql_sha256"] == sha(helper.SQL.encode()) and captured["verification"] == internal,
             "Original readonly native export source/raw/financial custody differs")
        expected_export_command = ["docker", "exec", "--interactive", cid, "psql", "--username", "postgres", "--dbname", "postgres",
                                   "--no-psqlrc", "--quiet", "--tuples-only", "--no-align", "--set", "ON_ERROR_STOP=1"]
        need(captured["command"] == expected_export_command and captured["command_sha256"] == helper.digest(expected_export_command)
             and captured["stdout_sha256"] == raw_sha and captured["stdout_bytes"] == captured["raw_bytes"]
             and captured["credentials_or_environment_captured"] is False, "Original fixed readonly capture command differs")
        need(external == diagnostic["live_ledger_verification"] and external["external_report_anchor"] is True
             and diagnostic["live_ledger_raw_sha256"] == raw_sha, "Original external reviewed seal/revision anchor differs")
        outputs = []
        for flags, label in ((["-I"], "I"), (["-I", "-O"], "IO")):
            destination = args.review / f"{name}-{label}.json"
            command = [sys.executable, *flags, str(HELPER), "--ledger", str(raw_ledger), "--expected-export-sha256", raw_sha,
                       "--expected-validation-digest", packet["snapshot_reads"]["expected_validation_digest"], "--expected-revision", packet["revision"], "--output", str(destination)]
            result = subprocess.run(command, capture_output=True, check=False, timeout=15)
            need(result.returncode == 0 and not result.stderr, "Original isolated readonly ledger CLI failed")
            cli = read(destination)
            need(cli == {**external, "raw_export_sha256": raw_sha, "raw_export_anchor": True}, "Original standalone raw-pinned verification differs")
            outputs.append(destination.read_bytes())
            cli_records.append({"file": str(destination), "sha256": sha(outputs[-1]), "original_raw_sha256": raw_sha, "optimized": label == "IO"})
        need(outputs[0] == outputs[1], "Original normal/optimized oracle output differs")
        config = {key: packet[key] for key in ("python", "platform", "logical_cpus", "architecture", "image", "postgres_version", "postgres_configuration", "runtime_role_flags")}
        common = config if common is None else common
        need(config == common, "Actual runner/workload/DB configuration differs")
        started, ended = [datetime.fromisoformat(packet[key]) for key in ("started_at", "finished_at")]
        need(started < ended and (previous_end is None or previous_end <= started), "Original business windows overlap")
        previous_end = ended
        aggregate.append({"variant": variant, "ledger": external, "container_id": cid, "primary_effect_ids": packet["posting"]["ordered_effect_ids"], "warm_effect_ids": packet["posting_warmup"]["effect_ids"]})
        runs.append({"directory": name, "variant": variant, "source": source, "original_report_sha256": diagnostic["original_result_sha256"],
                     "original_ledger_sha256": raw_sha, "financial": external, "metrics": metrics(packet, resource)})
    population = driver.verify_large_population(aggregate)
    need(population == overall["large_population_verification"] and population["native_effects_including_primary_warm_and_large"] == 1089
         and population["fresh_tenants"] == population["fresh_servers"] == population["large_journals"] == 9, "Original tenant-qualified aggregate differs")
    metric_keys = [key for key, value in runs[0]["metrics"].items() if numeric(value)]
    grouped = {variant: {key: dispersion([row["metrics"][key] for row in runs if row["variant"] == variant]) for key in metric_keys} for variant in HEADS}
    ratios = []
    for repetition in range(1, 4):
        group = {row["variant"]: row["metrics"] for row in runs if row["directory"].startswith(f"large-snapshot-r{repetition}-")}
        ratios.append({"repetition": repetition, "ratio_scope": "same scheduled block, actual raw ratios only; no causal performance acceptance",
                       "current_over_baseline": {key: group["current"][key] / group["baseline"][key] if group["baseline"][key] else None for key in metric_keys},
                       "projection_over_current": {key: group["projection"][key] / group["current"][key] if group["current"][key] else None for key in metric_keys}})
    need(not any(name == "reconforge" or name.startswith("reconforge.") for name in sys.modules), "Reviewer imported application code")
    return {"schema_version": "wave5-large0756-independent-original-file-review-v1", "status": "passed",
            "actual_control_commit": COMMIT, "artifact_zip_sha256": args.archive_sha256, "original_member_count": len(MEMBERS),
            "original_pure_counts": counts, "population": population, "runs": runs, "per_variant_three_independent_run_dispersion": grouped,
            "individual_block_ratios": ratios, "original_standalone_cli_proofs": cli_records, "original_member_index": MEMBERS,
            "cross_platform_path_adapter": "Strict absolute PurePosixPath comparison adapter only; original source and report strings unchanged",
            "performance_comparison_accepted": False, "cost_per_transaction": None,
            "limits": ["File-only original ZIP/hash/source/custody and18 separately pinned stdlib CLI reproductions; no DB/Docker/network/app import or new workload",
                       "Real1000-line GL journals, not1000-line commercial orders, MRP or inventory workloads",
                       "Three authenticated journal stage wall/clientCPU and six snapshot reads are distinct from each100 primary cycles/20warmups",
                       "Run latency percentiles are summarized as three run statistics, never pooled into a new percentile distribution",
                       "Primary cgroup bracketing excludes later big journal and independent export; sampled WAL/I/O spans another window; no per-stage backendCPU/WAL/I/O attribution",
                       "Export follows sampler.stop/final Docker stats; original overall wall includes export/cleanup; those sampled/final resources exclude export",
                       "Linux getrusage/container lifetime peaks include startup/migration/warmup and may precede the big-journal peak; no whole-process-tree/host CPU sum",
                       "No local Windows power or frequency equality is transferred to ephemeral Linux data; host_processor may be unavailable",
                       "Independent admin readonly export is a financial check, not a fresh restricted-role RLS/authorization or complete audit-chain proof",
                       "Normal successful custody is exercised; actual timeout/failure cleanup and new137 backup/restore are not inferred",
                       "Experimental projection is not integrated into frozen PR13122 source; no accepted global superiority, cost or causal performance conclusion"]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", required=True, type=Path)
    parser.add_argument("--archive-sha256", required=True)
    parser.add_argument("--extracted", required=True, type=Path)
    parser.add_argument("--review", required=True, type=Path)
    args = parser.parse_args()
    args.review = args.review.resolve()
    result = main(args)
    destination = args.review / "independent-review.json"
    raw = json.dumps(result, indent=2, allow_nan=False).encode() + b"\n"
    with destination.open("xb") as stream:
        stream.write(raw)
    print(json.dumps({"status": result["status"], "report": str(destination), "sha256": sha(raw), "performance_comparison_accepted": False}))
