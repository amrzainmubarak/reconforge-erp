"""Independent original Linux diagnostics review: stdlib/file-only, no live work."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import math
import statistics
import sys
import zipfile
from datetime import datetime
from pathlib import Path, PurePosixPath

OWN = Path(__file__).resolve().parent
CAPTURE = OWN / "wave5-linux-profile-a6e1f6df-20261012"
FILES = CAPTURE / "profile-artifact"
EXPECTED_ARCHIVE = "95bbf4c977cf0859b30c8a17b650f1d49c948bd6839cbb5ac67df91aa9779b9d"
EXPECTED_INDEX = "8256e2234b761c35094d3d7fd2de38fd9a233392e9bc2ab569d78a5991a5028d"
ACTUAL = "a6e1f6dfed845b5e72de9b681981db92020b03d5"
HEADS = {"baseline": "6362724f2337a79c3d7569574f7bf9591a018524", "current": "22ebfd78e293aafa13d81b3a0bbf287491951115", "projection": ACTUAL}
LINUX_SHA = {"baseline": "d548fb6285681ef8b0105f5279997ef99dc41a05c21269e88dd9f81f0a107345", "current": "acd60e50895d0d3b59af741ed4d36e5f62d98c205f0b48201a9eeb0a7beeba88", "projection": "63d0fded454ac7cbc34bc2acf88695c55a2560d292d1ecf8840900efb6f6e484"}
TREES = {"baseline": "2947b63eff5c07ee58c7f37bd74ef5791fa4605a", "current": "5758db54102719605f88f7048c2e54000c8eaaa2", "projection": "40b5502e4bbf9ec2b4c693f19fe137ed87f1d320"}
FILE_INDEX: dict[str, dict] = {}


def need(condition: object, message: str) -> None:
    if not condition:
        raise ValueError(message)


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def pairs(values: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in values:
        need(key not in result, "Duplicate JSON member")
        result[key] = value
    return result


def read(path: Path, trusted: str | None = None) -> dict:
    raw = path.read_bytes()
    actual = sha(raw)
    need(trusted is None or trusted == actual, "Original file SHA differs")
    FILE_INDEX[str(path)] = {"sha256": actual, "bytes": len(raw)}
    value = json.loads(raw, object_pairs_hook=pairs, parse_constant=lambda _: need(False, "Nonfinite JSON"))
    need(isinstance(value, dict), "Expected JSON object")
    return value


def raw_counters(value: dict) -> dict:
    raw = value["raw"]
    cpu = {a: int(b) for a, b in (line.split() for line in raw["cpu"].splitlines())}
    io = {}
    for line in raw["io"].splitlines():
        device, *words = line.split()
        need(device not in io, "Repeated I/O device")
        io[device] = {key: int(number) for key, number in (word.split("=", 1) for word in words)}
    network = {}
    for line in raw["network"].splitlines():
        if ":" in line:
            interface, values = line.split(":", 1)
            counters = values.split()
            need(len(counters) == 16 and interface.strip() not in network, "Bad network record")
            network[interface.strip()] = {"received_bytes": int(counters[0]), "transmitted_bytes": int(counters[8])}
    result = {"cpu_microseconds": cpu, "memory_current_bytes": int(raw["memory_current"]), "container_lifetime_peak_memory_bytes": int(raw["memory_peak"]), "block_io_by_device": io, "network_by_interface": network}
    need(all(value["parsed"][key] == parsed for key, parsed in result.items()), "Resource parsed/raw mismatch")
    return result


class OriginalLinuxPath(PurePosixPath):
    """Canonical POSIX comparisons only; no host-side filesystem substitution."""

    def resolve(self, *args: object, **kwargs: object) -> OriginalLinuxPath:
        need(self.is_absolute() and ".." not in self.parts, "Noncanonical original Linux path")
        return self


def main() -> dict:
    index = read(CAPTURE / "profile-artifact-index.json", EXPECTED_INDEX)
    archive_path = Path(index["archive"])
    need(sha(archive_path.read_bytes()) == index["archive_sha256"] == EXPECTED_ARCHIVE, "Original profile ZIP differs")
    member_map = {row["member"]: row for row in index["members"]}
    need(len(member_map) == len(index["members"]) == 74, "Missing/duplicate original membership")
    with zipfile.ZipFile(archive_path) as archive:
        need(len(archive.namelist()) == 74 and set(archive.namelist()) == set(member_map), "Extra/missing ZIP member")
        for name, expected in member_map.items():
            need(".." not in Path(name).parts and not name.startswith("/") and "\\" not in name, "Unsafe member name")
            raw = archive.read(name)
            need(len(raw) == expected["bytes"] and sha(raw) == expected["sha256"] and (FILES / name).read_bytes() == raw, "Original/extracted member drift")
            FILE_INDEX[str(FILES / name)] = {"sha256": sha(raw), "bytes": len(raw)}
    need((FILES / "workflow-source-commit.txt").read_text().strip() == ACTUAL, "Actual workflow source header differs")
    overall = read(FILES / "diagnostics/diagnostics.json", "b26bc9281bedb13c45ab23315c6158024abdf5c2e6cb0801bdac9e54334464b0")
    need(overall["status"] == "passed" and overall["performance_comparison_accepted"] is False and len(overall["runs"]) == 6, "Overall diagnostic admission differs")
    need((overall["business_seconds"], overall["child_seconds"], overall["overall_seconds"], overall["cleanup_reserve_seconds"]) == (1200, 1500, 3300, 120), "Bounds changed")
    need((datetime.fromisoformat(overall["finished_at"]) - datetime.fromisoformat(overall["started_at"])).total_seconds() < 3180, "Overall reserved window exceeded")
    oracle_path = OWN / "wave5-experimental-a6e1-peer-custody/originals/0001/benchmark_wave5_profile_diagnostics.py"
    need(sha(oracle_path.read_bytes()) == overall["launcher_sha256"] == "6e48eac82b895dcb5ca73dbb94d963ae526840a391e0848d2557e9d8e81b629f", "Pinned actual original verifier differs")
    spec = importlib.util.spec_from_file_location("independent_original_linux_diagnostic_oracle", oracle_path)
    need(spec is not None and spec.loader is not None, "Original stdlib verifier absent")
    oracle = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(oracle)
    # Original function bytes and report strings are unchanged. Windows Path
    # adds a drive to /home/... on resolve; emulate the retained Linux canonical
    # path comparisons rather than rewrite any original source/report fields.
    oracle.Path = OriginalLinuxPath
    need(not any(name == "reconforge" or name.startswith("reconforge.") for name in sys.modules), "Application import occurred")
    total = sum(1 + int.from_bytes(hashlib.sha256(f"enterprise-native-v1:{i}".encode()).digest()[:8], "big") % 1_000_000 for i in range(100))
    need(total == 46669102, "Independent integer calculation differs")
    order = [(mode, variant) for mode in ("four-worker", "serial-cpu") for variant in HEADS]
    seen_effects, seen_containers, summaries, last_end = set(), set(), [], None
    for row, (mode, variant) in zip(overall["runs"], order, strict=True):
        name = f"{mode}-{variant}"
        directory = FILES / "diagnostics" / name
        need((row["mode"], row["variant"], row["status"]) == (mode, variant, "passed"), "Run order/status differs")
        diagnostic = read(directory / "diagnostic.json", row["diagnostic_sha256"])
        packet = read(directory / "native/result.json", diagnostic["original_result_sha256"])
        source = overall["sources"][variant]
        need(source["commit"] == HEADS[variant] and source["tracked_sha256"] == LINUX_SHA[variant] and source["git_tree"] == TREES[variant], "Original Linux source binding differs")
        need(diagnostic["source_before"] == diagnostic["source_after"] == source and diagnostic["status"] == "passed" and diagnostic["performance_comparison_accepted"] is False, "Source/diagnostic custody failed")
        intent = read(directory / "creation-intent.json")
        seal = read(directory / "creation-response.json")
        audit = read(directory / "creation-audit.json")
        created = read(directory / "created-container.json")
        admission = read(directory / "admission.json")
        origins = read(directory / "origins.json")
        worker = read(directory / "worker-complete.json")
        launch = read(directory / "spec.json")
        process = diagnostic["process"]
        need(process["pid"] == process["session"] == process["process_group"] and process["start_ticks"] > 0 and process["executable"] == overall["python_executable"], "Actual retained session identity differs")
        need(intent["process"] == seal["process"] == audit["process"] == admission["process"] == origins["process"] == process and admission["retained_pidfd"] is True, "Process birth/admission/origin custody differs")
        need(worker == {"exit_code": 0, "origin_status": "passed"} and diagnostic["process_cleanup"] == {"status": "verified_exited"}, "Worker cleanup failed")
        need(seal["intent_sha256"] == FILE_INDEX[str(directory / "creation-intent.json")]["sha256"] and seal["audit_sha256"] == FILE_INDEX[str(directory / "creation-audit.json")]["sha256"] and seal["returncode"] == 0, "Original creation seals differ")
        cid = seal["container_id"]
        need(len(cid) == 64 and all(c in "0123456789abcdef" for c in cid) and cid not in seen_containers, "Container ID invalid/reused")
        seen_containers.add(cid)
        expected_options = (["-c", "shared_preload_libraries=pg_stat_statements", "-c", "pg_stat_statements.track=all", "-c", "pg_stat_statements.track_planning=on", "-c", "track_io_timing=on"] if mode == "four-worker" else []) + ["-c", "join_collapse_limit=8", "-c", "from_collapse_limit=8"]
        docker_command = ["docker", "run", "--detach", "--rm", "--name", intent["name"], "--label", oracle.OWNER, "-e", "POSTGRES_PASSWORD", "-p", "127.0.0.1::5432", oracle.IMAGE, *expected_options]
        need(sha(json.dumps(docker_command, separators=(",", ":")).encode()) == intent["command_sha256"] == audit["command_sha256"] and audit["status"] == "matched" and intent["pre_spawn_exact_name_absent"] is True, "Actual typed creation audit differs")
        need(created["container_id"] == cid and created["name"] == "/" + intent["name"] and created["image"] == oracle.IMAGE and created["cmd"] == expected_options and created["entrypoint"] == ["docker-entrypoint.sh"] and created["auto_remove"] is True and created["privileged"] is False and created["publish_all_ports"] is False and created["restart_policy"]["Name"] == "no", "Immutable container config differs")
        need(datetime.fromisoformat(created["created_at"].replace("Z", "+00:00")) >= datetime.fromisoformat(intent["observed_at"]), "Container predates admission")
        for bindings in (created["port_bindings"], created["actual_ports"]):
            need(set(bindings) == {"5432/tcp"} and len(bindings["5432/tcp"]) == 1 and bindings["5432/tcp"][0]["HostIp"] == "127.0.0.1", "Owned listener boundary differs")
        need(diagnostic["container_cleanup"] == {"status": "verified_absent", "container_id": cid, "deleted_by_parent": False}, "Normal exact-ID cleanup failed")
        need(origins["status"] == "passed" and origins["foreign_modules"] == [] and origins["runtime_root"] == source["root"] and origins["harness_sha256_after"] == oracle.HARNESS_SHA and oracle.REQUIRED_MODULES <= {r["module"] for r in origins["origins"]}, "Tracked runtime origins fail closure")
        need(all(r["path"].startswith(source["root"] + "/") for r in origins["origins"]), "Foreign source origin")
        harness_path = overall["sources"]["current"]["root"] + "/.github/scripts/benchmark_enterprise_finance.py"
        expected_args = ["--counts", "100", "--workers", str(oracle.MODES[mode][0]), "--repetitions", "3", "--posting-warmup", "20", "--max-seconds", "1200", "--runtime-root", source["root"], "--postgres-image", oracle.IMAGE, "--snapshot-lines", "0", *oracle.MODES[mode][1], "--output", launch["directory"] + "/native"]
        need(launch["business_args"] == expected_args and launch["harness"] == harness_path and launch["launcher_sha256"] == overall["launcher_sha256"] and packet["command"][1:] == [harness_path, *expected_args], "Original business command differs")
        reproduced = oracle.verify_financial(packet, source, mode, packet["command"], OriginalLinuxPath(harness_path).resolve())
        need(reproduced == diagnostic["verification"], "Pinned original oracle output differs")
        effects = packet["posting"]["ordered_effect_ids"] + packet["posting_warmup"]["effect_ids"]
        need(len(effects) == len(set(effects)) == 120 and not set(effects) & seen_effects, "Fresh effect population reused")
        seen_effects.update(effects)
        start, end = [datetime.fromisoformat(packet[key]) for key in ("started_at", "finished_at")]
        need(start < end and (last_end is None or last_end <= start), "Run intervals overlap")
        last_end = end
        before, after = [raw_counters(packet[key]) for key in ("posting_container_counters_before", "posting_container_counters_after")]
        io = {key: sum(value[key] for value in after["block_io_by_device"].values()) - sum(value[key] for value in before["block_io_by_device"].values()) for key in ("rbytes", "wbytes", "rios", "wios", "dbytes", "dios")}
        network = {key: sum(value[key] for value in after["network_by_interface"].values()) - sum(value[key] for value in before["network_by_interface"].values()) for key in ("received_bytes", "transmitted_bytes")}
        samples = packet["resource_sampling"]["raw_samples"]
        phases = reproduced["measured_phases"]
        thread_totals = {part: sum(values["thread_cpu_seconds_sum"] for key, values in phases.items() if key.endswith("." + part)) for part in ("identity_enter", "business", "transaction_exit")}
        posting = packet["posting"]
        need(posting["native_postings_per_second"] == 100 / posting["seconds"] and posting["seconds"] > 0 and math.isfinite(posting["client_process_cpu_seconds"]), "Reported native throughput/CPU differs")
        statements = packet.get("posting_database_profile", {}).get("statements", [])
        if mode == "four-worker":
            need(len(statements) <= 200 and all(r["total_plan_ms"] >= 0 and r["total_exec_ms"] >= 0 and len(r["statement_sha256"]) == 64 for r in statements), "Query-profile contract differs")
        metrics = {"posting_seconds": posting["seconds"], "throughput": 100 / posting["seconds"], **posting["cycle_latency_seconds"], "posting_client_cpu_seconds": posting["client_process_cpu_seconds"], "dedicated_container_cpu_seconds": (after["cpu_microseconds"]["usage_usec"] - before["cpu_microseconds"]["usage_usec"]) / 1_000_000, "client_lifetime_peak_rss_bytes": max(s["client_memory"]["process_lifetime_peak_rss_bytes"] for s in samples), "container_lifetime_peak_memory_bytes": after["container_lifetime_peak_memory_bytes"], "sample_wal_bytes_delta": int(samples[-1]["postgres_wal_counters"]["wal_bytes"]) - int(samples[0]["postgres_wal_counters"]["wal_bytes"]), "sample_client_cpu_seconds_delta": samples[-1]["client_cpu_seconds"] - samples[0]["client_cpu_seconds"], "cgroup_io_delta": io, "cgroup_network_delta": network, "measured_phase_thread_cpu_seconds": thread_totals, "identity_fraction_of_measured_phase_thread_CPU": thread_totals["identity_enter"] / sum(thread_totals.values()), "query_profile_rows": len(statements), "sample_count": len(samples), "sample_elapsed_window": [samples[0]["elapsed_seconds"], samples[-1]["elapsed_seconds"]]}
        summaries.append({"mode": mode, "variant": variant, "original_result_sha256": diagnostic["original_result_sha256"], "source": source, "normal_custody_and_original_oracle": "passed", "metrics": metrics, "financial": reproduced, "native_function_profile": {k: v for k, v in packet["posting_profile"]["function_profile"].items() if k != "functions"}, "sample_scope": "Linux getrusage lifetime peak RSS, not sampled current RSS; cgroup/sample windows differ", "query_timing_scope": "nested and top-level pg_stat_statements timings overlap; no summation into wall/backend CPU"})
    need(len(seen_effects) == 720 and len(seen_containers) == 6, "Overall fresh population differs")
    return {"schema_version": "wave5-linux-a6e1-original-independent-file-review-v1", "status": "passed", "artifact_zip_sha256": EXPECTED_ARCHIVE, "original_member_count": 74, "sources": overall["sources"], "actual_projection_commit": ACTUAL, "original_oracle_sha256": overall["launcher_sha256"], "pinned_original_oracle_replay": "all6 exact original verification outputs reproduced; stdlib only", "cross_platform_path_adapter": "Pinned original function bytes and report strings are unchanged; strict absolute PurePosixPath comparisons emulate retained Linux canonical path semantics on Windows. No source/report rewrite or host-side Linux filesystem assertion.", "counts": {"measured_cycles": 600, "outside_measured_warmup_cycles": 120, "fresh_effects": 720, "fresh_owned_containers": 6, "verified_read_requests": 1818, "phase_observations": 6480}, "oracle_minor_per100_cycle_population": str(total), "runs": summaries, "performance_comparison_accepted": False, "cost_per_success_currency": None, "limits": ["File-only original74-member/source/financial/normal-custody review; no runtime imports, DB, Docker, network or new workload.", "Ephemeral Linux Python3.12.15 fingerprints are retained independently; do not substitute Windows fingerprints or published22 for actual experimental a6.", "One100-cycle observation per mode/source with instrumentation, fixedB/C/P order; no3repeat fair comparison, accepted speed/resource improvement or causal regression estimate.", "Measured identity-enter thread CPU includes connection/KDF/scope/permissions; not pureKDF CPU. Wall phases overlap across workers; cProfile wall contains blocking/I/O and at most32 serial cycles.", "Nested and top-level pg_stat_statements timings overlap; raw query metrics do not establish backendCPU, lock causal attribution or wall sums.", "Distinct posting processCPU/cgroup bracketing/sample windows are never summed; lifetime getrusage/cgroup peaks include setup/migration/warmup; no sampled-current-clientRSS or whole-host cost.", "Only normal successful retained-process/CID custody was exercised by these6 runs; timeout/group-termination fallback is source/pure-test reviewed, not actual exercised failure recovery.", "Current137 populated migration/rollback has separate native evidence; these profiles do not establish137 backup/restore or complete final acceptance."], "original_file_index": FILE_INDEX}


if __name__ == "__main__":
    destination = Path(sys.argv[1]).resolve()
    need(destination.parent == OWN and not destination.exists(), "Fresh ignored review output required")
    result = main()
    raw = (json.dumps(result, indent=2, ensure_ascii=True, allow_nan=False) + "\n").encode()
    with destination.open("xb") as stream:
        stream.write(raw)
    print(json.dumps({"status": result["status"], "path": str(destination), "sha256": sha(raw), "performance_comparison_accepted": False}))
