# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: intercompany-operations-cycles.spec.ts >> real atomic paired partial cash native elimination and bilingual three-book evidence
- Location: apps\web\live\intercompany-operations-cycles.spec.ts:43:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('form', { name: 'Prepare paired service charge', exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByRole('form', { name: 'Prepare paired service charge', exact: true })

```

```yaml
- link "Skip to main content":
  - /url: "#main-content"
- complementary:
  - strong: ReconForge
  - text: Studio
  - group:
    - text: FC
    - strong: Intercompany operations
    - text: Live session
  - navigation "Primary navigation":
    - paragraph: ERP operations
    - button "Finance & reporting"
    - button "Financial statements"
    - button "Fixed assets"
    - button "Manufacturing execution"
    - button "Intercompany operations"
    - button "Procurement sourcing"
    - button "Customer returns"
    - button "Currency & tax"
    - button "Product sales"
    - button "Partial procurement"
    - button "Sales & revenue"
    - button "Procurement & payments"
    - paragraph: Overview
    - button "Dashboard"
    - paragraph: Finance controls
    - button "Receivables"
    - button "Budget control"
    - link "Reconciliation Foundation":
      - /url: http://127.0.0.1:8601/reconciliation
    - button "Exceptions Foundation"
    - button "Evidence binder Foundation"
    - link "Month-end close Foundation":
      - /url: http://127.0.0.1:8601/close
    - button "Retail settlement Foundation"
    - button "Bank reconciliation Foundation"
    - button "Professional invoice / payment Foundation"
    - button "Individual cashflow Foundation"
    - paragraph: Operations
    - button "Inventory controls Foundation"
    - button "Inventory receipts"
    - button "Manufacturing cost control Foundation"
    - paragraph: Platform
    - link "Reports Foundation":
      - /url: http://127.0.0.1:8601/downloads
    - link "Control packs Foundation":
      - /url: http://127.0.0.1:8601/control-packs
    - button "Mapping Studio Foundation"
    - button "Rule Studio Foundation"
    - button "Live Studio Foundation"
    - button "Administration audit Foundation"
    - button "Notifications Foundation"
    - button "Durable jobs"
    - button "Settings Planned" [disabled]
    - link "Developer console Foundation":
      - /url: http://127.0.0.1:8601/docs
  - strong: Live session
  - text: Intercompany operations
  - button "Collapse sidebar"
- banner:
  - text: Finance controls
  - strong: Intercompany operations
  - button "Search controls, pages, or actions": Search controls, pages, or actions K
  - button "Switch language": AR
  - 'button "Theme: System"'
  - button "Accessibility"
  - strong: browser-maker
  - text: Live session
- main:
  - heading "Intercompany operations" [level=1]
  - paragraph: Explicit three-book management reporting; one currency. No legal ownership, tax or statutory consolidation assertion.
  - alert: The request or retained evidence could not be verified. Refresh the current state.
  - paragraph:
    - text: browser-maker
    - button "Sign out"
  - form "Organization scope":
    - text: Workspace ID
    - textbox "Workspace ID": work
    - text: Organization ID
    - textbox "Organization ID": org
    - button "Apply scope"
```

# Test source

```ts
  1   | import AxeBuilder from "@axe-core/playwright";
  2   | import { expect, test, type Page } from "@playwright/test";
  3   | 
  4   | const base = process.env.RECONFORGE_ERP_LIVE_URL, tenant = process.env.RECONFORGE_ERP_TENANT, password = process.env.RECONFORGE_ERP_PASSWORD;
  5   | const root = "/api/v1/intercompany-operations";
  6   | async function login(page: Page, username: string) {
  7   |   await page.goto(`${base}/admin-audit`);
  8   |   await page.getByLabel("Tenant ID", { exact: true }).fill(tenant!);
  9   |   await page.getByLabel("Username", { exact: true }).fill(username);
  10  |   await page.getByLabel("Password", { exact: true }).fill(password!);
  11  |   await page.getByRole("button", { name: "Sign in to administration", exact: true }).click();
  12  |   await expect(page.getByRole("heading", { name: "Confirm privileged access", exact: true })).toBeVisible();
  13  |   await page.getByLabel("Password", { exact: true }).fill(password!);
  14  |   const response = page.waitForResponse(reply => reply.url().endsWith("/auth/step-up"));
  15  |   await page.getByRole("button", { name: "Confirm and continue", exact: true }).click();
  16  |   expect((await response).status()).toBe(200);
  17  | }
  18  | async function enter(page: Page, sourceId = "") {
  19  |   await page.getByRole("navigation", { name: "Primary navigation" }).getByRole("button", { name: "Intercompany operations", exact: true }).click();
  20  |   await expect(page.getByRole("heading", { name: "Intercompany operations", exact: true })).toBeVisible();
  21  |   const form = page.getByRole("form", { name: "Organization scope", exact: true });
  22  |   for (const [label, value] of Object.entries({ "Workspace ID": "work", "Organization ID": "org" })) {
  23  |     await expect(form.getByLabel(label, { exact: true })).toBeEnabled();
  24  |     await form.getByLabel(label, { exact: true }).fill(value);
  25  |     await expect(form.getByLabel(label, { exact: true })).toHaveValue(value);
  26  |   }
  27  |   await form.getByRole("button", { name: "Apply scope", exact: true }).click();
> 28  |   await expect(page.getByRole("form", { name: "Prepare paired service charge", exact: true })).toBeVisible();
      |                                                                                                ^ Error: expect(locator).toBeVisible() failed
  29  |   if (sourceId) {
  30  |     await page.getByRole("combobox", { name: "Retained sources", exact: true }).selectOption(sourceId);
  31  |     await expect(page.getByRole("heading", { name: "BROWSER-IC1", exact: true })).toBeVisible();
  32  |   }
  33  | }
  34  | async function phase(page: Page, sourceId: string, planId: string, operation: "review" | "post") {
  35  |   await login(page, operation === "review" ? "browser-checker" : "browser-poster"); await enter(page, sourceId);
  36  |   const region = page.getByRole("region", { name: "Native operation", exact: true });
  37  |   await region.getByLabel("Reason", { exact: true }).fill(`Actual independent native ${operation}`);
  38  |   const reply = page.waitForResponse(response => response.url().endsWith(`${root}/plans/${planId}/${operation}`) && response.request().method() === "POST");
  39  |   await region.getByRole("button", { name: operation === "review" ? "Review every native entry" : "Post whole native operation", exact: true }).click();
  40  |   const response = await reply; expect(response.status(), await response.text()).toBe(200); return (await response.json()).plan;
  41  | }
  42  | 
  43  | test("real atomic paired partial cash native elimination and bilingual three-book evidence", async ({ page }) => {
  44  |   test.setTimeout(300_000);
  45  |   expect(base && tenant && password && process.env.RECONFORGE_ERP_BROWSER_ARTIFACTS, "Owned HTTPS native fixture must be supplied").toBeTruthy();
  46  |   await login(page, "browser-maker"); await enter(page);
  47  |   const form = page.getByRole("form", { name: "Prepare paired service charge", exact: true });
  48  |   for (const [label, value] of Object.entries({ "Source reference": "BROWSER-IC1", "Original minor units": "10001", "Posting date": "2026-10-03", Reason: "Actual paired original service charge" })) await form.getByLabel(label, { exact: true }).fill(value);
  49  |   for (const [label, value] of Object.entries({ "Seller entity": "entity", "Buyer entity": "buyer", "Group adjustment scope": "group", "Fiscal period": "period", "Native journal": "STOCK", "IC receivable account": "IC_AR", "IC payable account": "IC_AP", "IC income account": "IC_REVENUE", "IC expense account": "IC_EXPENSE", "Cash account": "CASH" })) await form.getByRole("combobox", { name: label, exact: true }).selectOption(value);
  50  |   let lost: unknown = null, commandId = "";
  51  |   await page.route(`**${root}/sources`, async route => {
  52  |     if (route.request().method() !== "POST") { await route.continue(); return; }
  53  |     commandId = route.request().postDataJSON().command_id;
  54  |     const response = await route.fetch(); expect(response.status(), await response.text()).toBe(200); lost = (await response.json()).plan;
  55  |     await route.abort("failed");
  56  |   }, { times: 1 });
  57  |   await form.getByRole("button", { name: "Prepare paired service charge", exact: true }).click();
  58  |   await expect(page.getByRole("button", { name: "Retry unchanged command", exact: true })).toBeVisible();
  59  |   const retried = page.waitForResponse(response => response.url().endsWith(`${root}/sources`) && response.request().method() === "POST");
  60  |   await page.getByRole("button", { name: "Retry unchanged command", exact: true }).click();
  61  |   const retry = await retried; expect(retry.status(), await retry.text()).toBe(200); let plan = (await retry.json()).plan;
  62  |   expect(plan).toEqual(lost); expect(commandId).not.toBe(""); expect(retry.request().postDataJSON().command_id).toBe(commandId);
  63  |   const sourceId = plan.source_id, effects: string[] = [];
  64  |   for (let stage = 0; stage < 3; stage++) {
  65  |     plan = await phase(page, sourceId, plan.id, "review"); plan = await phase(page, sourceId, plan.id, "post");
  66  |     expect(plan.status).toBe("Posted"); expect(plan.amount_minor).toBe(["10001", "3000", "17002"][stage]);
  67  |     await expect(page.getByRole("region", { name: "Native operation", exact: true }).getByRole("heading", { name: "Native operation · Posted", exact: true })).toBeVisible();
  68  |     const replied = page.waitForResponse(response => response.url().endsWith(`${root}/plans/${plan.id}/evidence`) && response.request().method() === "GET");
  69  |     await page.getByRole("button", { name: "Verify canonical native evidence", exact: true }).click();
  70  |     const actual = await replied; expect(actual.status(), await actual.text()).toBe(200); const evidence = (await actual.json()).evidence;
  71  |     expect(evidence.source.request.amount_minor).toBe("10001"); expect(evidence.plan.plan_digest).toBe(plan.plan_digest);
  72  |     expect(evidence.phases.map((row: { actor_id: string }) => row.actor_id)).toEqual(["erp-maker", "erp-checker", "erp-poster"]);
  73  |     expect(new Set(evidence.phases.map((row: { audit_event_id: string }) => row.audit_event_id)).size).toBe(3);
  74  |     expect(new Set(evidence.phases.map((row: { outbox_event_id: string }) => row.outbox_event_id)).size).toBe(3);
  75  |     expect(evidence.native_effects).toHaveLength(stage === 2 ? 1 : 2);
  76  |     for (const [index, native] of evidence.native_effects.entries()) {
  77  |       const entry = plan.entries[index]; expect(native.id).toBe(plan.posting_effect_ids[entry.book]); expect(native.entry_id).toBe(entry.entry_id);
  78  |       expect(native.validation_digest).toBe(entry.validation_digest); expect(native.posted_actor_id).toBe("erp-poster");
  79  |       expect(native.audit_event_id).toBeTruthy(); expect(native.outbox_event_id).toBeTruthy(); effects.push(native.id);
  80  |     }
  81  |     await expect(page.getByRole("status").filter({ hasText: "Verified original source, plan and native seals" })).toBeVisible();
  82  |     const download = page.waitForEvent("download"); await page.getByRole("button", { name: "Download verified evidence", exact: true }).click();
  83  |     await (await download).saveAs(`${process.env.RECONFORGE_ERP_BROWSER_ARTIFACTS}/ic-proof-${stage}.json`);
  84  |     if (stage === 2) break;
  85  |     await login(page, "browser-maker"); await enter(page, sourceId);
  86  |     const label = stage === 0 ? "Prepare paired cash settlement" : "Prepare final group adjustment";
  87  |     const progress = page.getByRole("form", { name: label, exact: true });
  88  |     if (stage === 0) await progress.getByLabel("Cash installment minor units", { exact: true }).fill("3000");
  89  |     await progress.getByLabel("Posting date", { exact: true }).fill(stage === 0 ? "2026-10-04" : "2026-10-05");
  90  |     await progress.getByLabel("Reason", { exact: true }).fill("Actual reviewed paired cash and final group adjustment");
  91  |     await progress.getByRole("combobox", { name: "Fiscal period", exact: true }).selectOption("period");
  92  |     const prepared = page.waitForResponse(response => response.url().endsWith(`${root}/sources/${sourceId}/${stage === 0 ? "settlements" : "eliminations"}`) && response.request().method() === "POST");
  93  |     await progress.getByRole("button", { name: label, exact: true }).click();
  94  |     const response = await prepared; expect(response.status(), await response.text()).toBe(200); plan = (await response.json()).plan;
  95  |   }
  96  |   expect(new Set(effects).size).toBe(5);
  97  |   const reporting = page.getByRole("form", { name: "Verify consolidated native report", exact: true });
  98  |   for (const label of ["Reviewed seller map", "Reviewed buyer map", "Reviewed group map"]) await reporting.getByRole("combobox", { name: label, exact: true }).selectOption({ index: 1 });
  99  |   await reporting.getByRole("combobox", { name: "Fiscal period", exact: true }).selectOption("period");
  100 |   await reporting.getByLabel("Reporting cutoff", { exact: true }).fill("2026-10-05");
  101 |   const reported = page.waitForResponse(response => response.url().includes(`${root}/sources/${sourceId}/report?`) && response.request().method() === "GET");
  102 |   await reporting.getByRole("button", { name: "Verify consolidated native report", exact: true }).click();
  103 |   const actualReport = await reported; expect(actualReport.status(), await actualReport.text()).toBe(200); const report = (await actualReport.json()).report;
  104 |   expect(report.effect_count).toBe(5);
  105 |   expect([...new Set(report.trial_balance.flatMap((row: { postings: { effect_id: string }[] }) => row.postings.map(line => line.effect_id)))].sort()).toEqual(effects.slice().sort());
  106 |   expect(report.trial_balance.every((row: { closing: { balance_minor: string } }) => row.closing.balance_minor === "0")).toBe(true);
  107 |   expect(report.income_statement).toEqual({ income_minor: "0", expense_minor: "0", result_minor: "0" });
  108 |   expect(report.cash_net_movements).toEqual({ opening_minor: "0", activity_minor: "0", closing_minor: "0" });
  109 |   await expect(page.getByRole("status").filter({ hasText: "Verified three-book native report" })).toBeVisible();
  110 |   const reportDownload = page.waitForEvent("download"); await page.getByRole("button", { name: "Download verified group report", exact: true }).click();
  111 |   await (await reportDownload).saveAs(`${process.env.RECONFORGE_ERP_BROWSER_ARTIFACTS}/ic-group-report.json`);
  112 |   await page.setViewportSize({ width: 390, height: 844 });
  113 |   await page.getByRole("button", { name: "Switch language", exact: true }).click();
  114 |   await expect(page.getByRole("heading", { name: "عمليات الشركات المرتبطة", exact: true })).toBeVisible();
  115 |   const arabicScope = page.getByRole("form", { name: "نطاق المؤسسة", exact: true });
  116 |   await expect(arabicScope.getByRole("button", { name: "تطبيق النطاق", exact: true })).toBeEnabled();
  117 |   await arabicScope.getByRole("button", { name: "تطبيق النطاق", exact: true }).click();
  118 |   await page.getByRole("combobox", { name: "المصادر المحفوظة", exact: true }).selectOption(sourceId);
  119 |   await expect(page.getByRole("heading", { name: "BROWSER-IC1", exact: true })).toBeVisible();
  120 |   await page.getByRole("button", { name: "التحقق من أدلة القيود الأصلية", exact: true }).click();
  121 |   await expect(page.getByRole("status").filter({ hasText: "تم التحقق من أختام المصدر والخطة والقيود" })).toBeVisible();
  122 |   const arabicDownload = page.waitForEvent("download"); await page.getByRole("button", { name: "تنزيل الأدلة المتحقق منها", exact: true }).click();
  123 |   await (await arabicDownload).saveAs(`${process.env.RECONFORGE_ERP_BROWSER_ARTIFACTS}/ic-proof-ar-mobile.json`);
  124 |   expect((await new AxeBuilder({ page }).include("#main-content").withTags(["wcag2a", "wcag2aa", "wcag21aa"]).analyze()).violations).toEqual([]);
  125 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  126 |   await page.screenshot({ path: `${process.env.RECONFORGE_ERP_BROWSER_ARTIFACTS}/ic-ar-mobile.png`, fullPage: true });
  127 | });
  128 | 
```