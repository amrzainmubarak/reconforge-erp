# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: manufacturing-execution-cycles.spec.ts >> actual versioned BOM native material WIP partial FG scrap cancelled draft and lost ACK
- Location: apps\web\live\manufacturing-execution-cycles.spec.ts:54:1

# Error details

```
Error: expect(locator).toBeEnabled() failed

Locator: getByRole('form', { name: 'Apply scope', exact: true }).getByLabel('Workspace ID', { exact: true })
Expected: enabled
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeEnabled" with timeout 5000ms
  - waiting for getByRole('form', { name: 'Apply scope', exact: true }).getByLabel('Workspace ID', { exact: true })

```

```yaml
- link "Skip to main content":
  - /url: "#main-content"
- complementary:
  - strong: ReconForge
  - text: Studio
  - group:
    - text: FC
    - strong: Manufacturing execution
    - text: Live session
  - navigation "Primary navigation":
    - paragraph: ERP operations
    - button "Finance & reporting"
    - button "Financial statements"
    - button "Fixed assets"
    - button "Manufacturing execution"
    - button "Intercompany operations"
    - button "Procurement sourcing"
    - button "Customer returns"
    - button "Currency & tax"
    - button "Product sales"
    - button "Partial procurement"
    - button "Sales & revenue"
    - button "Procurement & payments"
    - paragraph: Overview
    - button "Dashboard"
    - paragraph: Finance controls
    - button "Receivables"
    - button "Budget control"
    - link "Reconciliation Foundation":
      - /url: http://127.0.0.1:8601/reconciliation
    - button "Exceptions Foundation"
    - button "Evidence binder Foundation"
    - link "Month-end close Foundation":
      - /url: http://127.0.0.1:8601/close
    - button "Retail settlement Foundation"
    - button "Bank reconciliation Foundation"
    - button "Professional invoice / payment Foundation"
    - button "Individual cashflow Foundation"
    - paragraph: Operations
    - button "Inventory controls Foundation"
    - button "Inventory receipts"
    - button "Manufacturing cost control Foundation"
    - paragraph: Platform
    - link "Reports Foundation":
      - /url: http://127.0.0.1:8601/downloads
    - link "Control packs Foundation":
      - /url: http://127.0.0.1:8601/control-packs
    - button "Mapping Studio Foundation"
    - button "Rule Studio Foundation"
    - button "Live Studio Foundation"
    - button "Administration audit Foundation"
    - button "Notifications Foundation"
    - button "Durable jobs"
    - button "Settings Planned" [disabled]
    - link "Developer console Foundation":
      - /url: http://127.0.0.1:8601/docs
  - strong: Live session
  - text: Manufacturing execution
  - button "Collapse sidebar"
- banner:
  - text: Finance controls
  - strong: Manufacturing execution
  - button "Search controls, pages, or actions": Search controls, pages, or actions K
  - button "Switch language": AR
  - 'button "Theme: System"'
  - button "Accessibility"
  - strong: Signed out
  - text: Live session
- main:
  - heading "Actual manufacturing execution" [level=1]
  - paragraph: Versioned base-UOM recipes, whole component issue, native WIP, partial finished output and explicit abnormal material scrap. One functional currency; no routing, labor, overhead or MRP.
  - paragraph: An independent BOM approver and three distinct authorized humans for each material issue or output posting.
  - form "Sign in":
    - text: Tenant
    - textbox "Tenant": local
    - text: Username
    - textbox "Username"
    - text: Password
    - textbox "Password"
    - button "Sign in"
```

# Test source

```ts
  1  | import { expect, test, type Page, type Locator } from "@playwright/test";
  2  | import AxeBuilder from "@axe-core/playwright";
  3  | const base = process.env.RECONFORGE_ERP_LIVE_URL, tenant = process.env.RECONFORGE_ERP_TENANT, password = process.env.RECONFORGE_ERP_PASSWORD;
  4  | const root = "/manufacturing-execution";
  5  | async function login(page: Page, username: string) {
  6  |   await page.goto(`${base}/admin-audit`);
  7  |   for (const [label, value] of Object.entries({ "Tenant ID": tenant!, Username: username, Password: password! })) await page.getByLabel(label, { exact: true }).fill(value);
  8  |   await page.getByRole("button", { name: "Sign in to administration", exact: true }).click();
  9  |   await expect(page.getByRole("heading", { name: "Confirm privileged access", exact: true })).toBeVisible();
  10 |   await page.getByLabel("Password", { exact: true }).fill(password!);
  11 |   const response = page.waitForResponse(reply => reply.url().endsWith("/auth/step-up"));
  12 |   await page.getByRole("button", { name: "Confirm and continue", exact: true }).click(); expect((await response).status()).toBe(200);
  13 | }
  14 | async function enter(page: Page, order = "", child = "", bom = "") {
  15 |   await page.goto(`${base}${root}`);
  16 |   await expect(page.getByRole("heading", { name: "Actual manufacturing execution", exact: true })).toBeVisible();
  17 |   const form = page.getByRole("form", { name: "Apply scope", exact: true });
> 18 |   for (const [label, value] of Object.entries({ "Workspace ID": "work", "Organization ID": "org", "Legal entity ID": "entity" })) { const field = form.getByLabel(label, { exact: true }); await expect(field).toBeEnabled(); await field.fill(value); }
     |                                                                                                                                                                                                                ^ Error: expect(locator).toBeEnabled() failed
  19 |   for (const [label, value] of Object.entries({ "Workspace ID": "work", "Organization ID": "org", "Legal entity ID": "entity" })) await expect(form.getByLabel(label, { exact: true })).toHaveValue(value);
  20 |   const response = page.waitForResponse(reply => reply.url().endsWith(`${root}/orders`) && reply.request().method() === "GET");
  21 |   await form.getByRole("button", { name: "Apply scope", exact: true }).click(); expect((await response).status()).toBe(200);
  22 |   if (bom) await page.getByRole("combobox", { name: "Retained BOM version", exact: true }).selectOption(bom);
  23 |   if (order) { await page.getByRole("combobox", { name: "Retained production order", exact: true }).selectOption(order); await expect(page.getByRole("region", { name: "Original production and native financial evidence", exact: true })).toBeVisible(); }
  24 |   if (child) await page.getByRole("combobox", { name: "Retained output disposition", exact: true }).selectOption(child);
  25 | }
  26 | async function fill(form: Locator, values: Record<string, string>) { for (const [label, value] of Object.entries(values)) await form.getByLabel(label, { exact: true }).fill(value); }
  27 | async function command(page: Page, form: Locator, name: string, path: string, key: "bom" | "order" | "completion", lose = false) {
  28 |   let retained: unknown, body = "", finish!: () => void;
  29 |   const committed = new Promise<void>(resolve => { finish = resolve; });
  30 |   if (lose) await page.route(`**/api/v1${path}`, async route => { if (route.request().method() !== "POST") { await route.continue(); return; } body = route.request().postData()!; const reply = await route.fetch(); expect(reply.status(), await reply.text()).toBe(200); retained = (await reply.json())[key]; await route.abort("failed"); finish(); }, { times: 1 });
  31 |   const response = lose ? null : page.waitForResponse(reply => reply.url().endsWith(path) && reply.request().method() === "POST");
  32 |   await form.getByRole("button", { name, exact: true }).click();
  33 |   if (lose) {
  34 |     await committed; const retry = page.getByRole("button", { name: "Retry retained command", exact: true }); await expect(retry).toBeVisible();
  35 |     const response = page.waitForResponse(reply => reply.url().endsWith(path) && reply.request().method() === "POST"); await retry.click();
  36 |     const reply = await response; expect(reply.status(), await reply.text()).toBe(200); expect(reply.request().postData()).toBe(body);
  37 |     const actual = (await reply.json())[key]; expect(actual).toEqual(retained); return actual;
  38 |   }
  39 |   const reply = await response!; expect(reply.status(), await reply.text()).toBe(200); return (await reply.json())[key];
  40 | }
  41 | async function phase(page: Page, order: string, action: "prepare" | "review" | "post" | "cancel", child = "", lose = false) {
  42 |   await login(page, action === "prepare" ? "browser-maker" : action === "review" ? "browser-checker" : "browser-poster"); await enter(page, order, child);
  43 |   const region = page.getByRole("region", { name: "Original production and native financial evidence", exact: true });
  44 |   await region.getByLabel("Reason", { exact: true }).fill(`Actual independent ${action}`);
  45 |   const name = { prepare: "Prepare original FIFO material issue", review: "Review complete native source", post: "Post complete native effects", cancel: "Cancel unposted source" }[action];
  46 |   return command(page, region, name, `${root}/${child ? "completions/" + child : "orders/" + order}/${action}`, child ? "completion" : "order", lose);
  47 | }
  48 | async function partial(page: Page, order: string, good: string, scrap: string, lose = false) {
  49 |   await login(page, "browser-maker"); await enter(page, order);
  50 |   const form = page.getByRole("form", { name: "Prepare partial good output and abnormal scrap", exact: true });
  51 |   await fill(form, { "Exact good output quantity": good, "Exact abnormal scrap quantity": scrap, "Open fiscal period ID": "period", "Posting date": "2026-10-05", Reason: "Actual original material disposition" });
  52 |   return command(page, form, "Prepare partial good output and abnormal scrap", `${root}/orders/${order}/completions`, "completion", lose);
  53 | }
  54 | test("actual versioned BOM native material WIP partial FG scrap cancelled draft and lost ACK", async ({ page }) => {
  55 |   test.setTimeout(360_000); expect(base && tenant && password, "Owned HTTPS native fixture required").toBeTruthy();
  56 |   const errors: string[] = []; page.on("pageerror", error => errors.push(error.message));
  57 |   await login(page, "browser-maker"); await enter(page);
  58 |   const recipe = page.getByRole("form", { name: "Prepare versioned BOM", exact: true });
  59 |   await fill(recipe, { "Document number": "BOM-BROWSER", "BOM version": "1", "Finished item code": "PRODUCT", "Exact planned output quantity": "10", Reason: "Versioned exact material recipe" });
  60 |   await fill(recipe.getByRole("group").nth(0), { "Component item code": "ITEM", "Exact base-UOM component quantity": "2" });
  61 |   await recipe.getByRole("button", { name: "Add component", exact: true }).click();
  62 |   await fill(recipe.getByRole("group").nth(1), { "Component item code": "MATERIAL", "Exact base-UOM component quantity": "3.000" });
  63 |   const bom = await command(page, recipe, "Prepare versioned BOM", `${root}/boms`, "bom", true);
  64 |   await login(page, "browser-checker"); await enter(page, "", "", bom.id);
  65 |   const approve = page.getByRole("form", { name: "Approve exact BOM", exact: true }); await fill(approve, { Reason: "Independent exact base-UOM approval" });
  66 |   await command(page, approve, "Approve exact BOM", `${root}/boms/${bom.id}/approve`, "bom");
  67 |   await login(page, "browser-maker"); await enter(page, "", "", bom.id);
  68 |   const reserve = page.getByRole("form", { name: "Reserve whole material order", exact: true });
  69 |   await fill(reserve, { "Document number": "WORK-BROWSER", "Exact planned output quantity": "10", "Component location code": "MAIN/STOCK", "Finished location code": "MAIN/STOCK", "Component FIFO policy": "FIFO", "Finished FIFO policy with WIP offset": "MFG", "Native journal code": "STOCK", "WIP asset account": "WIP", "Abnormal scrap expense account": "SCRAP", "Open fiscal period ID": "period", "Posting date": "2026-10-04", Reason: "Actual governed material reservation" });
  70 |   const order = await command(page, reserve, "Reserve whole material order", `${root}/orders`, "order");
  71 |   const prepared = await phase(page, order.id, "prepare"); expect(prepared.issue_plan.total_cost_minor).toBe("2900");
  72 |   await phase(page, order.id, "review"); await phase(page, order.id, "post", "", true);
  73 |   const cancelled = await partial(page, order.id, "3", "1"); await phase(page, order.id, "review", cancelled.id); await phase(page, order.id, "cancel", cancelled.id, true);
  74 |   for (const [good, scrap] of [["3", "1"], ["6", "0"]]) {
  75 |     const child = await partial(page, order.id, good, scrap, good === "3");
  76 |     await phase(page, order.id, "review", child.id); const posted = await phase(page, order.id, "post", child.id, good === "6"); expect(posted.receipt_effect.posted_actor_id).toBe("erp-poster");
  77 |   }
  78 |   await login(page, "browser-maker"); await enter(page, order.id);
  79 |   await expect(page.getByRole("region", { name: "Original production and native financial evidence", exact: true })).toContainText("WIP: 0");
  80 |   await expect(page.getByRole("form", { name: "Prepare partial good output and abnormal scrap", exact: true })).toHaveCount(0);
  81 |   expect((await new AxeBuilder({ page }).analyze()).violations).toEqual([]);
  82 |   await page.setViewportSize({ width: 390, height: 844 });
  83 |   await page.getByRole("button", { name: "Switch language", exact: true }).click();
  84 |   await expect(page.getByRole("heading", { name: "التنفيذ الصناعي بالتكلفة الفعلية", exact: true })).toBeVisible();
  85 |   await expect(page.locator("main#main-content")).toHaveAttribute("dir", "rtl");
  86 |   expect((await new AxeBuilder({ page }).analyze()).violations).toEqual([]); expect(errors).toEqual([]);
  87 | });
  88 | 
```