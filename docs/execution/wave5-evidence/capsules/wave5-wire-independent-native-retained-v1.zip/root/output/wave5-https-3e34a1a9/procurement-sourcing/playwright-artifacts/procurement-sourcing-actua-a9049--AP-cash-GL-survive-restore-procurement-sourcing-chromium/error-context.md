# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: procurement-sourcing.spec.ts >> actual HTTPS PR, RFQ, retained supplier quotations, independent award and native budget/AP/cash/GL survive restore
- Location: apps\web\live\procurement-sourcing.spec.ts:47:1

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator: getByRole('main')
Expected: "rtl"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toHaveAttribute" with timeout 5000ms
  - waiting for getByRole('main')

```

```yaml
- link "انتقل إلى المحتوى الرئيسي":
  - /url: "#main-content"
- complementary:
  - strong: ReconForge
  - text: Studio
  - button "إغلاق النافذة"
  - group:
    - text: FC
    - strong: طلبات الشراء والمنافسات
    - text: جلسة مباشرة
  - navigation "التنقل الرئيسي":
    - paragraph: عمليات ERP
    - button "المالية والتقارير"
    - button "القوائم المالية"
    - button "الأصول الثابتة"
    - button "تنفيذ التصنيع"
    - button "المعاملات بين شركات المجموعة"
    - button "طلبات الشراء والمنافسات"
    - button "مرتجعات العملاء"
    - button "العملات والضرائب"
    - button "مبيعات المنتجات"
    - button "المشتريات الجزئية"
    - button "المبيعات والإيرادات"
    - button "المشتريات والمدفوعات"
    - paragraph: نظرة عامة
    - button "لوحة المتابعة"
    - paragraph: الضوابط المالية
    - button "الذمم المدينة"
    - button "رقابة الميزانيات"
    - link "المطابقة أساس تجريبي":
      - /url: http://127.0.0.1:8601/reconciliation
    - button "الاستثناءات أساس تجريبي"
    - button "ملف الأدلة أساس تجريبي"
    - link "إقفال نهاية الشهر أساس تجريبي":
      - /url: http://127.0.0.1:8601/close
    - button "تسويات التجزئة أساس تجريبي"
    - button "مطابقة البنك أساس تجريبي"
    - button "فواتير ومدفوعات الخدمات المهنية أساس تجريبي"
    - button "التدفق النقدي الفردي أساس تجريبي"
    - paragraph: العمليات
    - button "ضوابط المخزون أساس تجريبي"
    - button "استلام المخزون"
    - button "رقابة تكلفة التصنيع أساس تجريبي"
    - paragraph: المنصة
    - link "التقارير أساس تجريبي":
      - /url: http://127.0.0.1:8601/downloads
    - link "حزم الضوابط أساس تجريبي":
      - /url: http://127.0.0.1:8601/control-packs
    - button "استوديو ربط الأعمدة أساس تجريبي"
    - button "استوديو القواعد أساس تجريبي"
    - button "الاستوديو الحي أساس تجريبي"
    - button "تدقيق الإدارة أساس تجريبي"
    - button "الإشعارات أساس تجريبي"
    - button "الوظائف الدائمة"
    - button "الإعدادات مخطط" [disabled]
    - link "وحدة المطور أساس تجريبي":
      - /url: http://127.0.0.1:8601/docs
  - strong: جلسة مباشرة
  - text: طلبات الشراء والمنافسات
- banner:
  - button "القائمة"
  - button "ابحث في الضوابط والصفحات والإجراءات"
  - button "تبديل اللغة": EN
  - 'button "السمة: النظام"'
  - button "إمكانية الوصول"
  - strong: browser-poster
  - text: جلسة مباشرة
- region "طلبات الشراء والمنافسات":
  - heading "طلبات الشراء والمنافسات" [level=2]
  - paragraph: احفظ الاحتياج وعروض الموردين واختيار أقل تكلفة بمراجعة مستقلة. ينشر شخص ثالث أمر الشراء المرتبط بالاعتماد القائم.
  - paragraph: "النطاق: العملة الوظيفية وضريبة صفر والوحدات الأساسية و١٢٨ بندًا و٣٢ موردًا. لا ينشأ مخزون أو التزام مورد قبل الاستلام والاستحقاق القائمين. تشير روابط التصنيع إلى الاحتياجات الأصلية دون ادعاء عجز صافٍ."
  - paragraph: browser-poster
  - button "خروج"
  - group "النطاق المؤسسي الحالي":
    - text: النطاق المؤسسي الحالي مساحة العمل
    - combobox "مساحة العمل":
      - option "اختر"
      - option "work" [selected]
    - text: المؤسسة والكيان القانوني
    - combobox "المؤسسة والكيان القانوني":
      - option "اختر"
      - option "Synthetic · Synthetic · USD" [selected]
  - button "تحديث طلبات الشراء"
  - list:
    - listitem:
      - button "فتح SRC5-BROWSER"
      - text: Awarded · 17000 USD
  - group: طلب شراء جديد
  - region "أدلة مصدر الشراء":
    - heading "SRC5-BROWSER" [level=3]
    - status: تمت الترسية
    - term: السقف الأصلي بأصغر وحدة نقدية
    - definition: 17000 USD
    - term: بصمة المصدر الأصلي
    - definition:
      - code: 756b47630cfc49d89088bd257616e43fa0d42c64fe357d77ed09a9612acae7e7
    - term: حدث المراجعة
    - definition:
      - code: AE-4c66d16d00b444c4b73f6f42723b8470
    - term: حدث النشر
    - definition:
      - code: PSOUT-50fb393f8a7646fa8b2cec973602e4c9
    - button "تحديث هذا الطلب"
    - text: سبب المراجعة أو الترسية
    - textbox "سبب المراجعة أو الترسية": Actual independent retained source selection
    - list "العروض المحفوظة":
      - listitem:
        - text: SUP · 17000 USD
        - strong: العرض المختار بالمراجعة
        - code: 6b40d444a6ec3b49770672902705a980d76fc680df8c0f6b52c5bc5192230488
      - listitem:
        - text: ALT · 18000 USD
        - code: 96a1d72e0436cf32c3b3481b67f2a4440ea5c1ea8928c910ab32867ee3f9a281
    - paragraph:
      - text: "أمر الشراء القائم:"
      - code: PPORDER-365f0d29acdd93a5
      - text: · BPC1-SRC5-BROWSER افتح المشتريات الجزئية لإرسال الأمر والموافقة والاستلام والترحيل واستهلاك الاعتماد وتسوية الأمر الأصلي.
- navigation "تنقل الهاتف":
  - button "المالية والتقارير"
  - button "المبيعات والإيرادات"
  - button "استلام المخزون"
  - button "المشتريات والمدفوعات"
  - button "القائمة"
```

# Test source

```ts
  13  |   await page.getByLabel("Password", { exact: true }).fill(password!);
  14  |   const elevated = page.waitForResponse(reply => reply.url().endsWith("/auth/step-up"));
  15  |   await page.getByRole("button", { name: "Confirm and continue", exact: true }).click(); await acknowledgement(await elevated);
  16  | }
  17  | async function budgetScope(page: Page) {
  18  |   await page.getByRole("navigation", { name: "Primary navigation" }).getByRole("button", { name: "Budget control", exact: true }).click();
  19  |   for (const [label, value] of Object.entries({ "Workspace ID": "work", "Organization ID": "org", "Legal entity ID": "entity" })) await page.getByLabel(label, { exact: true }).fill(value);
  20  |   await page.getByRole("button", { name: "Load budgets", exact: true }).click();
  21  | }
  22  | async function purchaseScope(page: Page) {
  23  |   await page.getByRole("navigation", { name: "Primary navigation" }).getByRole("button", { name: "Partial procurement", exact: true }).click();
  24  |   await page.getByRole("combobox", { name: "Workspace", exact: true }).selectOption("work");
  25  |   await page.getByRole("combobox", { name: "Organization and legal entity", exact: true }).selectOption("entity");
  26  | }
  27  | async function inspect(page: Page) {
  28  |   const region = page.getByRole("region", { name: "Source and ledger references", exact: true });
  29  |   const loaded = page.waitForResponse(reply => /\/procurement-partial\/orders\/PPORDER-[^/?]+$/.test(reply.url()) && reply.request().method() === "GET");
  30  |   if (await region.isVisible()) await region.getByRole("button", { name: "Refresh this order", exact: true }).click();
  31  |   else {
  32  |     await page.getByRole("combobox", { name: "Organization and legal entity", exact: true }).selectOption("");
  33  |     await page.getByRole("combobox", { name: "Organization and legal entity", exact: true }).selectOption("entity");
  34  |     await page.getByRole("button", { name: "Open " + number, exact: true }).click();
  35  |   }
  36  |   const detail = await acknowledgement(await loaded);
  37  |   await expect(region.getByRole("heading", { name: number, exact: true })).toBeVisible();
  38  |   await region.getByLabel("Review or posting reason", { exact: true }).fill("Actual independent appropriated procurement operation");
  39  |   return { region, detail };
  40  | }
  41  | async function action(page: Page, label: string, operation: string) {
  42  |   const { region } = await inspect(page);
  43  |   const saved = page.waitForResponse(reply => reply.url().endsWith(`/commands/${operation}`) && reply.request().method() === "POST");
  44  |   await region.getByRole("button", { name: label, exact: true }).click(); return acknowledgement(await saved);
  45  | }
  46  | 
  47  | test("actual HTTPS PR, RFQ, retained supplier quotations, independent award and native budget/AP/cash/GL survive restore", async ({ browser }) => {
  48  |   test.setTimeout(600_000); expect(base && tenant && password).toBeTruthy();
  49  |   const contexts = await Promise.all(["maker", "checker", "poster"].map(() => browser.newContext({ ignoreHTTPSErrors: true })));
  50  |   try {
  51  |     const [maker, checker, poster] = await Promise.all(contexts.map(context => context.newPage()));
  52  |     for (const [page, user] of [[maker, "browser-maker"], [checker, "browser-checker"], [poster, "browser-poster"]] as const) await login(page, user);
  53  |     await budgetScope(maker);
  54  |     const budgetForm = maker.getByRole("form", { name: "Create budget draft", exact: true });
  55  |     for (const [label, value] of Object.entries({ "Budget code": "BROWSER-PC", "Budget name": "Actual approved purchase appropriation", "Fiscal period ID": "period", "Currency code": "USD", "Limit in exact minor units": "20000" })) await budgetForm.getByLabel(label, { exact: true }).fill(value);
  56  |     const createdBudget = maker.waitForResponse(reply => reply.url().endsWith("/budget-control/envelopes") && reply.request().method() === "POST");
  57  |     await budgetForm.getByRole("button", { name: "Create draft", exact: true }).click();
  58  |     const budget = await acknowledgement(await createdBudget);
  59  |     await maker.getByLabel("Recorded reason", { exact: true }).fill("Independent reviewed native purchase budget");
  60  |     const submitted = maker.waitForResponse(reply => reply.url().endsWith(`/envelopes/${budget.id}/submit`));
  61  |     await maker.getByRole("button", { name: "Submit for independent approval", exact: true }).click(); await acknowledgement(await submitted);
  62  |     await budgetScope(checker); await checker.getByRole("button", { name: "Open budget BROWSER-PC", exact: true }).click();
  63  |     await checker.getByLabel("Recorded reason", { exact: true }).fill("Independent appropriation approval");
  64  |     const approved = checker.waitForResponse(reply => reply.url().endsWith(`/envelopes/${budget.id}/approve`));
  65  |     await checker.getByRole("button", { name: "Approve budget", exact: true }).click(); expect((await acknowledgement(await approved)).status).toBe("Approved");
  66  |     async function sourcingScope(page: Page) {
  67  |       await page.getByRole("navigation", { name: "Primary navigation" }).getByRole("button", { name: "Procurement sourcing", exact: true }).click();
  68  |       await page.getByRole("combobox", { name: "Workspace", exact: true }).selectOption("work");
  69  |       await page.getByRole("combobox", { name: "Organization and legal entity", exact: true }).selectOption("entity");
  70  |     }
  71  |     async function inspectSource(page: Page) {
  72  |       await page.getByRole("button", { name: "Refresh requisitions", exact: true }).click();
  73  |       await page.getByRole("button", { name: "Open SRC5-BROWSER", exact: true }).click();
  74  |       const region = page.getByRole("region", { name: "Original sourcing evidence", exact: true });
  75  |       await expect(region.getByRole("heading", { name: "SRC5-BROWSER", exact: true })).toBeVisible();
  76  |       await region.getByLabel("Review or award reason", { exact: true }).fill("Actual independent retained source selection");
  77  |       return region;
  78  |     }
  79  |     async function sourceAction(page: Page, operation: string, label: string) {
  80  |       const region = await inspectSource(page);
  81  |       const saved = page.waitForResponse(reply => reply.url().endsWith("/" + operation) && reply.request().method() === "POST");
  82  |       await region.getByRole("button", { name: label, exact: true }).click();
  83  |       return acknowledgement(await saved);
  84  |     }
  85  |     for (const page of [maker, checker, poster]) await sourcingScope(page);
  86  |     await maker.locator("summary").filter({ hasText: /^New purchase requisition$/ }).click();
  87  |     const sourceForm = maker.getByRole("form", { name: "New purchase requisition", exact: true });
  88  |     await sourceForm.getByRole("button", { name: "Add demand line", exact: true }).click();
  89  |     for (const [label, value] of Object.entries({ "Requisition number": "SRC5-BROWSER", "Posting date": "2026-10-12", "Quantity 1": "10", "Ceiling unit price in minor units 1": "1200", "Quantity 2": "2.50", "Ceiling unit price in minor units 2": "2000", "Creation reason": "Original exact mixed-unit operational demand" })) await sourceForm.getByLabel(label, { exact: true }).fill(value);
  90  |     for (const [label, value] of Object.entries({ "Approved appropriation": budget.id, "Reference supplier": "SUP", "Open fiscal period": "period", "Accrual and payment journal": "STOCK", "Accounts payable": "AP", "Cash account": "CASH", "Item 1": "ITEM", "Receiving location 1": "MAIN/STOCK", "FIFO valuation policy 1": "FIFO", "Item 2": "WEIGHT", "Receiving location 2": "NORTH/STOCK", "FIFO valuation policy 2": "FIFO" })) await sourceForm.getByRole("combobox", { name: label, exact: true }).selectOption(value);
  91  |     const createdSource = maker.waitForResponse(reply => reply.url().endsWith("/procurement-sourcing/requisitions") && reply.request().method() === "POST");
  92  |     await sourceForm.getByRole("button", { name: "Create requisition", exact: true }).click();
  93  |     expect((await acknowledgement(await createdSource)).ceiling_minor).toBe("17000");
  94  |     await sourceAction(checker, "open-rfq", "Open RFQ independently");
  95  |     for (const [supplier, price] of [["ALT", "1300"], ["SUP", "1200"]] as const) {
  96  |       const region = await inspectSource(maker), quotation = region.getByRole("form", { name: "Retain supplier quotation", exact: true });
  97  |       await quotation.getByRole("combobox", { name: "Quotation supplier", exact: true }).selectOption(supplier);
  98  |       await quotation.getByLabel("Offer valid until", { exact: true }).fill("2026-10-31");
  99  |       await quotation.getByLabel("Quoted unit price in minor units 1 · ITEM", { exact: true }).fill(price);
  100 |       await quotation.getByLabel("Quoted unit price in minor units 2 · WEIGHT", { exact: true }).fill("2000");
  101 |       const retained = maker.waitForResponse(reply => reply.url().endsWith("/quotes") && reply.request().method() === "POST");
  102 |       await quotation.getByRole("button", { name: "Retain exact supplier offer", exact: true }).click(); await acknowledgement(await retained);
  103 |     }
  104 |     expect((await sourceAction(checker, "review-selection", "Review deterministic lowest-cost selection")).status).toBe("SelectionReviewed");
  105 |     const owner = await sourceAction(poster, "award", "Award native budget-backed purchase");
  106 |     expect(owner.status).toBe("Awarded"); expect(owner.order_id).toMatch(/^PPORDER-/);
  107 |     const sourceRegion = poster.getByRole("region", { name: "Original sourcing evidence", exact: true });
  108 |     await expect(sourceRegion.getByText("Reviewed winner", { exact: true })).toBeVisible();
  109 |     expect((await new AxeBuilder({ page: poster }).include(".procurement-sourcing-page").analyze()).violations).toEqual([]);
  110 |     await poster.setViewportSize({ width: 390, height: 844 }); expect(await poster.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  111 |     await poster.screenshot({ path: test.info().outputPath("sourcing-390px-en.png"), fullPage: true });
  112 |     await poster.getByTestId("locale-toggle").click();
> 113 |     await expect(poster.getByRole("main")).toHaveAttribute("dir", "rtl");
      |                                            ^ Error: expect(locator).toHaveAttribute(expected) failed
  114 |     await expect(poster.getByRole("heading", { name: "طلبات الشراء والمنافسات", exact: true })).toBeVisible();
  115 |     expect((await new AxeBuilder({ page: poster }).include(".procurement-sourcing-page").analyze()).violations).toEqual([]);
  116 |     await poster.screenshot({ path: test.info().outputPath("sourcing-390px-ar.png"), fullPage: true });
  117 |     await poster.getByTestId("locale-toggle").click(); await poster.setViewportSize({ width: 1280, height: 800 });
  118 |     for (const page of [maker, checker, poster]) await purchaseScope(page);
  119 |     await action(poster, "Submit purchase order", "submit-order"); await action(checker, "Approve purchase order", "approve-order");
  120 |     for (const [lineIndex, quantity] of [[0, "2"], [1, "2.50"]] as const) {
  121 |       const { region, detail } = await inspect(maker);
  122 |       const part = region.getByRole("group", { name: "Quantity for this document", exact: true });
  123 |       await part.getByRole("combobox", { name: "Purchase line for receiving", exact: true }).selectOption(detail.lines[lineIndex].id);
  124 |       await part.getByLabel("Quantity", { exact: true }).fill(quantity); await part.getByLabel("Posting date", { exact: true }).fill("2026-10-12");
  125 |       const prepared = maker.waitForResponse(reply => reply.url().endsWith("/commands/prepare-receipt-line"));
  126 |       await part.getByRole("button", { name: "Prepare partial receipt", exact: true }).click(); await acknowledgement(await prepared);
  127 |       await action(checker, "Review receiving", "review-receipt"); await action(poster, "Post stock receiving and GL", "receive");
  128 |     }
  129 |     const { region: matching } = await inspect(maker), part = matching.getByRole("group", { name: "Quantity for this document", exact: true });
  130 |     await part.getByLabel("ITEM · EA", { exact: true }).fill("2"); await part.getByLabel("WEIGHT · KG", { exact: true }).fill("2.50");
  131 |     const matched = maker.waitForResponse(reply => reply.url().endsWith("/commands/match-invoice-lines"));
  132 |     await part.getByRole("button", { name: "Match partial invoice", exact: true }).click(); const invoice = (await acknowledgement(await matched)).invoices[0];
  133 |     await action(checker, "Approve supplier invoice", "approve-invoice"); await action(maker, "Prepare invoice accrual", "prepare-accrual"); await action(checker, "Review invoice accrual", "review-accrual");
  134 |     const { region: publishing } = await inspect(poster);
  135 |     const consumed = poster.waitForResponse(reply => reply.url().endsWith(`/procurement-commitments/orders/${owner.order_id}/consume`));
  136 |     await publishing.getByRole("button", { name: "Post AP and consume appropriation " + invoice.number, exact: true }).click();
  137 |     expect((await acknowledgement(await consumed)).consumed_minor).toBe("7400");
  138 |     const { region: releasing } = await inspect(checker);
  139 |     await releasing.getByLabel("Release posting date", { exact: true }).fill("2026-10-13");
  140 |     const released = checker.waitForResponse(reply => reply.url().endsWith(`/procurement-commitments/orders/${owner.order_id}/release`));
  141 |     await releasing.getByRole("button", { name: "Release remaining obligation", exact: true }).click();
  142 |     expect((await acknowledgement(await released)).released_minor).toBe("9600");
  143 |     await expect(releasing.getByRole("button", { name: "Prepare partial receipt", exact: true })).toHaveCount(0);
  144 |     for (const amount of ["2400", "5000"]) {
  145 |       const { region } = await inspect(maker), payment = region.getByRole("form", { name: "Prepare installment", exact: true });
  146 |       await payment.getByRole("combobox", { name: "Supplier invoice", exact: true }).selectOption(invoice.id);
  147 |       await payment.getByLabel("Installment amount in minor units", { exact: true }).fill(amount); await payment.getByLabel("Posting date", { exact: true }).fill("2026-10-13");
  148 |       const prepared = maker.waitForResponse(reply => reply.url().endsWith("/financial-installments/plans") && reply.request().method() === "POST");
  149 |       await payment.getByRole("button", { name: "Prepare installment", exact: true }).click(); await acknowledgement(await prepared);
  150 |       const { region: reviewing } = await inspect(checker), reviewed = checker.waitForResponse(reply => /\/financial-installments\/plans\/[^/]+\/review$/.test(reply.url()));
  151 |       await reviewing.getByRole("button", { name: "Review installment", exact: true }).click(); await acknowledgement(await reviewed);
  152 |       const { region: posting } = await inspect(poster), posted = poster.waitForResponse(reply => /\/financial-installments\/plans\/[^/]+\/post$/.test(reply.url()));
  153 |       await posting.getByRole("button", { name: "Post installment", exact: true }).click(); expect((await acknowledgement(await posted)).plan.amount_minor).toBe(amount);
  154 |     }
  155 |     const { region, detail } = await inspect(poster); expect(detail.totals).toMatchObject({ accrued_minor: "7400", paid_minor: "7400", outstanding_minor: "0" });
  156 |     await expect(region.getByRole("region", { name: "Purchase appropriation", exact: true })).toContainText("Released");
  157 |     await poster.setViewportSize({ width: 390, height: 844 }); expect(await poster.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  158 |     expect((await new AxeBuilder({ page: poster }).include(".procurement-partial-page").analyze()).violations).toEqual([]);
  159 |     await poster.screenshot({ path: test.info().outputPath("appropriation-390px-en.png"), fullPage: true });
  160 |     await poster.getByTestId("locale-toggle").click(); await expect(poster.getByRole("main")).toHaveAttribute("dir", "rtl");
  161 |     await expect(poster.getByRole("heading", { name: "اعتماد أمر الشراء", exact: true })).toBeVisible();
  162 |     expect((await new AxeBuilder({ page: poster }).include(".procurement-partial-page").analyze()).violations).toEqual([]);
  163 |     await poster.screenshot({ path: test.info().outputPath("appropriation-390px-ar.png"), fullPage: true });
  164 |   } finally { await Promise.all(contexts.map(context => context.close())); }
  165 | });
  166 | 
```