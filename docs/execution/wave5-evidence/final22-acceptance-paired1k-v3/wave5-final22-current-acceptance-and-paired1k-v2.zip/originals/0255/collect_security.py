from __future__ import annotations
import concurrent.futures, hashlib, json, subprocess, sys, zipfile
from datetime import datetime, timezone
from pathlib import Path
import requests

OUT=Path(__file__).resolve().parent
REPO='amrzainmubarak/reconforge-erp'
SOURCE='22ebfd78e293aafa13d81b3a0bbf287491951115'
RUNS={'manual-security':38209387439,'codeql':38208811406,'docker':38208811421}
TOKEN=subprocess.check_output(['gh','auth','token'],text=True,stderr=subprocess.DEVNULL,timeout=15).strip()
STAMP=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')

def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(endpoint, accept='application/vnd.github+json'):
 try:
  response=requests.get('https://api.github.com/'+endpoint,headers={'Authorization':'Bearer '+TOKEN,'Accept':accept,'X-GitHub-Api-Version':'2022-11-28'},timeout=(10,45))
  if response.status_code!=200:return {'endpoint':endpoint,'status_code':response.status_code,'error':'http-response'}
  return {'endpoint':endpoint,'status_code':200,'raw':response.content}
 except requests.RequestException as e:return {'endpoint':endpoint,'error_type':type(e).__name__}
def persist(label, response):
 if 'raw' not in response:return response
 raw=response.pop('raw');path=OUT/(label+'-'+STAMP+'.json');path.write_bytes(raw)
 return {**response,'file':path.name,'bytes':len(raw),'sha256':sha(raw),'value':json.loads(raw)}
def snapshot():
 requests_by_name={}
 for label,run in RUNS.items():
  for kind in ['metadata','jobs','artifacts']:
   endpoint=f'repos/{REPO}/actions/runs/{run}'+('' if kind=='metadata' else '/'+kind+'?per_page=100')
   requests_by_name[label+'-'+kind]=endpoint
 requests_by_name['current-runs']=f'repos/{REPO}/actions/runs?head_sha={SOURCE}&per_page=100'
 saved={}
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  futures={pool.submit(read,endpoint):label for label,endpoint in requests_by_name.items()}
  for future in concurrent.futures.as_completed(futures):
   label=futures[future];saved[label]=persist(label,future.result())
 summary=[]
 for label,run in RUNS.items():
  value=saved.get(label+'-metadata',{}).get('value');jobs=saved.get(label+'-jobs',{}).get('value',{}).get('jobs',[])
  if value is not None:
   if value['head_sha']!=SOURCE:raise ValueError('Exact source mismatch: '+label)
   summary.append({'label':label,'run_id':run,'url':value['html_url'],'source_commit':value['head_sha'],'event':value['event'],'status':value['status'],'conclusion':value['conclusion'],'job_count':len(jobs),'jobs':[{'id':j['id'],'name':j['name'],'status':j['status'],'conclusion':j['conclusion']} for j in jobs]})
 candidates=saved.get('current-runs',{}).get('value',{}).get('workflow_runs',[])
 for candidate in candidates:
  if candidate['head_sha']==SOURCE and candidate['name']=='Security' and candidate['event']=='pull_request':
   entry=persist('pr-security-metadata',read(f'repos/{REPO}/actions/runs/{candidate["id"]}'));saved['pr-security-metadata']=entry
   jobs=persist('pr-security-jobs',read(f'repos/{REPO}/actions/runs/{candidate["id"]}/jobs?per_page=100'));saved['pr-security-jobs']=jobs
   summary.append({'label':'pr-security','run_id':candidate['id'],'url':candidate['html_url'],'source_commit':SOURCE,'event':'pull_request','status':candidate['status'],'conclusion':candidate['conclusion'],'job_count':len(jobs.get('value',{}).get('jobs',[])),'jobs':[{'id':j['id'],'name':j['name'],'status':j['status'],'conclusion':j['conclusion']} for j in jobs.get('value',{}).get('jobs',[])]})
 packet={'schema_version':'wave5-readonly-security-snapshot-v1','captured_at_utc':STAMP,'source_commit':SOURCE,'runs':summary,'raw_records':[{k:v for k,v in row.items() if k!='value'} for row in saved.values()]}
 path=OUT/('snapshot-'+STAMP+'.json');path.write_text(json.dumps(packet,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'snapshot':str(path),'sha256':sha(path.read_bytes()),'runs':summary},indent=2))
def download(run_id):
 artifact_response=persist('download-artifacts',read(f'repos/{REPO}/actions/runs/{run_id}/artifacts?per_page=100'))
 if 'value' not in artifact_response:print(json.dumps({k:v for k,v in artifact_response.items() if k!='value'}));return
 records=[]
 for artifact in artifact_response['value']['artifacts']:
  if artifact['expired']:continue
  response=read(f'repos/{REPO}/actions/artifacts/{artifact["id"]}/zip',accept='application/vnd.github+json')
  if 'raw' not in response:records.append(response);continue
  raw=response.pop('raw');path=OUT/f'artifact-{artifact["id"]}-{artifact["name"]}.zip'
  if path.exists():
   if path.read_bytes()!=raw:raise ValueError('Immutable artifact changed')
  else:path.write_bytes(raw)
  members=[]
  with zipfile.ZipFile(path) as archive:
   for member in archive.infolist():
    if member.is_dir():continue
    if Path(member.filename).suffix.lower() not in {'.json','.txt','.log','.xml'}:raise ValueError('Unexpected original security artifact member suffix')
    if member.file_size>32*1024*1024 or member.filename.startswith(('/', '\\')) or Path(member.filename).is_absolute() or Path(member.filename).drive or '..' in Path(member.filename).parts:raise ValueError('Unsafe artifact member')
    body=archive.read(member);target=OUT/'artifact-members'/str(artifact['id'])/member.filename
    if not target.resolve().is_relative_to((OUT/'artifact-members'/str(artifact['id'])).resolve()):raise ValueError('Artifact member escapes owned evidence directory')
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():
     if target.read_bytes()!=body:raise ValueError('Immutable extracted member changed')
    else:target.write_bytes(body)
    members.append({'name':member.filename,'path':str(target),'bytes':len(body),'sha256':sha(body)})
  records.append({'source_commit':artifact['workflow_run']['head_sha'],'run_id':run_id,'artifact_id':artifact['id'],'name':artifact['name'],'origin':response['endpoint'],'zip':str(path),'bytes':len(raw),'sha256':sha(raw),'members':members})
 result=OUT/('downloads-'+str(run_id)+'-'+STAMP+'.json');result.write_text(json.dumps({'source_commit':SOURCE,'run_id':run_id,'artifacts':records},indent=2)+'\n',encoding='utf-8');print(json.dumps({'downloads':str(result),'sha256':sha(result.read_bytes()),'artifacts':records},indent=2))

if __name__=='__main__':
 if len(sys.argv)==3 and sys.argv[1]=='download':download(int(sys.argv[2]))
 else:snapshot()
