from __future__ import annotations
import collections,hashlib,json
from pathlib import Path
from datetime import datetime,timezone

ROOT=Path(__file__).resolve().parent
SOURCE='22ebfd78e293aafa13d81b3a0bbf287491951115'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def unique(pairs):
 d={}
 for k,v in pairs:
  if k in d:raise ValueError('Duplicate original JSON member')
  d[k]=v
 return d
def read(p):return json.loads(p.read_bytes(),object_pairs_hook=unique)
def need(condition,message):
 if not condition:raise ValueError(message)

snapshot_path=next(ROOT.glob('snapshot-*.json'));snapshot=read(snapshot_path)
runs=snapshot['runs'];need(len(runs)==4 and all(r['source_commit']==SOURCE and r['status']=='completed' and r['conclusion']=='success' for r in runs),'Exact published source workflow closure differs')
manual=next(r for r in runs if r['label']=='manual-security');pr=next(r for r in runs if r['label']=='pr-security')
need(manual['event']=='workflow_dispatch' and manual['run_id']==38209387439 and len(manual['jobs'])==5 and all(j['conclusion']=='success' for j in manual['jobs']),'Manual all-five real security gates absent')
need(pr['event']=='pull_request' and pr['run_id']==38208811416 and len(pr['jobs'])==5 and collections.Counter(j['conclusion'] for j in pr['jobs'])=={'success':4,'skipped':1},'PR conditional image execution distinction differs')
need(next(j for j in pr['jobs'] if j['conclusion']=='skipped')['name']=='Exact-image SBOM, vulnerability, and license gate','Unexpected skipped PR gate')
member=ROOT/'artifact-members'/'11729335269';policy=read(member/'container-security-evidence.json');syft=read(member/'image.syft.json');grype=read(member/'image.grype.json')
need(policy['status']=='passed' and policy['blockers']==[] and policy['active_exception_count']==0,'Actual image policy blockers/exception evidence differs')
need(policy['vulnerabilities']['grype_report_sha256']==sha(member/'image.grype.json') and policy['vulnerabilities']['syft_inventory_sha256']==sha(member/'image.syft.json'),'Actual image original report fingerprints differ')
image=policy['image'];smeta=syft['source']['metadata'];gmeta=grype['source']['target']
need(image['config_digest']==smeta['imageID']==gmeta['imageID'] and image['local_manifest_digest']==smeta['manifestDigest']==gmeta['manifestDigest'],'Exact original policy/SBOM/vulnerability image differs')
need(smeta['userInput']==gmeta['userInput']=='reconforge-security:'+SOURCE,'Actual manual source image tag differs')
counts=collections.Counter(match['vulnerability']['severity'].lower() for match in grype['matches']);expected={level:counts[level] for level in ['critical','high','low','medium','negligible','unknown']}
need(policy['vulnerabilities']['counts']==expected=={'critical':0,'high':0,'low':0,'medium':9,'negligible':1,'unknown':0},'Actual raw image vulnerability population differs')
matches=[]
for match in grype['matches']:
 v,a=match['vulnerability'],match['artifact'];matches.append({'cve_id':v['id'],'severity':v['severity'],'package':a['name'],'version':a['version'],'ecosystem':a['type'],'purl':a.get('purl'),'scanner_data_source':v.get('dataSource'),'raw_reported_fix':v.get('fix')})
missing=[{'name':a['name'],'version':a['version'],'ecosystem':a['type'],'purl':a.get('purl')} for a in syft['artifacts'] if not a.get('licenses')]
licenses=policy['license_inventory'];need(len(syft['artifacts'])==licenses['total_packages']==68 and len(missing)==3 and licenses['licensed_packages']==65 and licenses['coverage_basis_points']==65*10000//68==9558 and licenses['legal_compatibility_assessed'] is False,'Actual license metadata/assessment contract differs')
need(sorted(a['name']+'@'+a['version'] for a in missing)==sorted(licenses['missing_license_packages']),'Exact three missing license metadata identities differ')
gitleaks=[]
for artifact_id,mode in [('11728207446','manual-exact-head'),('11728975475','pr-merge-checkout')]:
 for kind in ['history','tree']:
  p=ROOT/'artifact-members'/artifact_id/('gitleaks-'+kind+'.json');value=read(p);need(type(value) is list and value==[],'Original current redacted Gitleaks findings not empty');gitleaks.append({'mode':mode,'kind':kind,'findings':len(value),'bytes':p.stat().st_size,'sha256':sha(p)})
binding=read(ROOT/'pr-checkout-binding.json');need(binding['same_tree'] is binding['published_head_is_parent'] is True and binding['workflow_head_sha']==SOURCE,'Current PR checkout/head exact tree binding absent')
downloads=[]
for p in sorted(ROOT.glob('downloads-*.json')):
 d=read(p);need(d['source_commit']==SOURCE,'Original artifact workflow-head differs')
 for row in d['artifacts']:
  need(row['source_commit']==SOURCE and sha(Path(row['zip']))==row['sha256'],'Original artifact ZIP custody differs')
  for part in row['members']:need(sha(Path(part['path']))==part['sha256'],'Original extracted member custody differs')
  downloads.append(row)
raw=[]
for p in sorted(ROOT.rglob('*')):
 if p.is_file() and p.suffix in {'.json','.zip'}:raw.append({'relative_path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
result={'schema_version':'wave5-exact-source-security-closure-v1','evaluated_at_utc':datetime.now(timezone.utc).isoformat(),'source_commit':SOURCE,
 'workflow_execution_closure':'passed','manual_security':manual,'pr_security':pr,'codeql':next(r for r in runs if r['label']=='codeql'),'docker':next(r for r in runs if r['label']=='docker'),
 'image_policy':{'status':policy['status'],'config_digest':image['config_digest'],'manifest_digest':image['local_manifest_digest'],'distro':image['distro'],'platform':image['platform'],'evaluated_at':policy['evaluated_at'],'tools':policy['tools'],'database':policy['database'],'counts':expected,'raw_matches':len(grype['matches']),'unique_cves':len({m['cve_id'] for m in matches}),'active_exceptions':policy['active_exception_count'],'applied_fixed_vex_findings':policy['vex']['applied_fixed_findings'],'vex_review':policy['vex']},
 'vulnerability_matches':matches,'license_inventory':licenses,'missing_license_metadata':missing,'gitleaks_original_reports':gitleaks,'pr_checkout_binding':binding,'original_artifact_zip_records':downloads,
 'raw_file_index':raw,'raw_snapshot_file':snapshot_path.name,'raw_snapshot_sha256':sha(snapshot_path),'limitations':['Policy execution success does not mean zero vulnerabilities. Nine Medium and one Negligible raw matches remain; applicability was not independently adjudicated in this retrieval.','Three license metadata gaps remain; legal compatibility is unassessed.','PR image job was conditionally skipped; actual image-policy evidence comes from the separate exact-head workflow_dispatch run.','CodeQL job success proves analysis workflow completion; no Actions artifact/SARIF or independently counted code-scanning alerts were supplied. No zero-CodeQL-alert claim.','Locked Python/npm gate success is retained from original workflow steps; no separately uploaded raw audit report was supplied.','PR original artifact name retains merge checkout66bcd39a0f73a80180b97902f3569aea6dbf414e; raw Git objects prove identical tree and exact22eb parent, without relabeling original bytes.','Read-only GitHub REST and original artifact retrieval only; no new scan, dependency installation, tests, image build, rerun, dispatch, root edits or capsule changes.']}
target=ROOT/'security-closure-22ebfd78.json';need(not target.exists(),'Existing closure cannot be overwritten');target.write_bytes((json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
print(json.dumps({'record':str(target),'sha256':sha(target),'raw_files':len(raw),'artifacts':len(downloads),'manual_security_all_five':'success','image_counts':expected,'license_metadata':[65,68],'missing_license_metadata':missing,'source_commit':SOURCE},indent=2))
