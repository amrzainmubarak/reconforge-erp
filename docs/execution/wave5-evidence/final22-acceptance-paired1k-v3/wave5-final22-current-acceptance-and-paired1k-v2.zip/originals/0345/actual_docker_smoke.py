"""One authorized real ownership-protocol smoke; sleep only, no DB/financial work."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import final22_pair as c  # noqa: E402


def main() -> None:
    output = HERE / "actual-docker-smoke-1"
    c.require(not output.exists(), "Preserve previous smoke")
    output.mkdir()
    root = c.ROOTS["baseline"]
    harness = c.ROOTS["candidate"] / ".github/scripts/benchmark_enterprise_finance.py"
    plan = {"harness_path": str(harness), "harness_sha256": c.sha(harness)}
    before = c.source(root, c.COMMITS["baseline"])
    actual, _reported = c.child_command(plan, "baseline", output / "sleep-only")
    actual.insert(actual.index("--"), "--smoke-ownership")
    environment = os.environ.copy()
    environment["__PYVENV_LAUNCHER__"] = str(c.PYTHON.resolve())
    environment["PYTHONPATH"] = str(root)
    environment.pop("PYTHONHOME", None)
    packet = {"schema_version": "actual-final22-docker-ownership-smoke-v1", "status": "failed",
              "command": actual, "no_database_or_financial_commands": True, "source_before": before}
    ownership = output / "sleep-only-ownership.json"
    process, job, identity, bound = None, None, None, None
    deadline = time.monotonic() + 60
    try:
        with (output / "child.log").open("xb") as log:
            process = subprocess.Popen(actual, cwd=root, env=environment, stdout=log, stderr=subprocess.STDOUT,
                                       creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)
            identity = c.process_identity(process.pid)
            c.require(identity["pid"] == process.pid and Path(identity["executable"]).resolve() == c.PHYSICAL.resolve(),
                      "Physical PID ownership differs")
            packet["process"] = identity
            job = c.OwnedJob(process)
            c.write(output / "sleep-only-admission.json", {"process": identity, "owned_job_assigned": True})
            while process.poll() is None:
                c.require(time.monotonic() < deadline - 30, "Smoke child deadline exhausted")
                if bound is None:
                    bound = c.inspect_owned(ownership, identity, deadline=deadline)
                time.sleep(.1)
            packet["child_exit_code"] = process.returncode
            c.require(process.returncode == 0, "Actual sleep-only child failed")
            bound = bound or c.inspect_owned(ownership, identity, deadline=deadline)
            c.require(bound is not None, "Actual immutable creation binding missing")
            packet["audited_binding"] = bound
            packet["origin_closure"] = c.read(output / "sleep-only-origins.json")
            c.require(packet["origin_closure"]["status"] == "passed" and packet["origin_closure"]["process"] == identity,
                      "Actual wrapper source/physical identity differs")
    finally:
        if process is not None:
            try:
                packet["process_cleanup"] = c.stop_owned(process, identity, job, deadline=deadline)
            finally:
                if job is not None:
                    job.close()
            packet["container_cleanup"] = c.cleanup_container(bound, ownership, identity, aborted=True, deadline=deadline)
        packet["source_after"] = c.source(root, c.COMMITS["baseline"])
        c.require(packet["source_after"] == before, "Source changed during smoke")
        packet["status"] = "passed" if packet.get("child_exit_code") == 0 and packet.get("container_cleanup", {}).get("status") == "verified_absent" else "failed"
        c.write(output / "smoke.json", packet)
    print(json.dumps({"status": packet["status"], "report": str(output / "smoke.json"),
                      "sha256": c.sha(output / "smoke.json"), "no_database_or_financial_commands": True}))


if __name__ == "__main__":
    main()
