"""Actual gated interpreter/module preflight; no Docker, database or financial work."""
from __future__ import annotations

import argparse
import importlib
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from native_observations import in_owned_job, process_identity, require


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--admission", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    identity = process_identity(os.getpid())
    until = time.monotonic() + 15
    while not args.admission.exists() and time.monotonic() < until:
        time.sleep(.02)
    require(args.admission.exists(), "Parent ownership gate absent")
    admission = json.loads(args.admission.read_bytes())
    require(admission["process"] == identity and admission["owned_job_assigned"] is True and in_owned_job(),
            "Actual Popen PID/birth/physical executable/Job differs")
    root = args.root.resolve()
    sys.path.insert(0, str(root))
    names = ("reconforge.infrastructure.postgres_finance_core", "reconforge.infrastructure.postgres_finance_posting",
             "reconforge.benchmark.resource_sampling", "tests.erp_expansion_browser_seed")
    origins = {name: str(Path(importlib.import_module(name).__file__).resolve()) for name in names}
    require(all(Path(path).is_relative_to(root) for path in origins.values()), "Foreign application imports")
    dependencies = {name: str(Path(importlib.import_module(name).__file__).resolve()) for name in ("psycopg", "alembic", "sqlalchemy")}
    report = {"status": "passed", "no_docker_or_database_work": True, "process": identity, "pid": os.getpid(),
              "actual_job_membership": in_owned_job(), "executable": sys.executable,
              "physical_base_executable": sys._base_executable, "prefix": sys.prefix, "base_prefix": sys.base_prefix,
              "python": sys.version, "origins": origins, "dependencies": dependencies,
              "venv_launcher_environment_consumed": "__PYVENV_LAUNCHER__" not in os.environ}
    with args.report.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")


if __name__ == "__main__":
    main()
