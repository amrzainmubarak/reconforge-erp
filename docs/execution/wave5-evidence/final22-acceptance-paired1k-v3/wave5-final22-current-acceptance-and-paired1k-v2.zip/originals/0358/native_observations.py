"""Read-only host/process observations; no power-setting or workload mutations."""
from __future__ import annotations

import base64
import ctypes
import hashlib
import re
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


def require(value: bool, message: str) -> None:
    if not value:
        raise ValueError(message)


class FileTime(ctypes.Structure):
    _fields_ = [("low", ctypes.c_uint32), ("high", ctypes.c_uint32)]


def ticks(value: FileTime) -> int:
    return (int(value.high) << 32) | int(value.low)


class Power(ctypes.Structure):
    _fields_ = [("ac", ctypes.c_ubyte), ("battery", ctypes.c_ubyte),
                ("percent", ctypes.c_ubyte), ("saver", ctypes.c_ubyte),
                ("life", ctypes.c_uint32), ("full_life", ctypes.c_uint32)]


class Memory(ctypes.Structure):
    _fields_ = [("length", ctypes.c_uint32), ("memory_load_percent", ctypes.c_uint32),
                *[(name, ctypes.c_uint64) for name in ("total_physical_bytes", "available_physical_bytes",
                 "total_pagefile_bytes", "available_pagefile_bytes", "total_virtual_bytes",
                 "available_virtual_bytes", "available_extended_virtual_bytes")]]


def kernel() -> Any:
    require(sys.platform == "win32", "Live quiet-window controller requires Windows")
    load = getattr(ctypes, "WinDLL", None)
    require(callable(load), "Windows native loader unavailable")
    return load("kernel32", use_last_error=True)


def process_identity(pid: int) -> dict[str, Any]:
    require(type(pid) is int and pid > 0, "Invalid PID")
    if sys.platform != "win32":
        raw = Path(f"/proc/{pid}/stat").read_text()
        return {"pid": pid, "birth": raw.rsplit(")", 1)[1].split()[19],
                "executable": str(Path(f"/proc/{pid}/exe").resolve()), "method": "proc-starttime"}
    api = kernel()
    api.OpenProcess.argtypes = [ctypes.c_uint32, ctypes.c_int32, ctypes.c_uint32]
    api.OpenProcess.restype = ctypes.c_void_p
    api.CloseHandle.argtypes = [ctypes.c_void_p]
    api.CloseHandle.restype = ctypes.c_int32
    api.GetProcessTimes.argtypes = [ctypes.c_void_p, *[ctypes.POINTER(FileTime)] * 4]
    api.GetProcessTimes.restype = ctypes.c_int32
    api.QueryFullProcessImageNameW.argtypes = [ctypes.c_void_p, ctypes.c_uint32,
                                             ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_uint32)]
    api.QueryFullProcessImageNameW.restype = ctypes.c_int32
    handle = api.OpenProcess(0x1000, False, pid)
    require(bool(handle), "Cannot establish process ownership")
    try:
        created, ended, user, system = [FileTime() for _ in range(4)]
        require(bool(api.GetProcessTimes(handle, ctypes.byref(created), ctypes.byref(ended),
                                        ctypes.byref(user), ctypes.byref(system))), "Cannot read process birth")
        size = ctypes.c_uint32(32768)
        path = ctypes.create_unicode_buffer(size.value)
        require(bool(api.QueryFullProcessImageNameW(handle, 0, path, ctypes.byref(size))),
                "Cannot read process executable")
        return {"pid": pid, "birth": ticks(created), "executable": str(Path(path.value).resolve()),
                "method": "GetProcessTimes+QueryFullProcessImageNameW"}
    finally:
        api.CloseHandle(handle)


def observe_load() -> dict[str, Any]:
    row: dict[str, Any] = {"observed_at": datetime.now(UTC).isoformat(), "status": "unavailable"}
    try:
        api = kernel()
        api.GetSystemPowerStatus.argtypes = [ctypes.POINTER(Power)]
        api.GetSystemPowerStatus.restype = ctypes.c_int32
        power = Power()
        require(bool(api.GetSystemPowerStatus(ctypes.byref(power))), "Power read failed")
        raw = {name: int(getattr(power, name)) for name, _ in Power._fields_}
        row["power"] = {"status": "available", "raw": raw,
                        "ac_online": bool(power.ac) if power.ac in (0, 1) else None,
                        "battery_saver_on": bool(power.saver) if power.saver in (0, 1) else None}
        api.GetSystemTimes.argtypes = [ctypes.POINTER(FileTime)] * 3
        api.GetSystemTimes.restype = ctypes.c_int32
        idle, system, user = [FileTime() for _ in range(3)]
        require(bool(api.GetSystemTimes(ctypes.byref(idle), ctypes.byref(system), ctypes.byref(user))),
                "Host CPU observation failed")
        row["host_cpu_100ns"] = {"idle": ticks(idle), "kernel_including_idle": ticks(system), "user": ticks(user)}
        api.GlobalMemoryStatusEx.argtypes = [ctypes.POINTER(Memory)]
        api.GlobalMemoryStatusEx.restype = ctypes.c_int32
        memory = Memory()
        memory.length = ctypes.sizeof(Memory)
        require(bool(api.GlobalMemoryStatusEx(ctypes.byref(memory))), "Host memory read failed")
        row["host_memory"] = {name: int(getattr(memory, name)) for name, _ in Memory._fields_ if name != "length"}
        row["status"] = "available"
    except Exception as exc:
        row["failure_type"] = type(exc).__name__
    return row


def observe_scheme(*, deadline: float | None = None) -> dict[str, Any]:
    row = observe_load()
    command = ["powercfg", "/getactivescheme"]
    row["command"] = command
    try:
        def remaining() -> float:
            value = 10 if deadline is None else min(10, deadline - time.monotonic())
            require(value > 0, "No remaining scheme-observation budget")
            return value
        process = subprocess.run(command, capture_output=True, timeout=remaining(), check=False)
        row.update(exit_code=process.returncode,
                   stdout_base64=base64.b64encode(process.stdout).decode("ascii"),
                   stderr_base64=base64.b64encode(process.stderr).decode("ascii"),
                   stdout_sha256=hashlib.sha256(process.stdout).hexdigest(),
                   stderr_sha256=hashlib.sha256(process.stderr).hexdigest())
        require(process.returncode == 0, "Read-only powercfg failed")
        text = process.stdout.decode("utf-16") if process.stdout.startswith((b"\xff\xfe", b"\xfe\xff")) else process.stdout.decode("utf-8", errors="replace")
        matches = re.findall(r"\b[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}\b", text)
        require(len(matches) == 1, "Active scheme GUID missing or ambiguous")
        row["scheme_guid"] = matches[0].lower()
        query = ["powercfg", "/query", row["scheme_guid"], "SUB_PROCESSOR"]
        settings = subprocess.run(query, capture_output=True, timeout=remaining(), check=False)
        require(settings.returncode == 0, "Read-only processor power parameters unavailable")
        row["processor_power_parameters"] = {"command": query, "exit_code": settings.returncode,
            "stdout_base64": base64.b64encode(settings.stdout).decode("ascii"),
            "stdout_sha256": hashlib.sha256(settings.stdout).hexdigest(),
            "stderr_base64": base64.b64encode(settings.stderr).decode("ascii"),
            "stderr_sha256": hashlib.sha256(settings.stderr).hexdigest()}
    except Exception as exc:
        row.update(status="unavailable", failure_type=type(exc).__name__)
    return row


def validate_power(row: dict[str, Any], guid: str | None = None) -> str | None:
    require(row.get("status") == "available", "Host observation unavailable")
    power = row.get("power")
    require(isinstance(power, dict) and power.get("status") == "available"
            and power.get("ac_online") is True and power.get("battery_saver_on") is False,
            "Observed AC/saver-off required")
    if "command" in row:
        require(row["command"] == ["powercfg", "/getactivescheme"] and row["exit_code"] == 0,
                "Scheme command failed or changed")
        actual = row.get("scheme_guid")
        require(isinstance(actual, str) and bool(re.fullmatch(r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}", actual)),
                "Invalid scheme GUID")
        require(guid is None or actual == guid, "Active scheme changed")
        return actual
    return guid


class OwnedJob:
    """Retained Windows Job handle binds only this gated child's process tree."""

    def __init__(self, process: Any) -> None:
        class Basic(ctypes.Structure):
            _fields_ = [("process_time", ctypes.c_int64), ("job_time", ctypes.c_int64),
                        ("flags", ctypes.c_uint32), ("minimum", ctypes.c_size_t), ("maximum", ctypes.c_size_t),
                        ("active", ctypes.c_uint32), ("affinity", ctypes.c_size_t),
                        ("priority", ctypes.c_uint32), ("scheduling", ctypes.c_uint32)]
        class Extended(ctypes.Structure):
            _fields_ = [("basic", Basic), ("io", ctypes.c_uint64 * 6),
                        ("process_memory", ctypes.c_size_t), ("job_memory", ctypes.c_size_t),
                        ("peak_process_memory", ctypes.c_size_t), ("peak_job_memory", ctypes.c_size_t)]
        self.api = kernel()
        self.api.CreateJobObjectW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p]
        self.api.CreateJobObjectW.restype = ctypes.c_void_p
        self.api.SetInformationJobObject.argtypes = [ctypes.c_void_p, ctypes.c_int32, ctypes.c_void_p, ctypes.c_uint32]
        self.api.SetInformationJobObject.restype = ctypes.c_int32
        self.api.AssignProcessToJobObject.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        self.api.AssignProcessToJobObject.restype = ctypes.c_int32
        self.api.TerminateJobObject.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
        self.api.TerminateJobObject.restype = ctypes.c_int32
        self.api.CloseHandle.argtypes = [ctypes.c_void_p]
        self.api.CloseHandle.restype = ctypes.c_int32
        self.handle = self.api.CreateJobObjectW(None, None)
        require(bool(self.handle), "Cannot create owned process job")
        try:
            limits = Extended()
            limits.basic.flags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
            require(bool(self.api.SetInformationJobObject(self.handle, 9, ctypes.byref(limits), ctypes.sizeof(limits))),
                    "Cannot establish kill-on-close ownership")
            require(bool(self.api.AssignProcessToJobObject(self.handle, int(process._handle))),
                    "Cannot atomically bind retained child handle to owned job")
        except Exception:
            self.close()
            raise

    def terminate(self) -> None:
        require(bool(self.handle) and bool(self.api.TerminateJobObject(self.handle, 130)),
                "Owned job termination unverified")

    def close(self) -> None:
        if self.handle:
            self.api.CloseHandle(self.handle)
            self.handle = None


def in_owned_job() -> bool:
    api = kernel()
    api.GetCurrentProcess.argtypes = []
    api.GetCurrentProcess.restype = ctypes.c_void_p
    api.IsProcessInJob.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.POINTER(ctypes.c_int32)]
    api.IsProcessInJob.restype = ctypes.c_int32
    value = ctypes.c_int32()
    require(bool(api.IsProcessInJob(api.GetCurrentProcess(), None, ctypes.byref(value))), "Cannot observe process Job membership")
    return bool(value.value)
