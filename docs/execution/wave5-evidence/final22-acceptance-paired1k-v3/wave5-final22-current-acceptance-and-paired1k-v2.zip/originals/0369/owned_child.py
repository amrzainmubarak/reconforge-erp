"""Transparent launcher for an unchanged common harness, with audited exact ownership."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import runpy
import signal
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from uuid import uuid4

sys.path.insert(0, str(Path(__file__).resolve().parent))
from native_observations import in_owned_job, process_identity, require


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--harness", type=Path, required=True)
    parser.add_argument("--harness-sha256", required=True)
    parser.add_argument("--ownership", type=Path, required=True)
    parser.add_argument("--origin-report", type=Path, required=True)
    parser.add_argument("--runtime-root", type=Path, required=True)
    parser.add_argument("--image", required=True)
    parser.add_argument("--admission", type=Path, required=True)
    parser.add_argument("--physical-executable", type=Path, required=True)
    parser.add_argument("--physical-sha256", required=True)
    parser.add_argument("--virtual-executable", type=Path, required=True)
    parser.add_argument("--smoke-ownership", action="store_true")
    args, forwarded = parser.parse_known_args()
    require(forwarded and forwarded[0] == "--", "Explicit harness argv separator required")
    harness, root = args.harness.resolve(), args.runtime_root.resolve()
    require(hashlib.sha256(harness.read_bytes()).hexdigest() == args.harness_sha256, "Common harness changed")
    identity = process_identity(os.getpid())
    require(Path(identity["executable"]).resolve() == args.physical_executable.resolve()
            == Path(sys._base_executable).resolve(), "Physical launcher executable differs")
    require(hashlib.sha256(args.physical_executable.read_bytes()).hexdigest() == args.physical_sha256,
            "Physical executable bytes changed")
    require(Path(sys.executable).resolve() == args.virtual_executable.resolve()
            and Path(sys.prefix).resolve() == args.virtual_executable.resolve().parents[1], "Intended venv context differs")
    ownership = args.ownership.resolve()
    require(not ownership.exists(), "Owned resource provenance already exists")
    # Parent must bind the retained process handle to its kill-on-close Windows
    # Job before this wrapper can create ANY subprocess/container.
    admission_deadline = time.monotonic() + 15
    while not args.admission.exists() and time.monotonic() < admission_deadline:
        time.sleep(.05)
    require(args.admission.is_file(), "Parent process-tree ownership admission absent")
    admission = json.loads(args.admission.read_bytes())
    require(admission["process"] == identity and admission["owned_job_assigned"] is True and in_owned_job(),
            "Parent ownership admission differs")
    original_run = subprocess.run
    pending_creation: list[str] | None = None

    def audit(event: str, values: tuple[object, ...]) -> None:
        if event != "subprocess.Popen" or pending_creation is None:
            return
        argv = values[1]
        require((isinstance(argv, str) and argv == subprocess.list2cmdline(pending_creation))
                or (isinstance(argv, (list, tuple)) and list(argv) == pending_creation),
                "Native Popen command differs from original typed Docker creation")
        packet = {"status": "matched", "process": identity, "audit_argument_form": type(argv).__name__,
                  "original_typed_command_sha256": hashlib.sha256(json.dumps(pending_creation, separators=(",", ":")).encode()).hexdigest(),
                  "method": "literal audit comparison against list2cmdline(original typed argv); no parsing"}
        with ownership.with_suffix(".audit-crosscheck.json").open("x", encoding="utf-8", newline="\n") as stream:
            json.dump(packet, stream, indent=2)
            stream.write("\n")

    def record_intent(words: list[str]) -> None:
        require("--name" in words and "--label" in words, "Unexpected Docker creation")
        name = words[words.index("--name") + 1]
        label = words[words.index("--label") + 1]
        require(isinstance(name, str) and bool(re.fullmatch(r"reconforge-enterprise-finance-[0-9a-f]{12}", name)),
                "Unexpected owned container name")
        require(label == "reconforge.owner=enterprise-finance-benchmark" and args.image in words,
                "Unexpected owned image or label")
        absence = original_run(["docker", "container", "ls", "--all", "--no-trunc", "--filter", f"name=^/{name}$",
                                "--format", "{{.ID}}"], capture_output=True, timeout=5, check=False)
        require(absence.returncode == 0 and not absence.stdout.strip(), "Preexisting exact container name; refuse creation")
        packet = {"schema_version": "audited-final22-owned-container-v1", "process": identity,
                  "observed_at": datetime.now(UTC).isoformat(), "name": name, "image": args.image,
                  "label": label, "command_sha256": hashlib.sha256(json.dumps(words, separators=(",", ":")).encode()).hexdigest(),
                  "pre_spawn_exact_name_absent": True,
                  "method": "original typed subprocess.run argv recorded before Docker creation; native audit crosschecked"}
        ownership.parent.mkdir(parents=True, exist_ok=True)
        with ownership.open("x", encoding="utf-8", newline="\n") as stream:
            json.dump(packet, stream, indent=2, allow_nan=False)
            stream.write("\n")

    def observed_run(*values: object, **options: object) -> object:
        # Arguments and CompletedProcess are forwarded unchanged. Only the
        # successful Docker creation's returned immutable ID is recorded. No
        # environment or arbitrary stdout is retained by this observer.
        nonlocal pending_creation
        argv = values[0] if values else options.get("args")
        creation = isinstance(argv, (list, tuple)) and len(argv) > 1 and Path(str(argv[0])).name.lower() in ("docker", "docker.exe") and argv[1] == "run"
        if creation:
            require(all(isinstance(word, str) for word in argv), "Typed Docker creation words required")
            record_intent(list(argv))
            pending_creation = list(argv)
        try:
            result = original_run(*values, **options)
        finally:
            pending_creation = None
        if creation:
            require(result.returncode == 0, "Docker creation did not acknowledge ownership")
            response = result.stdout.decode() if isinstance(result.stdout, bytes) else result.stdout
            require(isinstance(response, str) and bool(re.fullmatch(r"[0-9a-f]{64}", response.strip())),
                    "Docker creation response ID absent or malformed")
            packet = {"schema_version": "final22-docker-creation-response-v1", "process": identity,
                      "audit_sha256": hashlib.sha256(ownership.read_bytes()).hexdigest(), "container_id": response.strip(),
                      "returncode": result.returncode, "response_sha256": hashlib.sha256(response.encode()).hexdigest(),
                      "method": "unchanged successful subprocess.run Docker creation response"}
            with ownership.with_suffix(".created.json").open("x", encoding="utf-8", newline="\n") as stream:
                json.dump(packet, stream, indent=2)
                stream.write("\n")
        return result

    sys.addaudithook(audit)
    subprocess.run = observed_run
    if hasattr(signal, "SIGBREAK"):
        signal.signal(signal.SIGBREAK, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
    sys.argv = [str(harness), *forwarded[1:]]
    exit_code = 1
    try:
        if args.smoke_ownership:
            import importlib
            argv = ["docker", "run", "--detach", "--rm", "--name", "reconforge-enterprise-finance-" + uuid4().hex[:12],
                    "--label", "reconforge.owner=enterprise-finance-benchmark", "--entrypoint", "sleep", args.image, "30"]
            completed = subprocess.run(argv, cwd=root, capture_output=True, text=True, check=True, timeout=15)
            sys.path.insert(0, str(root))
            for module in ("reconforge.infrastructure.postgres_finance_core", "reconforge.infrastructure.postgres_finance_posting",
                           "reconforge.benchmark.resource_sampling", "tests.erp_expansion_browser_seed"):
                importlib.import_module(module)
            print(json.dumps({"status": "smoke_created", "container_id": completed.stdout.strip(),
                              "no_database_or_financial_commands": True}), flush=True)
            exit_code = 0
        else:
            runpy.run_path(str(harness), run_name="__main__")
    except SystemExit as exc:
        exit_code = exc.code if type(exc.code) is int else 1
    finally:
        tracked = set(subprocess.check_output(["git", "ls-files", "-z"], cwd=root, timeout=30).decode().split("\0"))
        origins = []
        foreign = []
        for name, module in sorted(sys.modules.items()):
            if name == "reconforge" or name.startswith("reconforge.") or name.startswith("tests."):
                filename = getattr(module, "__file__", None)
                if filename is not None:
                    actual = Path(filename).resolve()
                    row = {"module": name, "path": str(actual)}
                    origins.append(row)
                    if not actual.is_relative_to(root) or actual.relative_to(root).as_posix() not in tracked:
                        foreign.append(row)
        required = {"reconforge.infrastructure.postgres_finance_core", "reconforge.infrastructure.postgres_finance_posting",
                    "reconforge.benchmark.resource_sampling", "tests.erp_expansion_browser_seed"}
        status = "passed" if not foreign and required.issubset({row["module"] for row in origins}) else "failed"
        value = {"schema_version": "final22-runtime-module-origin-closure-v1", "status": status,
                 "runtime_root": str(root), "process": identity, "origins": origins, "foreign_modules": foreign,
                 "harness_sha256_after": hashlib.sha256(harness.read_bytes()).hexdigest()}
        with args.origin_report.open("x", encoding="utf-8", newline="\n") as stream:
            json.dump(value, stream, indent=2)
            stream.write("\n")
        if status != "passed":
            exit_code = 1
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
