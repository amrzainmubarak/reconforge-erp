"""File-only independent review of original frozen FINAL22 V4 paired evidence.

Stdlib only: no application imports, subprocesses, network, database or live
observation. All claimed observations remain bound to original raw file SHA256.
"""
from __future__ import annotations

import base64
import hashlib
import json
import math
import re
import statistics
import sys
from datetime import datetime
from decimal import Decimal
from pathlib import Path

OWN = Path(__file__).resolve().parent
ROOT = Path(r"C:\Users\LOQ\.codex\worktrees\reconforge-integration-wave5\reconforge-erp")
PACKET = ROOT / "output/wave5-final22-paired-1k-v4"
TOOL = OWN / "wave5-final22-pair-readiness-v4-20261012"
TRUSTED = {
    "manifest.json": "7ce625b4d78de4f64a18b2e4c215b0c69b2ec37523774280d73560b52bde171b",
    "offline-proof.json": "1ced618170c8f6ac2b2da543c94bfe29dce2dd7ba10322ac12c3132bda79f26d",
    "1-baseline/result.json": "55d3b1043dfe29344e2f242b3f928a2d9729eaae7ec95966ab3ee51e86a46d78",
    "1-candidate/result.json": "959f2f63eb4a8b68b8c1755c581f247d8a8d3a0d446bbbfebaf7c212a449eb3f",
    "2-candidate/result.json": "71c057ab3c5c04bae0061e39929643b908028cf3d36e4e9d078318c8954db4a6",
    "2-baseline/result.json": "2b09c730609990a853a13d6bd26b28948054b0ff0302e43a05137085d7d461ca",
    "3-baseline/result.json": "0dc1877e1ff08919766ca09e70ba405817125d8fd29c38ea8ed846463a5f5a6d",
    "3-candidate/result.json": "c0d3054a6efb3bccd0f46adec3986c6d7db4ccebb499decf38dfb6688dfa7a65",
}
COMMITS = {"baseline": "6362724f2337a79c3d7569574f7bf9591a018524", "candidate": "22ebfd78e293aafa13d81b3a0bbf287491951115"}
SOURCE = {"baseline": "65911f44fdf66fe5100225a8538934a89c8788a15342fc2fb64a1a9b5b32f6c8", "candidate": "cf9a1280d9a3138ca6e908708fd393ec75268fa198140c070098aa3056723652"}
ORDER = [(1, "baseline"), (1, "candidate"), (2, "candidate"), (2, "baseline"), (3, "baseline"), (3, "candidate")]
IMAGE = "postgres:17.11-alpine@sha256:aa90e97ee862e558111d34cfb8b2c4bec768c2b039fb791341686928560263b3"
HARNESSSHA = "7bce2382df24d439d39386f0e02c07bf362c4f451649dbd8d7f225c8a920396b"
INDEX: dict[str, dict[str, object]] = {}


def need(condition: object, message: str) -> None:
    if not condition:
        raise ValueError(message)


def digest(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def pairs(values: list[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in values:
        need(key not in result, f"Duplicate JSON member: {key}")
        result[key] = value
    return result


def read(path: Path, expected: str | None = None) -> dict:
    actual = digest(path)
    need(expected is None or actual == expected, f"Original file hash mismatch: {path}")
    INDEX[str(path)] = {"sha256": actual, "bytes": path.stat().st_size}
    data = json.loads(path.read_bytes(), object_pairs_hook=pairs, parse_constant=lambda _: need(False, "Nonfinite JSON"))
    need(isinstance(data, dict), "Expected JSON object")
    return data


def referenced(relative: str, expected: str | None = None) -> dict:
    need(relative and ".." not in Path(relative).parts and "\\" not in relative and ":" not in relative, "Unsafe relative evidence path")
    path = (PACKET / relative).resolve()
    need(path.is_relative_to(PACKET), "Evidence path escapes")
    return read(path, expected)


def quantiles(raw: list[float]) -> dict[str, float]:
    need(raw and all(type(x) in (float, int) and math.isfinite(x) and x > 0 for x in raw), "Invalid latency vector")
    ordered = sorted(raw)
    return {label: ordered[math.ceil(len(raw) * fraction) - 1] for label, fraction in (("p50", .5), ("p95", .95), ("p99", .99))}


def minor(count: int) -> str:
    return str(sum(1 + int.from_bytes(hashlib.sha256(f"enterprise-native-v1:{index}".encode()).digest()[:8], "big") % 1_000_000 for index in range(count)))


def raw_cgroup(value: dict) -> dict:
    raw = value["raw"]
    cpu = {line.split()[0]: int(line.split()[1]) for line in raw["cpu"].splitlines()}
    io = {}
    for line in raw["io"].splitlines():
        device, *words = line.split()
        need(device not in io, "Repeated cgroup device")
        io[device] = {key: int(number) for key, number in (word.split("=", 1) for word in words)}
    network = {}
    for line in raw["network"].splitlines():
        if ":" in line:
            interface, counters = line.split(":", 1)
            words = counters.split()
            need(len(words) == 16 and interface.strip() not in network, "Invalid network counter row")
            network[interface.strip()] = {"received_bytes": int(words[0]), "transmitted_bytes": int(words[8])}
    parsed = {"cpu_microseconds": cpu, "memory_current_bytes": int(raw["memory_current"]), "container_lifetime_peak_memory_bytes": int(raw["memory_peak"]), "block_io_by_device": io, "network_by_interface": network}
    need(all(value["parsed"][key] == expected for key, expected in parsed.items()), "Parsed resource counter differs from original raw text")
    return parsed


def docker_memory(raw: str) -> int:
    number, unit = re.fullmatch(r"([0-9.]+)([A-Za-z]+)", raw.strip()).groups()
    scale = {"B": 1, "kB": 1000, "MB": 1000**2, "GB": 1000**3, "KiB": 1024, "MiB": 1024**2, "GiB": 1024**3}[unit]
    return int((Decimal(number) * scale).to_integral_value())


def summarize(values: list[float]) -> dict:
    need(values and all(math.isfinite(x) for x in values), "Missing/invalid sample population")
    return {"count": len(values), "min": min(values), "median": statistics.median(values), "max": max(values)}


def power(value: dict) -> None:
    need(value["status"] == "available" and value["ac_online"] is True and value["battery_saver_on"] is False, "Observed AC/saver changed")


def main() -> dict:
    manifest = referenced("manifest.json", TRUSTED["manifest.json"])
    original = referenced("offline-proof.json", TRUSTED["offline-proof.json"])
    replay = [read(OWN / f"wave5-final22-paired-independent-{mode}.json", TRUSTED["offline-proof.json"]) for mode in ("I", "IO")]
    need(replay[0] == replay[1] == original, "Original normal/optimized independent replay differs")
    need(manifest["status"] == "passed" and manifest["commits"] == COMMITS and manifest["performance_comparison_accepted"] is False and manifest["cost_per_success_currency"] is None, "Manifest contract drift")
    plan = read(TOOL / "readiness-v4.json", "7bdd6ee3da407966e2377b3757610e75f3dfea07d984a2284baa92d340405473")
    for name, expected in plan["tool_sha256"].items():
        need(digest(TOOL / name) == expected, "Pinned original verifier/controller source drift")
        INDEX[str(TOOL / name)] = {"sha256": expected, "bytes": (TOOL / name).stat().st_size}
    need(digest(ROOT / ".github/scripts/benchmark_enterprise_finance.py") == HARNESSSHA == plan["harness_sha256"], "Common harness source drift")
    need(manifest["sources_after"] == plan["sources"], "Source fingerprint before/after custody drift")
    matched_fields = ("profile", "seed", "counts", "workers", "repetitions", "posting_warmup_cycles", "max_seconds", "image", "python", "platform", "logical_cpus", "processor", "architecture", "docker_version", "docker_engine_resources", "postgres_version", "postgres_configuration", "runtime_role_flags")
    common, seen_effects, seen_containers, previous_end = None, set(), set(), None
    runs = []
    scheme, settings = None, None
    all_requests = all_visits = 0
    need(len(manifest["runs"]) == 6, "Incomplete six-run population")
    for record, expected_order in zip(manifest["runs"], ORDER, strict=True):
        repetition, variant = expected_order
        label = f"{repetition}-{variant}"
        need((record["repetition"], record["variant"]) == expected_order and record["child_exit_code"] == 0, "Run order/failure drift")
        report = referenced(record["report"], TRUSTED[record["report"]])
        need(record["report_sha256"] == TRUSTED[record["report"]], "Manifest/raw hash custody mismatch")
        need(report["source_commit"] == report["source_commit_after"] == COMMITS[variant] and report["source_sha256"] == report["source_sha256_after"] == SOURCE[variant], "Financial runtime source differs")
        need(report["harness_sha256"] == report["harness_sha256_after"] == HARNESSSHA and report["source_unchanged"] is True and report["owned_container_removed"] is True, "Source/container lifecycle drift")
        need(report["revision"] == ("0132_pg_stock_inverse_dispatch" if variant == "baseline" else "0136_pg_inventory_scope"), "Wrong schema head")
        config = {key: report[key] for key in matched_fields}
        common = config if common is None else common
        need(config == common and report["image"] == IMAGE, "Actual device/workload/DB configuration differs")
        started, ended = [datetime.fromisoformat(report[key]) for key in ("started_at", "finished_at")]
        need(started.tzinfo and ended.tzinfo and started < ended and (previous_end is None or previous_end <= started), "Original workloads overlap")
        previous_end = ended
        posting, warm = report["posting"], report["posting_warmup"]
        need(posting["completed_indices"] == list(range(1000)) and posting["requested_cycles"] == posting["admitted_cycles"] == posting["completed_cycles"] == 1000, "Incomplete posting population")
        need(posting["error_count"] == posting["not_admitted_cycles"] == 0 and posting["failed_cycles"] == [], "Posting failure")
        need(posting["expected"] == dict.fromkeys(("debit_minor", "credit_minor", "cash_minor", "equity_minor"), minor(1000)), "Independent financial integer oracle differs")
        need(warm["completed_cycles"] == 20 and warm["indices"] == list(range(1000, 1020)) and warm["outside_measured_population"] is True, "Warmup population drift")
        effects = posting["ordered_effect_ids"] + warm["effect_ids"]
        need(len(effects) == len(set(effects)) == 1020 and not set(effects) & seen_effects, "Repeated/lost measured or warmup effect")
        seen_effects.update(effects)
        need(len(posting["raw_cycle_latency_seconds"]) == 1000 and quantiles(posting["raw_cycle_latency_seconds"]) == posting["cycle_latency_seconds"], "Posting raw quantile drift")
        need(len(warm["raw_cycle_latency_seconds"]) == 20, "Warmup raw timing missing")
        requests = visits = 0
        for profile in report["verified_reads"]:
            count = profile["count"]
            need(count in (100, 1000) and profile["expected"] == dict.fromkeys(posting["expected"], minor(count)), "Independent read-prefix oracle mismatch")
            prefix = json.dumps(posting["ordered_effect_ids"][:count], sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
            need(hashlib.sha256(prefix).hexdigest() == profile["dataset_effect_ids_sha256"], "Read-prefix effect custody mismatch")
            for mode, samples in profile["samples"].items():
                need([row["repetition"] for row in samples] == [0, 1, 2], "Read repetition drift")
                for sample in samples:
                    need(sample["status"] == "complete" and sample["error_count"] == 0 and sample["effects"] == sample["requested_effects"] == count, "Read failure")
                    need(sample["debit_minor"] == sample["credit_minor"] == minor(count) and sample["effects_digest"] == profile["financial_effects_digest"], "Read balance/effect digest mismatch")
                    raw = sample["raw_request_latency_seconds"]
                    need(len(raw) == (count if mode == "per_effect_baseline" else count // 100) and quantiles(raw) == sample["request_latency_seconds"], "Read raw quantile/count drift")
                    requests += len(raw)
                    visits += count
        need(requests == 3333 and visits == 6600, "Verified read population incomplete")
        all_requests += requests
        all_visits += visits
        samples = report["resource_sampling"]["raw_samples"]
        need(report["resource_sampling"]["status"] == "complete" and report["resource_sampling"]["errors"] == [] and report["resource_sampling"]["thread_still_running"] is False, "Resource collector incomplete")
        before, after = [raw_cgroup(report[key]) for key in ("posting_container_counters_before", "posting_container_counters_after")]
        need(set(before["block_io_by_device"]) == set(after["block_io_by_device"]) and set(before["network_by_interface"]) == set(after["network_by_interface"]), "Resource device/interface population changed")
        io_delta = {key: sum(after["block_io_by_device"][device][key] - value[key] for device, value in before["block_io_by_device"].items()) for key in ("rbytes", "wbytes", "rios", "wios", "dbytes", "dios")}
        network_delta = {key: sum(after["network_by_interface"][device][key] - value[key] for device, value in before["network_by_interface"].items()) for key in ("received_bytes", "transmitted_bytes")}
        need(all(value >= 0 for value in [*io_delta.values(), *network_delta.values()]), "Resource counters decreased")
        need(after["cpu_microseconds"]["usage_usec"] >= before["cpu_microseconds"]["usage_usec"], "CPU counter decreased")
        for first, last in zip(samples, samples[1:]):
            need(first["elapsed_seconds"] < last["elapsed_seconds"] and first["client_cpu_seconds"] <= last["client_cpu_seconds"], "Sample window order/reset")
            need(all(last["postgres_database_counters"][key] >= value for key, value in first["postgres_database_counters"].items()), "DB counter reset")
            need(all(int(last["postgres_wal_counters"][key]) >= int(value) for key, value in first["postgres_wal_counters"].items()), "WAL counter reset")
        for sample in samples:
            power(sample["host_processor"]["power"])
            need(sample["client_pid"] == record["process"]["pid"], "Observed client process differs")
        frequencies = [s["host_processor"]["processor_frequency_mhz"] for s in samples if s["host_processor"]["processor_frequency_mhz"] is not None]
        performance = [s["host_processor"]["processor_performance_percent"] for s in samples if s["host_processor"]["processor_performance_percent"] is not None]
        load_intervals = []
        observations = record["host_load_observations"]
        for observation in observations:
            power(observation["power"])
        for a, b in zip(observations, observations[1:]):
            x, y = a["host_cpu_100ns"], b["host_cpu_100ns"]
            total = y["kernel_including_idle"] + y["user"] - x["kernel_including_idle"] - x["user"]
            idle = y["idle"] - x["idle"]
            need(total > 0 and 0 <= idle <= total, "Host CPU counter reset")
            load_intervals.append({"start": a["observed_at"], "end": b["observed_at"], "busy_percent": (total - idle) / total * 100, "ending_memory_load_percent": b["host_memory"]["memory_load_percent"]})
        for phase in ("before", "after"):
            binding = record[f"environment_{phase}"]
            sidecar = referenced(binding["path"], binding["sha256"])
            power(sidecar["power"])
            scheme = sidecar["scheme_guid"] if scheme is None else scheme
            need(sidecar["scheme_guid"] == scheme, "Power scheme changed")
            for raw_info in (sidecar, sidecar["processor_power_parameters"]):
                need(hashlib.sha256(base64.b64decode(raw_info["stdout_base64"], validate=True)).hexdigest() == raw_info["stdout_sha256"], "Original powercfg stdout hash mismatch")
            settings = sidecar["processor_power_parameters"]["stdout_sha256"] if settings is None else settings
            need(sidecar["processor_power_parameters"]["stdout_sha256"] == settings, "Processor power settings drift")
        cleanup = record["cleanup"]
        container = cleanup["container_id"]
        need(cleanup["status"] == "verified_absent" and cleanup["action"] == "already_absent" and re.fullmatch(r"[0-9a-f]{64}", container) and container not in seen_containers, "Owned cleanup/fresh container failed")
        seen_containers.add(container)
        owned = referenced(f"{label}-ownership.json", cleanup["ownership_audit_sha256"])
        creation = referenced(f"{label}-ownership.created.json", cleanup["creation_response_sha256"])
        audit = referenced(f"{label}-ownership.audit-crosscheck.json", cleanup["native_audit_crosscheck_sha256"])
        admission = referenced(f"{label}-admission.json")
        need(owned["process"] == creation["process"] == audit["process"] == admission["process"] == record["process"] and admission["owned_job_assigned"] is True, "Actual PID/birth/Job ownership differs")
        need(creation["container_id"] == container and creation["audit_sha256"] == cleanup["ownership_audit_sha256"] and creation["returncode"] == 0, "Created immutable CID differs")
        need(audit["status"] == "matched" and audit["audit_argument_form"] == "str" and audit["original_typed_command_sha256"] == owned["command_sha256"], "Actual Windows original command audit differs")
        need(owned["pre_spawn_exact_name_absent"] is True and owned["image"] == IMAGE and cleanup["bound_inspection"]["Id"] == container and cleanup["bound_inspection"]["Config"]["Image"] == IMAGE, "Creation custody differs")
        need(record["process_cleanup"]["status"] == "already_exited" and record["process_cleanup"]["forced"] is False and record["process_cleanup"]["identity"] == record["process"], "Process lifecycle incomplete")
        origins = referenced(record["origins"]["path"], record["origins"]["sha256"])
        need(origins["status"] == "passed" and origins["foreign_modules"] == [] and origins["process"] == record["process"] and origins["harness_sha256_after"] == HARNESSSHA, "Actual module-origin closure failed")
        runtime_root = Path(report["runtime_root"]).resolve()
        need(all(Path(row["path"]).resolve().is_relative_to(runtime_root) for row in origins["origins"]), "Actual foreign app module loaded")
        metrics = {"posting_seconds": posting["seconds"], "throughput": 1000 / posting["seconds"], **quantiles(posting["raw_cycle_latency_seconds"]), "client_cpu_seconds": posting["client_process_cpu_seconds"], "container_cpu_seconds": (after["cpu_microseconds"]["usage_usec"] - before["cpu_microseconds"]["usage_usec"]) / 1_000_000, "bounded_batch_read_seconds": statistics.median(s["seconds"] for s in report["verified_reads"][-1]["samples"]["bounded_batch"]), "client_lifetime_peak_memory_bytes": max(s["client_memory"]["process_lifetime_peak_rss_bytes"] for s in samples), "container_lifetime_peak_memory_bytes": after["container_lifetime_peak_memory_bytes"], "sampled_client_rss_peak_bytes": max(s["client_memory"]["rss_bytes"] for s in samples), "sampled_docker_ram_peak_bytes": max(docker_memory(s["docker_raw_counters"]["MemUsage"].split("/")[0]) for s in samples), "wal_bytes_sample_window_delta": int(samples[-1]["postgres_wal_counters"]["wal_bytes"]) - int(samples[0]["postgres_wal_counters"]["wal_bytes"]), "client_cpu_sample_window_seconds": samples[-1]["client_cpu_seconds"] - samples[0]["client_cpu_seconds"], "database_bytes": report["database_bytes"], **{f"cgroup_io_{key}": value for key, value in io_delta.items()}, **{f"cgroup_network_{key}": value for key, value in network_delta.items()}}
        for key, value in metrics.items():
            if key in record["verified"]:
                need(record["verified"][key] == value, "Recomputed metric differs from original verified field")
        runs.append({"run": label, "variant": variant, "raw_report_sha256": TRUSTED[record["report"]], "financial_oracle_minor": minor(1000), "read_prefix_100_minor": minor(100), "fresh_effects": 1020, "measured_cycles": 1000, "outside_measured_warmup_cycles": 20, "verified_read_requests": requests, "metrics": metrics, "sample_window": {"first_elapsed_seconds": samples[0]["elapsed_seconds"], "last_elapsed_seconds": samples[-1]["elapsed_seconds"], "samples": len(samples), "database_counter_deltas": {key: samples[-1]["postgres_database_counters"][key] - value for key, value in samples[0]["postgres_database_counters"].items()}, "sampled_lock_waiting_sessions_max": max(s["postgres_wait_event_type_sessions"].get("Lock", 0) for s in samples)}, "frequency_mhz": summarize(frequencies), "processor_performance_percent": summarize(performance), "host_cpu_busy_percent": summarize([x["busy_percent"] for x in load_intervals]), "host_busy_top_three_intervals": sorted(load_intervals, key=lambda x: x["busy_percent"], reverse=True)[:3], "host_memory_load_percent": summarize([x["host_memory"]["memory_load_percent"] for x in observations]), "posting_latency_over_5_seconds_count": sum(x > 5 for x in posting["raw_cycle_latency_seconds"]), "posting_latency_max_seconds": max(posting["raw_cycle_latency_seconds"]), "container_id": container, "cleanup": "captured immutable CID already absent; actual process exited without forced stop", "timestamps": {"start": report["started_at"], "end": report["finished_at"]}})
    medians = {variant: {key: statistics.median(run["metrics"][key] for run in runs if run["variant"] == variant) for key in runs[0]["metrics"]} for variant in COMMITS}
    changes = {key: (Decimal(str(medians["candidate"][key])) / Decimal(str(medians["baseline"][key])) - 1) * 100 if medians["baseline"][key] != 0 else None for key in medians["baseline"]}
    need(all(original["medians"][variant][key] == medians[variant][key] for variant in COMMITS for key in original["medians"][variant]), "Independent medians differ")
    final = referenced("pair.json")
    need(final["status"] == "passed" and final["manifest_sha256"] == TRUSTED["manifest.json"] and final["offline_proof_sha256"] == TRUSTED["offline-proof.json"] and final["wall_seconds"] < manifest["overall_wall_seconds"] - manifest["cleanup_reserve_seconds"], "Overall bounded deadline closure differs")
    need(len(seen_effects) == 6120 and len(seen_containers) == 6 and all_requests == 19998 and all_visits == 39600, "Six-run financial/custody count differs")
    return {"schema_version": "wave5-final22-paired-independent-file-review-v1", "status": "passed", "reviewer_scope": "Retained original bytes only; stdlib, no subprocess/network/database/live observer/application imports", "commits": COMMITS, "tracked_source_fingerprints": SOURCE, "manifest_sha256": TRUSTED["manifest.json"], "original_offline_proof_sha256": TRUSTED["offline-proof.json"], "original_oracle_replay": {"normal_and_optimized_outputs_byte_identical_to_original": True, "isolated_modes": ["-I", "-I -O"], "pinned_readiness_sha256": "7bdd6ee3da407966e2377b3757610e75f3dfea07d984a2284baa92d340405473"}, "counts": {"measured_cycles": 6000, "outside_measured_warmup_cycles": 120, "fresh_effects": 6120, "fresh_owned_containers": 6, "verified_read_requests": all_requests, "verified_effect_visits": all_visits}, "financial_oracles_minor": {"100": minor(100), "1000": minor(1000)}, "runs": runs, "descriptive_medians_of_three_run_metrics": medians, "descriptive_candidate_change_percent": {key: str(value) if value is not None else None for key, value in changes.items()}, "observed_environment": {"power_scheme_guid": scheme, "processor_settings_original_stdout_sha256": settings, "observed_ac_online_all": True, "observed_battery_saver_off_all": True, "initial_host_busy_percent": manifest["initial_host_busy_percent"], "final_controller_wall_seconds": final["wall_seconds"], "wall_deadline_seconds": manifest["overall_wall_seconds"], "cleanup_reserve_seconds": manifest["cleanup_reserve_seconds"]}, "performance_comparison_accepted": False, "cost_per_success_currency": None, "resource_windows": {"client_cpu": "posting process_time includes concurrent observer thread; excludes waits and external subprocess CPU", "container_cpu_io_network": "raw dedicated-cgroup before/after bracketing interval includes read-only exec/observer overhead; boundaries differ from client posting process_time", "sampled_db_wal_and_peaks": "10-second sample window spans warmup, posting and reads; monotonic deltas verified, short spikes may be missed", "memory": "client lifetime working-set/cgroup lifetime peaks include setup/migrations/warmup; Docker memory is rounded display parsed with decimal units", "host_busy": "GetSystemTimes cumulative host counters differenced across parent observations during complete child lifetime, not isolated ERP CPU", "frequency": "available host-total PDH frequency/performance samples; priming null excluded, not per-core clock or thermal measurement"}, "limits": ["Observed medians are descriptive. C2 contains 100% host-busy and 98% memory-load observations; source, AC, saver, scheme and processor-setting equality do not isolate outside work, scheduling, power overlay or thermal state.", "All three candidate throughputs are below paired baseline observations; this is not an isolated causal regression estimate or accepted resource gain.", "Median-of-run p50/p95/p99 values are not pooled workload quantiles. C2 p99 and tails remain present without exclusion.", "No continuous energy/power/frequency attestation, no thermal/per-core measurements, no whole-host CPU sum or monetary cost model.", "Container raw block-read delta zero and pg_stat_database timing zero under track_io_timing=off do not establish zero database or whole-host I/O.", "Single-entity USD two-line three-human native cash/equity cycles, authentication included; no HTTP/mixed ERP/manufacturing/consolidation/commercial-order throughput or cross-vendor comparison.", "Source custody uses original frozen before/after report/readiness fingerprints; this review does not recompute all checkout bytes or rerun financial effects.", "Six exact captured container lifecycles are independently bound; any retained older possible orphan is outside these six custody records and this reviewer takes no cleanup action."], "original_file_index": INDEX}


if __name__ == "__main__":
    output = Path(sys.argv[1]).resolve()
    need(output.parent == OWN and not output.exists(), "Review output must be fresh in owned ignored output")
    report = main()
    raw = (json.dumps(report, indent=2, ensure_ascii=True, allow_nan=False) + "\n").encode()
    with output.open("xb") as stream:
        stream.write(raw)
    print(json.dumps({"status": report["status"], "sha256": hashlib.sha256(raw).hexdigest(), "path": str(output), "no_live_workload": True}))
