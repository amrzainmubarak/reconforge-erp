"""Independent stdlib-only retained V3 cleanup/preservation review; no live calls."""
from __future__ import annotations

import hashlib
import json
import re
import sys
from datetime import datetime
from pathlib import Path

OWN = Path(__file__).resolve().parent
OPS = Path(r"C:\Users\LOQ\.codex\worktrees\reconforge-operations-wave5\reconforge-erp\output\wave5-controller-peer-review-20261012")
ROOT = Path(r"C:\Users\LOQ\.codex\worktrees\reconforge-integration-wave5\reconforge-erp\output")
CLOSURE = OPS / "v3-exact-cleanup-after-six-runs-readonly-closure-v3"
TARGET = "a218046582c3e81dc3e61f2d7c800ae119ef7d541d4a8239956e0a7c18589a8c"
INDEX: dict[str, dict] = {}


def need(condition: object, message: str) -> None:
    if not condition:
        raise ValueError(message)


def raw(path: Path, expected: str | None = None, size: int | None = None) -> bytes:
    value = path.read_bytes()
    sha = hashlib.sha256(value).hexdigest()
    need(expected is None or sha == expected, f"Original hash mismatch: {path}")
    need(size is None or len(value) == size, "Raw original size mismatch")
    INDEX[str(path)] = {"sha256": sha, "bytes": len(value)}
    return value


def pairs(values: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in values:
        need(key not in result, "Duplicate JSON member")
        result[key] = value
    return result


def read(path: Path, expected: str | None = None) -> dict:
    value = json.loads(raw(path, expected), object_pairs_hook=pairs, parse_constant=lambda _: need(False, "Nonfinite JSON"))
    need(isinstance(value, dict), "Expected JSON object")
    return value


def main() -> dict:
    closure = read(CLOSURE / "closure.json", "7a8cf6598668a04ff24d2de6b93cc3756392b5a1a7441ca48a460914d1796244")
    preservation = read(CLOSURE / "original-v3-pair-preservation.json", "9603e3ce9f974e97895c2115bd33e85eb141ae60dd88bc27269781f6ce69be9b")
    proof = read(OPS / "v3-orphan-readonly-current-inventory-proof-v3.json", "fa42edafe7b58b14b7e275c5fa5156f771840ccb5fd23c02df46aae75240c3a1")
    first = read(OPS / "v3-exact-cleanup-after-six-runs-v1/cleanup.json", "98f9a6af28c4186ee478675fe775ee1661788918b4b8013630cb4430bbccb2b3")
    failed_closure = read(OPS / "v3-exact-cleanup-after-six-runs-readonly-closure-v2/closure.json", "5ea902df2a7def07867f35c1a60cc37fc1f0c4fc5b3001b624a89e3975b364dd")
    original_pair = read(ROOT / "wave5-final22-paired-1k-v3/pair.json", preservation["original_pair_sha256"])
    original_report = read(ROOT / "wave5-final22-paired-1k-v3/1-baseline/result.json", preservation["original_report_sha256"])
    v4 = read(ROOT / "wave5-final22-paired-1k-v4/pair.json")
    need(original_pair["status"] == original_report["status"] == "failed" and original_pair["performance_comparison_accepted"] is False, "Original V3 failure was relabeled")
    need(original_pair["runs"][0]["cleanup"]["status"] == "unverified" and first["status"] == failed_closure["status"] == "unverified", "Original failed guard evidence altered")
    need(original_pair["runs"][0]["retained_raw_report_sha256"] == preservation["original_report_sha256"] == proof["original_report_sha256"] == first["original_failed_report_sha256_before"] == closure["original_failed_report_sha256_after"], "V3 original report custody mismatch")
    need(preservation["original_pair_sha256"] == "6840b7e154619438efa0351fe3c95925661231e884320f2fe950747257fc2804" and preservation["subsequent_exact_cleanup_closure_sha256"] == INDEX[str(CLOSURE / "closure.json")]["sha256"], "Preservation/closure link drift")
    need(closure["exact_container_id"] == first["exact_container_id"] == proof["exact_container_id"] == TARGET and re.fullmatch(r"[a-f0-9]{64}", TARGET), "Wrong immutable cleanup target")
    need(closure["status"] == "exact_target_stop_acknowledgment_and_strict_absence_verified" and closure["stop_executed_by_this_continuation"] is False and closure["no_foreign_stop_or_delete"] is True, "Closure action scope drift")
    need(closure["original_startup_response_id_seal_created"] is False and closure["original_v3_cleanup_status_rebound"] is False and preservation["original_startup_response_id_seal_created"] is False and preservation["original_v3_acceptance_rebound"] is False, "Absent original V3 response-ID seal invented")
    need(proof["original_stdout_id_value_retained"] is False and proof["native_create_event_capture_available"] is False, "Causal metadata claim changed")
    raw_inspection = raw(OPS / "v3-exact-cleanup-after-six-runs-v1/safe-before-exact-id-inspection.raw", proof["exact_id_inspection_raw_sha256"], proof["exact_id_inspection_raw_bytes"])
    inspection_values = [json.loads(word) for word in raw_inspection.decode().strip().split("\t")]
    need(len(inspection_values) == 13 and inspection_values[0] == TARGET and inspection_values[1] == proof["safe_exact_id_inspection"]["Name"] and inspection_values[2] == proof["safe_exact_id_inspection"]["Created"], "Original exact-ID metadata differs")
    need(first["safe_before_exact_id_inspection"]["Id"] == TARGET and first["fresh_before_inspection_exact_match"] is True, "Fresh authorized cleanup inspection missing")
    stopped = first["commands"][-1]
    need(stopped["argv"] == ["docker", "container", "stop", "--time", "10", TARGET] and stopped["returncode"] == 0 and first["stop_executed"] is True and first["foreign_stop_or_delete_executed"] is False, "Original stop acknowledgment differs")
    acknowledgment = closure["original_stop_acknowledgment"]
    reconstructed = raw(CLOSURE / "reconstructed-stop-response-hash-matched.raw", stopped["stdout_sha256"], stopped["stdout_bytes"])
    expected_reconstruction = f"Flag --time has been deprecated, use --timeout instead\n{TARGET}\n".encode()
    need(reconstructed == expected_reconstruction and acknowledgment["stdout_sha256"] == stopped["stdout_sha256"] and acknowledgment["returncode"] == stopped["returncode"], "Explicit public stdout reconstruction mismatch")
    inspect_command, population_command = closure["commands"]
    need(inspect_command["argv"] == ["docker", "container", "inspect", "--format", "{{json .Id}}", TARGET] and inspect_command["returncode"] == 1, "Exact absence probe differs")
    absence_stdout = raw(CLOSURE / "strict-exact-id-absence-original-stdout.raw", inspect_command["stdout_sha256"], inspect_command["stdout_bytes"])
    absence_stderr = raw(CLOSURE / "strict-exact-id-absence-original-safe.raw", inspect_command["stderr_sha256"], inspect_command["stderr_bytes"])
    need(absence_stdout in (b"", b"\n") and absence_stdout.hex() == closure["strict_absence_stdout_hex"], "Strict observed absence stdout differs")
    need(absence_stderr == f"Error response from daemon: No such container: {TARGET}\n".encode(), "Unrelated daemon/permission error accepted")
    after_raw = raw(CLOSURE / "after-container-ids-only-original-safe.raw", population_command["stdout_sha256"], population_command["stdout_bytes"])
    need(population_command["argv"] == ["docker", "container", "ls", "--all", "--no-trunc", "--format", "{{.ID}}"] and population_command["returncode"] == 0, "Raw after-population command differs")
    after_ids = after_raw.decode().splitlines()
    need(len(after_ids) == len(set(after_ids)) == 15 and all(re.fullmatch(r"[a-f0-9]{64}", value) for value in after_ids) and TARGET not in after_ids, "Invalid after-population or target remains")
    before_foreign = sorted(set(first["all_container_ids_before"]) - {TARGET})
    need(sorted(after_ids) == before_foreign == closure["foreign_container_ids_before"] == closure["foreign_container_ids_after"] and closure["foreign_container_id_population_unchanged"] is True, "Foreign container identity population changed")
    need(datetime.fromisoformat(first["started_at"]) > datetime.fromisoformat(v4["finished_at"]), "Older container cleanup occurred before six runs finished")
    return {"schema_version": "wave5-v3-cleanup-preservation-independent-file-review-v1", "status": "passed", "file_only": True, "actual_live_commands_by_this_reviewer": 0, "exact_target": TARGET, "recorded_stop_after_all_six_v4_runs": True, "explicit_public_stdout_reconstruction_hash_matches_original_recorded_acknowledgment": True, "reconstruction_relabelled_original_capture": False, "original_strict_absence_bytes_rehashed": True, "foreign_identity_population_unchanged": True, "foreign_container_count": 15, "original_v3_status": "failed", "original_v3_cleanup_status": "unverified", "original_v3_performance_acceptance": False, "failed_stop_guard_and_empty_stdout_refusal_preserved": True, "original_v3_startup_response_id_seal": "unavailable; remains unavailable", "limits": ["Read-only retained-byte audit; no new Docker observation or cleanup executed.", "Causal metadata reconstruction matches one immutable creation window, image, owner and exact-ID inspection; it does not supply original Docker startup response-ID bytes or historic CREATE event.", "Known public stop notice plus exact-ID stdout is explicitly reconstructed and hash-matched; it is not relabeled an original retained stdout capture.", "Only the separately captured later strict exact-ID absence and after-population prove observed cleanup closure. Original failed V3 acceptance and both earlier guard refusals remain unchanged.", "Before/after foreign-ID membership equality does not inspect foreign data or attest their states.", "An older retained container was observed during B1 and after all six before cleanup; no continuous idle-CPU or thermal claim follows from these metadata records."], "original_file_index": INDEX}


if __name__ == "__main__":
    output = Path(sys.argv[1]).resolve()
    need(output.parent == OWN and not output.exists(), "Output must be fresh in owned ignored directory")
    result = main()
    report = (json.dumps(result, indent=2, ensure_ascii=True, allow_nan=False) + "\n").encode()
    with output.open("xb") as stream:
        stream.write(report)
    print(json.dumps({"status": result["status"], "path": str(output), "sha256": hashlib.sha256(report).hexdigest(), "file_only": True}))
