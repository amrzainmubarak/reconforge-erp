"""File-only terminal CI custody audit; no network, app imports, DB or reruns."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import zipfile
from pathlib import Path, PurePosixPath

from jsonschema import Draft202012Validator
from referencing import Registry, Resource
from referencing.exceptions import NoSuchResource


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON member")
        result[key] = value
    return result


def nonfinite(value):
    raise ValueError("Nonfinite JSON constant: " + value)


def parse(raw):
    return json.loads(raw, object_pairs_hook=unique, parse_constant=nonfinite)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def stream_sha(stream):
    return hashlib.file_digest(stream, "sha256").hexdigest()


def file_sha(path):
    with path.open("rb") as stream:
        return stream_sha(stream)


def canonical(value):
    return json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("ascii")


def deny(uri):
    raise NoSuchResource(ref=uri)


parser = argparse.ArgumentParser()
parser.add_argument("--directory", type=Path, required=True)
parser.add_argument("--root", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
directory, root = args.directory.resolve(), args.root.resolve()
head = "22ebfd78e293aafa13d81b3a0bbf287491951115"
merge = "66bcd39a0f73a80180b97902f3569aea6dbf414e"
base = "6362724f2337a79c3d7569574f7bf9591a018524"
run_id = 38208811408
acceptance_name = "terminal-ci-acceptance-original-source-v1.json"
index_name = "terminal-ci-flat-file-index-v1.json"
trusted_acceptance = "c813847c479d474f83948acbf06424023f9eb29078f0a40c7178b35d57a0f247"
trusted_index = "80390fc8e0934cb4a180b508b8953fd86e67dc5154a38aaef5785c45067b36f2"
acceptance_raw = (directory / acceptance_name).read_bytes()
index_raw = (directory / index_name).read_bytes()
require(sha(acceptance_raw) == trusted_acceptance and sha(index_raw) == trusted_index, "Separately trusted terminal/index bytes differ")
acceptance, index = parse(acceptance_raw), parse(index_raw)
require(index["head_sha"] == acceptance["head_sha"] == head and index["run_id"] == acceptance["run_id"] == run_id, "Wrong terminal source/run")
records = index["records"]
names = [row["file_name"] for row in records]
require(len(records) == len(set(names)) == index["record_count"] == 223, "Wrong exact flat-index membership")
for row in records:
    path = PurePosixPath(row["file_name"])
    require(len(path.parts) == 1 and not path.is_absolute() and ".." not in path.parts, "Non-flat index member")
    file = directory / row["file_name"]
    require(file.stat().st_size == row["bytes"] and file_sha(file) == row["sha256"], "Original indexed file bytes differ")


def git(*arguments):
    return subprocess.run(("git", *arguments), cwd=root, check=True, capture_output=True).stdout


require(git("rev-parse", "HEAD").decode().strip() == head and not git("status", "--porcelain", "--untracked-files=no"), "Source checkout differs")
binding = acceptance["source_binding"]
api_raw = (directory / "virtual-merge-git-api-original.json").read_bytes()
api = parse(api_raw)
local_tree = git("rev-parse", f"{head}^{{tree}}").decode().strip()
require(sha(api_raw) == binding["remote_api_raw_sha256"], "Original Git API bytes differ")
require(api["sha"] == binding["original_actual_merge_commit"] == acceptance["original_actual_virtual_merge"] == merge,
        "Original virtual merge header differs")
require([parent["sha"] for parent in api["parents"]] == binding["remote_parent_sha"] == [base, head], "Actual merge parents differ")
require(api["tree"]["sha"] == local_tree == binding["local_head_tree_sha"] == binding["remote_merge_tree_sha"], "Actual merge/PR content trees differ")
require(binding["tree_equal"] is True and parse((directory / "virtual-merge-and-current-recovery-source-binding.json").read_bytes()) == binding,
        "Source binding record differs")

runs = [parse(path.read_bytes()) for path in sorted(directory.glob("run-*.json"))]
require(any(run["id"] == run_id and run["head_sha"] == head and run["status"] == "completed" and run["conclusion"] == "success" for run in runs),
        "Original terminal run capture missing")
jobs_capture = parse(sorted(directory.glob("jobs-*.json"))[-1].read_bytes())
jobs = jobs_capture["jobs"]
outcomes = acceptance["job_outcomes"]
require(len(jobs) == len(outcomes) == jobs_capture["total_count"] == 44 and len({job["id"] for job in jobs}) == 44,
        "Original terminal job membership differs")
require({job["id"] for job in jobs} == {job["id"] for job in outcomes}, "Terminal projected/original job population differs")
actual_jobs = {job["id"]: job for job in jobs}
for job in outcomes:
    original = actual_jobs[job["id"]]
    require(job["name"] == original["name"] and job["status"] == original["status"] == "completed"
            and job["conclusion"] == original["conclusion"] == "success" and not job["failed_steps"], "Actual terminal job is not successful")
    summary = directory / job["retained_safe_summary_file"]
    require(file_sha(summary) == job["retained_summary_sha256"], "Retained summary bytes differ")
require(acceptance["job_counts"] == {"success": 44, "failure": 0, "cancelled": 0, "skipped": 0}
        and acceptance["run_status"] == "completed" and acceptance["run_conclusion"] == "success", "Terminal counts/state differ")

pattern = re.compile(r"mandatory native gate: collected=(\d+), skipped=(\d+), xfailed=(\d+), xpassed=(\d+), stats_available=(\d+)")
fields = ("collected", "skipped", "xfailed", "xpassed", "stats_available")
native = acceptance["native_shards"]
require(len(native) == 19 and len({row["job_id"] for row in native}) == 19, "Native job population differs")
sessions = selected = mandatory = dedicated = 0
for row in native:
    job = next(job for job in outcomes if job["id"] == row["job_id"])
    text = (directory / job["retained_safe_summary_file"]).read_text(encoding="utf-8-sig")
    observed = [dict(zip(fields, map(int, match.groups()), strict=True)) for match in pattern.finditer(text)]
    require(observed == row["actual_gate_records"] and len(observed) == row["sessions"], "Original terminal native gate records differ")
    require(row["explicit_passed"] is None and row["numeric_passed_summary_available"] is False, "Unprinted native passed count invented")
    require(not row["actual_pytest_summaries"], "Unexpected explicit native numeric summary")
    if row["mandatory_pytest_applicable"] is True:
        mandatory += 1
        require(bool(observed), "Mandatory native job has no terminal session")
    else:
        dedicated += 1
        require(row["shard_name"] == "server-boundaries (writeback)" and not observed, "Wrong dedicated non-pytest native partition")
    for gate in observed:
        require(gate["stats_available"] == 1 and gate["collected"] > 0
                and gate["skipped"] == gate["xfailed"] == gate["xpassed"] == 0, "Incomplete/skipped native terminal gate")
    require(sum(gate["collected"] for gate in observed) == row["selected"], "Native selected count differs")
    sessions += len(observed)
    selected += row["selected"]
require(mandatory == acceptance["native_mandatory_partitions"] == 18 and dedicated == acceptance["native_dedicated_writeback_partitions"] == 1,
        "Native partition totals differ")
require(sessions == acceptance["native_mandatory_sessions"] == 54 and selected == acceptance["native_selected"] == 1528,
        "Native session/selected totals differ")
require(acceptance["native_explicit_passed_total"] is None and acceptance["native_skipped_xfailed_xpassed"] == 0, "Native summary boundary differs")

artifacts = acceptance["original_artifacts"]
require(len(artifacts) == len({row["artifact_id"] for row in artifacts}) == 26, "Exact original artifact population differs")
artifact_by_id = {}
original_zip_members = 0
for artifact in artifacts:
    path = directory / artifact["original_complete_archive_file"]
    require(file_sha(path) == artifact["archive_sha256"] and path.stat().st_size == artifact["archive_bytes"], "Original complete ZIP bytes differ")
    artifact_by_id[artifact["artifact_id"]] = path
    expected = {row["entry_name"]: row for row in artifact["members"]}
    require(len(expected) == len(artifact["members"]), "Duplicate artifact member record")
    with zipfile.ZipFile(path) as archive:
        infos = archive.infolist()
        require(len(infos) == len({info.filename for info in infos}) and set(expected) == {info.filename for info in infos}, "Original artifact ZIP membership differs")
        for info in infos:
            require(info.file_size == expected[info.filename]["bytes"], "Original artifact member size differs")
            with archive.open(info) as stream:
                require(stream_sha(stream) == expected[info.filename]["sha256"], "Original artifact member SHA differs")
    original_zip_members += len(expected)

public_path = next(directory.glob("public-playwright-diff-original-custody-*.json"))
public = parse(public_path.read_bytes())
patch = git("--no-pager", "-c", "color.ui=false", "diff", "--no-ext-diff", "--abbrev=7", base, head)
require(sha(patch) == public["public_patch_full_sha256"], "Whole public Git diff bytes differ")
prefix = patch.decode("utf-8").encode("utf-16-le")[:2 * public["public_patch_prefix_utf16_units"]].decode("utf-16-le")
require(sha(prefix.encode("utf-8")) == public["public_patch_prefix_sha256"], "Exact Playwright JS-unit public prefix differs")
public_contexts = 0
for capture in public["captures"]:
    require(capture["original_complete_archive_file"] == artifact_by_id[capture["artifact_id"]].name
            and capture["prior_safe_projection_preserved"] is True, "Original/public capture custody differs")
    with zipfile.ZipFile(artifact_by_id[capture["artifact_id"]]) as archive:
        for member in capture["original_source_members"]:
            raw = archive.read(member["entry_name"])
            require(sha(raw) == member["raw_sha256"], "Original Playwright JSON member differs")
            data = parse(raw)
            for context in member["source_diff_contexts"]:
                if context["json_member_path"] == "$.config.metadata.gitDiff":
                    value = data["config"]["metadata"]["gitDiff"]
                else:
                    match = re.fullmatch(r"\$\.config\.projects\[(\d+)\]\.metadata\.gitDiff", context["json_member_path"])
                    require(match is not None, "Unknown public Git diff context path")
                    value = data["config"]["projects"][int(match[1])]["metadata"]["gitDiff"]
                require(value == prefix and sha(value.encode()) == context["literal_source_diff_sha256"], "Original source-diff value differs from exact public Git bytes")
                public_contexts += 1
for line in public["public_literal_source_line_bindings"]:
    name = line["repository_relative_path"]
    raw = git("show", f"{head}:{name}")
    require(sha(raw) == line["blob_sha256"] and git("rev-parse", f"{head}:{name}").decode().strip() == line["git_blob_sha1"], "Public source blob binding differs")
    require(sha(raw.splitlines()[line["source_line_number"] - 1]) == line["literal_line_sha256"], "Public literal source line differs")

current_name = binding["current_recovery_original_report_file"]
current_raw = (directory / current_name).read_bytes()
require(sha(current_raw) == binding["current_recovery_original_report_sha256"], "Current GHA recovery raw bytes differ")
current = parse(current_raw)
payload = dict(current)
current_digest = payload.pop("report_digest")
require(sha(canonical(payload)) == current_digest and current["subject"]["base_commit"] == merge, "Original GHA recovery subject/digest differs")
registry = Registry(retrieve=deny)
schemas = []
for name in ("docs/schemas/postgres_writeback_recovery_compensation_matrix.schema.json", "docs/schemas/postgres_writeback_recovery_compensation_matrix.v2.schema.json"):
    schema = parse(git("show", f"{head}:{name}"))
    Draft202012Validator.check_schema(schema)
    registry = registry.with_resource(schema["$id"], Resource.from_contents(schema))
    schemas.append(schema)
Draft202012Validator(schemas[-1], registry=registry, format_checker=Draft202012Validator.FORMAT_CHECKER).validate(current)
require([run["runtime"]["postgresql"] for run in current["runs"]] == ["16.15", "17.11"], "Wrong current actual versions")
reference = current["sqlite_reference"]
require(len(reference["checks"]) == 13 and all(value is True for value in reference["checks"].values()), "SQLite current checks incomplete")
require(sha(canonical(reference["history"])) == reference["history_sha256"], "Current reference history digest differs")
for run in current["runs"]:
    require(len(run["checks"]) == 16 and all(value is True for value in run["checks"].values())
            and len(run["role_flags"]) == 5 and all(value is False for value in run["role_flags"].values()), "Current actual native checks/privileges differ")
    require(run["history"] == reference["history"] and run["history_sha256"] == reference["history_sha256"], "Current original complete histories differ")
require(current["parity"]["all_cleanup_complete"] is True and current["parity"]["all_checks_passed"] is True, "Current runtime parity/cleanup incomplete")
require(git("rev-parse", "HEAD").decode().strip() == head and not git("status", "--porcelain", "--untracked-files=no"), "Frozen source changed during audit")
audit = {
    "schema_version": "wave5-terminal-ci-independent-custody-audit-v1", "status": "passed", "run_id": run_id,
    "pr_head": head, "original_virtual_merge": merge, "exact_equal_tree": local_tree,
    "trusted_acceptance_sha256": trusted_acceptance, "trusted_flat_index_sha256": trusted_index,
    "indexed_original_files_rehashed": len(records), "original_complete_zip_artifacts_rehashed": len(artifacts),
    "original_zip_members_rehashed": original_zip_members, "actual_jobs": 44, "actual_job_successes": 44,
    "mandatory_native_partitions": mandatory, "dedicated_native_writeback_partitions": dedicated,
    "terminal_native_sessions": sessions, "native_selected": selected, "native_explicit_passed_total": None,
    "native_skipped_xfailed_xpassed": 0,
    "native_count_scope": "Selected items and completed successful mandatory terminal gate sessions only; no printed numeric passed total exists.",
    "public_playwright_original_captures": len(public["captures"]), "public_exact_git_diff_contexts": public_contexts,
    "public_git_diff_prefix_sha256": public["public_patch_prefix_sha256"], "public_literal_source_lines": len(public["public_literal_source_line_bindings"]),
    "public_scope": "Exact original public source diff values/line blobs independently bound; prior failed equality and projections remain preserved. No runtime-credential reclassification.",
    "current_recovery_original_report_sha256": sha(current_raw), "current_recovery_canonical_digest": current_digest,
    "current_recovery_original_source": merge, "current_recovery_equal_complete_history_sha256": reference["history_sha256"],
    "current_recovery_scope": "Original virtual-merge source preserved; independent synthetic lifecycle parity/schema/privilege check only, no accounting posting/live provider claim.",
    "reviewer_scope": "File-only hashes, terminal captures/gate logs, ZIP members and public Git source. No network, original runtime imports, DB, tests, retries or source edits.",
    "full_original_remote_job_logs_rehashed": False,
    "job_log_scope": "Retained safe summary raw hashes verified; complete remote log SHA metadata alone is not a local full-log rehash claim.",
}
args.output.write_bytes((json.dumps(audit, indent=2, sort_keys=True) + "\n").encode("utf-8"))
print(json.dumps({"status": "passed", "output_sha256": file_sha(args.output), "original_files": len(records),
                  "jobs_success": 44, "native_selected": selected, "native_passed_total": None}, sort_keys=True))
