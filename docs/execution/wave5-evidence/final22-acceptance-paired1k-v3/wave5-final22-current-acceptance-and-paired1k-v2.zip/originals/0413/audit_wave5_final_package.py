"""Read-only package/capsule byte closure audit; no extraction, imports or rebuild."""
from __future__ import annotations

import argparse
import base64
import csv
import hashlib
import io
import json
import subprocess
import tarfile
import zipfile
from pathlib import Path, PurePosixPath


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def members(pairs: list[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON member: " + key)
        result[key] = value
    return result


def invalid_constant(value: str) -> None:
    raise ValueError("Nonfinite JSON constant: " + value)


def parse(raw: bytes) -> dict:
    return json.loads(raw, object_pairs_hook=members, parse_constant=invalid_constant)


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def stream_sha(stream) -> str:
    return hashlib.file_digest(stream, "sha256").hexdigest()


def file_sha(path: Path) -> str:
    with path.open("rb") as stream:
        return stream_sha(stream)


def safe(name: str) -> None:
    path = PurePosixPath(name)
    require(bool(path.parts) and not path.is_absolute() and ".." not in path.parts and "\\" not in name,
            "Unsafe archive member: " + name)


parser = argparse.ArgumentParser()
parser.add_argument("--root", type=Path, required=True)
parser.add_argument("--package-directory", type=Path, required=True)
parser.add_argument("--report-sha256", required=True)
parser.add_argument("--commit", required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
root = args.root.resolve()
directory = args.package_directory.resolve()


def git(*arguments: str) -> bytes:
    return subprocess.run(("git", *arguments), cwd=root, check=True, capture_output=True).stdout


require(git("rev-parse", "HEAD").decode().strip() == args.commit, "Unexpected current source head")
require(not git("status", "--porcelain", "--untracked-files=no"), "Tracked source is not clean")
report_path = directory / "archive-verification.json"
raw_report = report_path.read_bytes()
require(sha(raw_report) == args.report_sha256, "Original verification report differs from separately trusted SHA")
report = parse(raw_report)
require(report["status"] == "passed" and report["source_commit"] == args.commit, "Original package acceptance source differs")
require(all(report[key] is True for key in ("source_unchanged", "tracked_clean_before", "tracked_clean_after", "temporary_extraction_removed")), "Original package closure/cleanup missing")

tracked = set(filter(None, git("ls-files", "-z").decode().split("\0")))
source_hashes = {}
source_digest = hashlib.sha256()
for name in sorted(tracked):
    value = file_sha(root / name)
    source_hashes[name] = value
    source_digest.update(name.encode("utf-8"))
    source_digest.update(bytes.fromhex(value))
require(source_digest.hexdigest() == report["source_sha256_before"] == report["source_sha256_after"], "Source byte/name fingerprint differs")

sdists = list(directory.glob("*.tar.gz"))
wheels = list(directory.glob("*.whl"))
require(len(sdists) == len(wheels) == 1, "Exactly one original sdist and wheel required")
sdist, wheel = sdists[0], wheels[0]
require(file_sha(sdist) == report["sdist_sha256"] and file_sha(wheel) == report["wheel_sha256"], "Distribution raw bytes differ")
sdist_hashes = {}
prefixes = set()
with tarfile.open(sdist, "r|gz") as archive:
    for member in archive:
        safe(member.name)
        path = PurePosixPath(member.name)
        prefixes.add(path.parts[0])
        require(not member.issym() and not member.islnk() and not member.isdev(), "Source archive link/device refused")
        if not member.isfile():
            continue
        name = PurePosixPath(*path.parts[1:]).as_posix()
        require(name not in sdist_hashes, "Duplicate sdist file")
        stream = archive.extractfile(member)
        require(stream is not None, "Missing sdist payload")
        sdist_hashes[name] = stream_sha(stream)
require(len(prefixes) == 1 and len(sdist_hashes) == report["sdist"]["file_members"], "Source archive population differs")
expected_sdist = report["sdist"]["exact_tracked_member_hashes"]
require(set(expected_sdist) == tracked.intersection(sdist_hashes), "Reported tracked sdist membership differs")
for name, value in expected_sdist.items():
    require(sdist_hashes[name] == source_hashes[name] == value, "sdist/source/report bytes differ: " + name)

capsule_relative = "docs/execution/wave5-evidence/capsules"
capsule_root = root / capsule_relative
copy = parse((capsule_root / "copy-verification-v3.json").read_bytes())
require(copy["source_indexes_unchanged"] is True, "Copy report original-index preservation missing")
require(file_sha(capsule_root / "copy-verification-v2.json") == copy["prior_v2_report_sha256"], "Prior V2 copy report changed")
copy_names = set()
for row in copy["files"]:
    require(row["file"] not in copy_names, "Duplicate V3 copy member")
    copy_names.add(row["file"])
    path = capsule_root / row["file"]
    require(path.stat().st_size == row["bytes"] and source_hashes[f"{capsule_relative}/{row['file']}"] == row["sha256"], "V3 copied file bytes differ")
    require(sdist_hashes[f"{capsule_relative}/{row['file']}"] == row["sha256"], "V3 copy member not preserved in sdist")

catalogs = [capsule_root / "capsule-index.json", *sorted(capsule_root.glob("capsule-index-extension-*.json"))]
declared_capsules = {}
for path in catalogs:
    catalog = parse(path.read_bytes())
    for entry in catalog["capsules"]:
        name = entry["file_name"]
        require(name not in declared_capsules, "Duplicate catalog capsule")
        declared_capsules[name] = entry
zips = sorted(capsule_root.glob("*.zip"))
require(set(declared_capsules) == {path.name for path in zips} and len(zips) == copy["capsules_verified"] == 13,
        "Complete exact 13-capsule catalog membership required")
capsules = []
raw_count = 0
zip_count = 0
for path in zips:
    catalog = declared_capsules[path.name]
    require(file_sha(path) == catalog["sha256"] and path.stat().st_size == catalog["bytes"], "Catalog ZIP bytes differ")
    index_path = capsule_root / catalog["index_name"]
    index_raw = index_path.read_bytes()
    require(sha(index_raw) == catalog["index_sha256"], "Catalog original index bytes differ")
    index = parse(index_raw)
    require(index["name"] == path.name, "Index ZIP identity differs")
    records = index["records"]
    names = [record["entry_name"] for record in records]
    require(len(names) == len(set(names)) == index["file_count"] == catalog["file_count"], "Capsule raw member population differs")
    with zipfile.ZipFile(path) as archive:
        infos = archive.infolist()
        stored_names = [info.filename for info in infos]
        require(len(stored_names) == len(set(stored_names)) and stored_names == sorted(stored_names), "Capsule ZIP duplicate/order differs")
        require(set(stored_names) == set(names) | {"capsule-manifest.json"}, "Capsule undeclared or missing ZIP member")
        require(archive.read("capsule-manifest.json") == index_raw, "Embedded/original external index bytes differ")
        for info in infos:
            safe(info.filename)
            require(info.compress_type == zipfile.ZIP_DEFLATED and info.date_time == (1980, 1, 1, 0, 0, 0)
                    and info.external_attr >> 16 == 0o100644, "Capsule deterministic metadata differs")
        size = 0
        for record in records:
            info = archive.getinfo(record["entry_name"])
            require(info.file_size == record["bytes"], "Original raw capsule size differs")
            with archive.open(info) as stream:
                require(stream_sha(stream) == record["sha256"], "Original raw capsule SHA differs")
            size += info.file_size
        require(size == index["raw_bytes"] == catalog["raw_bytes"], "Capsule total original raw size differs")
    raw_count += len(records)
    zip_count += len(stored_names)
    capsules.append({"name": path.name, "sha256": catalog["sha256"], "index_sha256": catalog["index_sha256"],
                     "raw_members": len(records), "zip_members": len(stored_names),
                     "original_capture_for_root_commit": index["capture_for_root_commit"]})
require(raw_count == copy["retained_files_verified"] == 702 and zip_count == copy["zip_members_verified"] == 715,
        "Exact V3 raw/ZIP membership totals differ")
require(all(name in copy_names for name in declared_capsules), "V3 omitted original capsule")
require(next(row for row in capsules if row["name"] == "wave5-d3-actual-mixed-api-package-independent-v1.zip")["original_capture_for_root_commit"]
        == "d3e227b7d46be7e7d3b73ac39fa82615943319e8", "Prior D3 evidence was relabeled")

schema_name = "docs/schemas/postgres_writeback_recovery_compensation_matrix.v2.schema.json"
verifier_name = ".github/scripts/verify_global_integrity_archive.py"
require(schema_name in expected_sdist and schema_name in sdist_hashes, "Current V2 schema omitted from sdist parity")
require(f'"{schema_name}"' in (root / verifier_name).read_text(encoding="utf-8"), "Archive verifier omitted explicit required V2 schema")
require(f"include {schema_name}" in (root / "MANIFEST.in").read_text(encoding="utf-8").splitlines(), "Source manifest omitted V2 schema")

with zipfile.ZipFile(wheel) as archive:
    wheel_names = archive.namelist()
    require(len(wheel_names) == len(set(wheel_names)), "Duplicate wheel member")
    wheel_hashes = {}
    wheel_sizes = {}
    for info in archive.infolist():
        safe(info.filename)
        with archive.open(info) as stream:
            wheel_hashes[info.filename] = stream_sha(stream)
        wheel_sizes[info.filename] = info.file_size
    for name, value in report["wheel"]["exact_source_member_hashes"].items():
        hits = [stored for stored in wheel_names if stored == name or stored.endswith("/" + name)]
        require(len(hits) == 1 and wheel_hashes[hits[0]] == source_hashes[name] == value, "Wheel source member bytes differ")
    require(wheel_hashes[report["wheel"]["license_member"]] == source_hashes["LICENSE"], "Wheel MIT license bytes differ")
    record_names = [name for name in wheel_names if name.endswith(".dist-info/RECORD")]
    require(len(record_names) == 1, "Unique wheel RECORD required")
    record_rows = list(csv.reader(io.StringIO(archive.read(record_names[0]).decode("utf-8"))))
    require(len(record_rows) == len({row[0] for row in record_rows}) and {row[0] for row in record_rows} == set(wheel_names), "Wheel RECORD membership differs")
    for name, recorded_sha, recorded_size in record_rows:
        if name == record_names[0]:
            require(recorded_sha == recorded_size == "", "Wheel RECORD self-entry differs")
            continue
        expected_hash = "sha256=" + base64.urlsafe_b64encode(bytes.fromhex(wheel_hashes[name])).decode().rstrip("=")
        require(recorded_sha == expected_hash and int(recorded_size) == wheel_sizes[name], "Wheel RECORD hash/size differs")
    require(not any("wave5-evidence" in name or "recovery_compensation_matrix.v2.schema.json" in name for name in wheel_names),
            "Documented wheel/sdist scope differs")

require(git("rev-parse", "HEAD").decode().strip() == args.commit and not git("status", "--porcelain", "--untracked-files=no"), "Source changed during independent audit")
audit = {
    "schema_version": "wave5-final-package-independent-byte-closure-v1", "status": "passed", "source_commit": args.commit,
    "original_verification_report_sha256": args.report_sha256, "actual_source_byte_name_sha256": source_digest.hexdigest(),
    "sdist": {"name": sdist.name, "sha256": report["sdist_sha256"], "bytes": sdist.stat().st_size,
              "file_members": len(sdist_hashes), "exact_tracked_members_rehashed": len(expected_sdist),
              "original_report_required_members": report["sdist"]["required_members"], "current_v2_schema_present": True},
    "wheel": {"name": wheel.name, "sha256": report["wheel_sha256"], "bytes": wheel.stat().st_size,
              "file_members": len(wheel_names), "exact_source_members_rehashed": len(report["wheel"]["exact_source_member_hashes"]),
              "record_members_verified": len(record_rows), "mit_license_matches_source": True,
              "scope": "Python runtime and migration assets; evidence capsules and source-drill V2 schema are sdist-only."},
    "v3_copy_members_verified": len(copy_names), "capsules_verified": len(capsules), "retained_raw_members_verified": raw_count,
    "zip_members_verified": zip_count, "capsules": capsules,
    "original_captures_and_D3_package_source_preserved": True, "source_clean_before_after": True,
    "scope": "Independent raw package/source/capsule/RECORD byte closure. Original archive verifier report preserved; no rebuild, install, imports, DB or financial drills by reviewer.",
    "limits": "Does not replay original financial oracles or claim wheel operational installation, final CI aggregate, signed release, production readiness or competitor performance.",
}
args.output.write_bytes((json.dumps(audit, indent=2, sort_keys=True) + "\n").encode("utf-8"))
print(json.dumps({"status": "passed", "output_sha256": file_sha(args.output), "capsules": len(capsules),
                  "retained_raw_members": raw_count, "zip_members": zip_count, "sdist_tracked_members": len(expected_sdist)}, sort_keys=True))
