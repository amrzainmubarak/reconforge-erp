"""File-only audit of a trusted current-profile report; no ReconForge imports or DB."""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from pathlib import Path

from jsonschema import Draft202012Validator
from referencing import Registry, Resource
from referencing.exceptions import NoSuchResource


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def strict_members(pairs: list[tuple[str, object]]) -> dict[str, object]:
    value: dict[str, object] = {}
    for key, member in pairs:
        require(key not in value, "Duplicate JSON member")
        value[key] = member
    return value


def reject_constant(value: str) -> None:
    raise ValueError("Nonfinite JSON constant: " + value)


def parse(raw: bytes) -> dict:
    return json.loads(raw, object_pairs_hook=strict_members, parse_constant=reject_constant)


def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def canonical(value: object) -> bytes:
    return json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("ascii")


def normalized_source(raw: bytes) -> bytes:
    return raw.decode("utf-8").replace("\r\n", "\n").replace("\r", "\n").encode("utf-8")


def deny_retrieval(uri: str) -> Resource:
    raise NoSuchResource(ref=uri)


parser = argparse.ArgumentParser()
parser.add_argument("--root", type=Path, required=True)
parser.add_argument("--report", type=Path, required=True)
parser.add_argument("--report-sha256", required=True)
parser.add_argument("--origins", type=Path, required=True)
parser.add_argument("--origins-sha256", required=True)
parser.add_argument("--expected-commit", required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
root = args.root.resolve()


def git(*arguments: str) -> bytes:
    return subprocess.run(("git", *arguments), cwd=root, check=True, capture_output=True).stdout


def blob(commit: str, name: str) -> bytes:
    return git("show", f"{commit}:{name}")


require(git("rev-parse", "HEAD").decode().strip() == args.expected_commit, "Current checkout head changed")
require(not git("status", "--porcelain", "--untracked-files=no"), "Current tracked source changed")
raw = args.report.read_bytes()
require(digest(raw) == args.report_sha256, "Original report bytes differ from separately supplied trusted digest")
report = parse(raw)
payload = dict(report)
supplied_report_digest = payload.pop("report_digest")
require(digest(canonical(payload)) == supplied_report_digest, "Canonical report digest differs")
require(report["schema_version"] == "postgres-writeback-recovery-compensation-matrix-v2", "Current V2 required")
require(report["subject"]["base_commit"] == args.expected_commit, "Actual report source commit differs")

schema_names = (
    "docs/schemas/postgres_writeback_recovery_compensation_matrix.schema.json",
    "docs/schemas/postgres_writeback_recovery_compensation_matrix.v2.schema.json",
)
registry = Registry(retrieve=deny_retrieval)
schemas = []
schema_bindings = {}
for name in schema_names:
    schema_bytes = (root / name).read_bytes()
    require(normalized_source(schema_bytes) == normalized_source(blob(args.expected_commit, name)), "Schema differs from actual Git subject")
    schema = parse(schema_bytes)
    Draft202012Validator.check_schema(schema)
    registry = registry.with_resource(schema["$id"], Resource.from_contents(schema))
    schemas.append(schema)
    schema_bindings[name] = digest(normalized_source(schema_bytes))
Draft202012Validator(schemas[-1], registry=registry, format_checker=Draft202012Validator.FORMAT_CHECKER).validate(report)

source_names = {
    "writeback_source_sha256": "reconforge/connectors/writeback.py",
    "postgres_persistence_source_sha256": "reconforge/infrastructure/postgres_writeback.py",
    "sqlite_persistence_source_sha256": "reconforge/infrastructure/sqlite_writeback.py",
    "migration_source_sha256": "alembic/versions/0089_postgres_writeback_proposal_identity.py",
    "supply_chain_policy_sha256": "docs/security/supply-chain-policy.v1.json",
    "current_postgres_policy_sha256": "docs/security/postgres-current-images.wave5.v1.json",
    "matrix_runner_source_sha256": ".github/scripts/verify_postgres_writeback_recovery_compensation_matrix.py",
}
source_bindings = {}
for field, name in source_names.items():
    source = normalized_source((root / name).read_bytes())
    require(source == normalized_source(blob(args.expected_commit, name)), "Current source differs from actual Git subject")
    require(digest(source) == report["subject"][field], "Reported normalized source digest differs")
    source_bindings[name] = digest(source)

policy = parse((root / source_names["current_postgres_policy_sha256"]).read_bytes())
images = policy["current_images"]
require(report["subject"]["runtime_profile"] == "current-postgres-wave5-v1", "Wrong explicit current profile")
require([(run["runtime"]["postgresql"], run["runtime"]["image"]) for run in report["runs"]] == [
    ("16.15", images["server_boundaries"]), ("17.11", images["native_acceptance"])
], "Wrong actual current image/version/order")
statuses = ["proposed", "approved", "dispatched", "acknowledged", "compensation_requested", "compensated"]
reference = report["sqlite_reference"]
require(len(reference["checks"]) == 13 and all(value is True for value in reference["checks"].values()), "SQLite checks missing or failed")
require(reference["statuses"] == statuses and len(reference["history"]) == 6, "SQLite lifecycle differs")
require(digest(canonical(reference["history"])) == reference["history_sha256"], "SQLite history digest differs")
require(report["parity"]["history_sha256"] == reference["history_sha256"], "Aggregate parity digest differs")
for run in report["runs"]:
    require(len(run["checks"]) == 16 and all(value is True for value in run["checks"].values()), "PostgreSQL checks missing or failed")
    require(len(run["role_flags"]) == 5 and all(value is False for value in run["role_flags"].values()), "Privileged actual application role")
    require(run["statuses"] == statuses and run["history"] == reference["history"], "Exact native/reference histories differ")
    require(digest(canonical(run["history"])) == run["history_sha256"] == reference["history_sha256"], "Native history digest differs")
require(report["parity"]["all_checks_passed"] is True and report["parity"]["all_cleanup_complete"] is True, "Incomplete parity/cleanup")

origins_raw = args.origins.read_bytes()
require(digest(origins_raw) == args.origins_sha256, "Original module preflight bytes differ")
origins = parse(origins_raw)
expected_origins = {
    "reconforge": "reconforge/__init__.py",
    "writeback": "reconforge/connectors/writeback.py",
    "postgres_writeback": "reconforge/infrastructure/postgres_writeback.py",
}
require(set(origins) == set(expected_origins), "Unexpected module-origin preflight population")
for key, name in expected_origins.items():
    require(Path(origins[key]).resolve() == (root / name).resolve(), "Module preflight origin outside actual subject checkout")
    require(normalized_source((root / name).read_bytes()) == normalized_source(blob(args.expected_commit, name)), "Preflight module source differs from Git subject")

immutable_names = (
    schema_names[0], "docs/security/postgres-current-images.wave5.v1.json", "docs/security/supply-chain-policy.v1.json",
    "docs/execution/POSTGRES_WRITEBACK_RECOVERY_COMPENSATION_MATRIX_2026-08-22.json",
    "docs/execution/POSTGRES_WRITEBACK_RECOVERY_COMPENSATION_MATRIX_2026-10-03.json",
    "docs/execution/POSTGRES_WRITEBACK_RECOVERY_COMPENSATION_MATRIX_2026-10-08.json",
)
immutable_bindings = {}
for name in immutable_names:
    original = blob("770b380a12a791a7d1a019168add6be5a485afa5", name)
    current = blob(args.expected_commit, name)
    require(original == current, "Retained V1/policy/report Git bytes changed")
    immutable_bindings[name] = digest(current)

log_names = (
    "output/wave5-current-writeback-22ebfd78-r2.log",
    "output/wave5-current-writeback-22ebfd78.log",
)
logs = {name: (root / name).read_bytes() for name in log_names}
text = logs[log_names[0]].decode("utf-8-sig")
cleanup = [json.loads(line)["owned_postgres_cleanup"] for line in text.splitlines() if line.startswith('{"owned_postgres_cleanup"')]
require(len(cleanup) == 2 and all(row["state"] == "absent" and row["returncode"] == 1 for row in cleanup), "Both owned cleanup observations missing")
require(f"versions=16.15,17.11 report_digest={supplied_report_digest}" in text, "Actual success log differs from report")
require("ModuleNotFoundError" in logs[log_names[1]].decode("utf-8-sig"), "Original failed environment attempt missing")
require(git("rev-parse", "HEAD").decode().strip() == args.expected_commit and not git("status", "--porcelain", "--untracked-files=no"), "Subject changed during read-only audit")

audit = {
    "schema_version": "wave5-current-writeback-file-audit-v1", "status": "passed",
    "scope": "Actual synthetic recovery/compensation/reference parity; no financial posting, live provider or production RPO/RTO claim.",
    "source_commit": args.expected_commit, "original_report_sha256": args.report_sha256,
    "canonical_report_digest": supplied_report_digest, "actual_duration_seconds": report["duration_seconds"],
    "schema_normalized_source_sha256": schema_bindings, "actual_subject_source_sha256": source_bindings,
    "native_versions": report["parity"]["postgresql_versions"], "native_checks_each": 16,
    "sqlite_checks": 13, "privilege_flags_each": 5, "all_privilege_flags_false": True,
    "exact_history_sha256": reference["history_sha256"], "equal_complete_histories": True,
    "owned_cleanup_log_observations": cleanup, "log_raw_sha256": {name: digest(value) for name, value in logs.items()},
    "original_preflight_sha256": args.origins_sha256, "verified_preflight_module_origins": origins,
    "module_origin_scope": "Three original preflight module origins only; no new imports/runtime probes by reviewer.",
    "retained_v1_policy_report_git_bytes_unchanged_sha256": immutable_bindings,
    "first_failed_environment_attempt_preserved": True, "reviewer_db_runtime_started": False,
}
args.output.write_bytes((json.dumps(audit, ensure_ascii=True, sort_keys=True, indent=2) + "\n").encode("utf-8"))
print(json.dumps({"status": audit["status"], "output_sha256": digest(args.output.read_bytes()),
                  "original_report_sha256": args.report_sha256, "canonical_report_digest": supplied_report_digest}, sort_keys=True))
