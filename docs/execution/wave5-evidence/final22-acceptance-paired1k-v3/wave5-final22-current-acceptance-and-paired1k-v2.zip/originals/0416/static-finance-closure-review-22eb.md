# Static native finance cost and namespace review

Subject: baseline `6362724f2337a79c3d7569574f7bf9591a018524` versus candidate `22ebfd78e293aafa13d81b3a0bbf287491951115`.

This is a source/Git and retained-artifact review only. No application modules were imported, no live database/Docker/resource queries or new tests/profiling were run, and no tracked source was edited. Six paired runs remain the owner's measurement task. No speed, CPU or resource comparison is accepted by this review.

## Verified unchanged baseline costs

Git comparison is byte-identical for `reconforge/auth/passwords.py`, `reconforge/infrastructure/postgres_identity.py`, `reconforge/infrastructure/postgres.py`, `tests/test_postgres_inventory_receipt_posting.py` and `tests/erp_expansion_browser_seed.py`.

- ReceiptRuntime.actor at test lines47-59 authenticates each principal in one tenant transaction, then opens a separate scoped business transaction. The common harness executes separate maker, checker and poster actor calls at lines229-239.
- Authentication at identity lines376-399 locks that user FOR UPDATE, verifies PBKDF2, then resets login counters. Passwords lines11/43-54 retain390,000 default iterations and constant-time comparison. This shared-user lock/KDF cost is not newly introduced by candidate22. Do not reduce strength or remove revocation/lockout serialization to improve a benchmark.
- Connection factory lines171-183 and boundary lines632-644 create and close a connection for each transaction. This benchmark has six connection admissions per complete three-actor cycle, rather than cross-cycle connection reuse. Measure per-backend planning before attributing any added trigger cost; an existing pool is not used by ReceiptRuntime's ordinary factory.
- Shared finance hierarchy RLS, existing posting guards and scope authority are unchanged. Period FOR SHARE, entry FOR UPDATE and command advisory locks remain required. Fresh native commands use distinct tenant/workspace/command keys; no static evidence shows new ME/IC row locks on ordinary manual posting.

## New common-table cost candidate

New Python source-owner admission at posting lines433-451 only imports/calls ME/IC owners when entry_number/id prefixes match. Ordinary BENCH entries do not call those admits methods or incur their owner SQL.

The SQL additions are broader:

- Manufacturing schema lines522-550 installs deferred parent classification on native rows. Every ordinary financial line and posting effect still selects its parent at lines540-541 before determining no ME relevance. Header events already return cheaply at535 when no ME number and no original reversal.
- Intercompany schema lines289-334 serializes the complete NEW row, OLD row or both with to_jsonb before extracting a few fields. Native entry/line/effect rows then select their current parent number at306 before returning for non-IC entries. UPDATE handles OLD and NEW separately. Installation345-346 also covers domain audit/outbox inserts; ordinary IDs exit at328-329 but still undergo full row JSON conversion.
- For an ordinary successful nonreplay two-line cycle with one create, one validation update, one posting update and one effect insert, static control flow predicts ME3 and IC8 additional parent-header lookups, totaling11. This is an execution-path estimate, not an observed query count or latency attribution. RLS applies to those reads. Added read-only probes can prolong existing transaction/lock lifetimes without themselves adding FOR UPDATE/FOR SHARE.
- Procurement sourcing native closures and revision136 inventory policies do not directly run on this manual cash/equity posting population. They do affect other workloads and fixture admission; do not generalize this exclusion to mixed ERP/manufacturing.

Batching at core1001-1018 replaces two account lookups with one ANY query; core1130-1177 replaces two line INSERT calls with one two-row VALUES statement. PostgreSQL RLS and row/deferred guards still run per row. The two-line case saves two client round trips; it does not eliminate row guard work. Account unique key `(tenant_id,chart_id,account_code)` exists at1757. No new account index is justified solely by this source change.

## Historical query evidence, explicitly not a fair comparison

Original baseline profile SHA256 `abbac3be6cc531732663c451c5aa6a6de831cb06a0c990070d4e1f3926af35fe`: source636, PostgreSQL17.10, one worker, opt-in stage/function/database instrumentation.

Original historical candidate profile SHA256 `e0509a4b2411e31a7eee2596caa0f63ef841a95790c995af297c211f0c13f9ab`: source5686b6ea064ece2e033651166f0875cfefa7b112, PostgreSQL17.11, one worker, opt-in instrumentation. Git5686 to22 differs in reconforge/alembic only by additive136 inventory-scope files/operation revision registry; the reviewed Finance/ME/IC code is equal. These observations are not final22 paired performance evidence.

Static SQL identity reconstruction used immutable Python AST string literals, positional `%s` to `$n` replacement, the snapshot's public empty-object literal normalization, and the exact two-row VALUES construction. No SQL text, parameters or financial rows are emitted.

- Account ANY at core1009: digest `b8e9c8448daf09754530bbe22f73abe5e72174020c0a2a7bc6b714df3cd600ac`; candidate historical100 calls/200 rows,179.124308ms plan,9.503561ms execution.
- Two-line INSERT at core1147: digest `9c612cfff568b8388b9d5787e1d435e830edde1d010f1931e70fe95aaf6a98df`; separate retained95-call/190-row and5-call/10-row records. Do not assume their query-ID split's cause.
- Complete reviewed snapshot at posting73-80: digest `81f9d84dd85691ce6ee15feb824c92b6fac8b7a4fa5ed9b00ee4c6274379a479`; baseline300 calls,4131.753816ms plan/1566.586714ms execution; historical candidate300 calls,5311.253618ms plan/2027.031074ms execution. The mixed versions/conditions prohibit speedup/regression attribution from these numbers.
- Snapshot, integrity and nested entry reads show repeated planning as a plausible target. The account ANY record is small relative to those retained hotspots; it still needs custom/generic-plan and large-cardinality tests under the same actual nonowner RLS context before choosing a planner change.
- pg_stat_statements retains at most200 rows and mixes top-level/nested counters. Do not sum them into wall time, equate zero retained reads with zero I/O, or treat the absence of a retained row as absence of execution.

## Namespace proof and rejected shortcuts

There is no DB-enforced disjoint ME/IC posting-effect ID namespace.

| Native object | Actual identity and DB binding | Shortcut conclusion |
| --- | --- | --- |
| ME material issue and scrap native header/lines | Shared core GLE/GLL hashes (core972/1132; platform209-213). Python uses ME1/ME1C entry numbers. me1_entry272-304 compares complete header/lines/snapshot to retained source; this is not an effect-ID prefix CHECK. | Do not classify by header or line ID prefix. |
| ME issue/scrap and all IC effects | Shared posting575 emits PST plus UUID. Posting schema12-32 contains scoped FKs, uniqueness, source-kind and seal constraints, with no disjoint ME/IC ID-prefix CHECK. Both sources use Manual source_kind. | Do not return early for generic PST or Manual effects. |
| ME partial finished goods | Shared receipt artifacts IRP1-GLE/IRP1-PST (receipt domain188-205). Receipt SQL273-292 enforces canonical artifact formulas; manufacturing481-494 binds source_number to completion and phase/cost/receipt links. These prefixes also serve ordinary receipts. | IRP prefix is not a manufacturing discriminator. |
| IC recognition, partial settlement and elimination | DB closure125 checks IC1 plan identity;194 enforces every A/B/G header number formula for every kind. Phase229-240 binds complete native effects/three distinct humans, not an effect prefix. | Header-number relevance is proved for accepted IC entries, but cannot replace the parent read for children/effects. |
| Native financial dimensions | Dimension row carries only generic entry_line_id; existing IC296 resolves native line, and305 preserves deleted-line behavior while line/header events close the owner. | Do not shortcut generic GLL/IRP line IDs or ignore OLD/deletion events. |
| Detached native inverse | ME535-538 joins the original effect/header; IC298-300 rejects an inverse of an IC source. The new inverse header/effect may have ordinary namespaces. | Keep both original-effect checks before any relevance return. |

Order/completion source tables have their own ME1/ME1C CHECKs; those do not constrain every shared financial artifact ID. Cancel/void, partial finished output, source-bound scrap, elimination and SQL-direct manipulation must remain covered. A universal effect-prefix fast path is rejected.

## Minimal safe hypotheses for the next isolated profile/implementation

1. First profile unchanged final22 on current17.11 after all six runs: measure stage exit/commit, exact nested query digests/calls, trigger times/calls, planning, WAL/I/O and identity/transaction lock waits. Use real source-owned cycles, same role/SoD/RLS and independent financial oracle. Diagnostic runs are separate from the fairness population.
2. A narrow new migration could replace only IC trigger extraction for hot financial/event tables with typed scalar access. Preserve the existing parent queries, complete closure functions, current and OLD header relevance, both inverse IDs, missing/deleted-line behavior and INVOKER/RLS context. Move the existing audit/outbox ID relevance predicate before full-row JSON construction with identical INSERT/UPDATE/DELETE and NULL semantics; this changes serialization work, not which source is guarded.
3. Reuse a fetched current parent number only within one trigger invocation when OLD and NEW resolve to the same exact tenant/entry pair. Still execute both original obligations and both inverse checks. Never cache classification across transactions, discard OLD events, skip parent resolution for generic IDs or introduce SECURITY DEFINER/row_security bypass. This is a hypothesis requiring implementation review and SQL-direct proof, not an approved change.
4. Adversarial acceptance must cover foreign tenant same local IDs; forged arbitrary PST/GLE/GLL IDs; ordinary-to-IC-to-ordinary rename within one transaction; IC delete/rename while deferred events remain; OLD/NEW reparent attempts; deleted/recreated dimension parents; detached ME/IC reversals; partial finished IRP receipts/cancel/scrap; all IC recognize/settle/eliminate books; persisted permission revocation; retry/lost response; rollback and restore. Any classification or economic result drift refuses optimization.

No new library, index, cache, partition, pool, authentication relaxation or background worker is recommended without a separate demonstrated bottleneck and matching correctness gate.
