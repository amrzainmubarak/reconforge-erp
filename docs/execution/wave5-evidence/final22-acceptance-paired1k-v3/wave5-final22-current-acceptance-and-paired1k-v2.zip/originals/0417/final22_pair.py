"""Ignored FINAL22 paired controller: preparation is not authorization to launch.

Only --mode run launches workloads; parent must first receive human quiet-window
approval. One unchanged final22 harness is used against explicit frozen roots.
Both child and whole-run deadlines reserve bounded cleanup. No automatic speed,
CPU, whole-host cost, resource improvement, or competitor acceptance is granted.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import importlib.util
import json
import os
import re
import signal
import statistics
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from native_observations import (  # noqa: E402 - isolated sibling bootstrap
    OwnedJob,
    observe_load,
    observe_scheme,
    process_identity,
    require,
    validate_power,
)

COMMITS = {"baseline": "6362724f2337a79c3d7569574f7bf9591a018524",
           "candidate": "22ebfd78e293aafa13d81b3a0bbf287491951115"}
ROOTS = {"baseline": Path("C:/Users/LOQ/.codex/worktrees/reconforge-integration-wave4/reconforge-erp"),
         "candidate": Path("C:/Users/LOQ/.codex/worktrees/reconforge-integration-wave5/reconforge-erp")}
PYTHON = Path("F:/reconforge-erp/.venv-baseline-20261008/Scripts/python.exe")
IMAGE = "postgres:17.11-alpine@sha256:aa90e97ee862e558111d34cfb8b2c4bec768c2b039fb791341686928560263b3"
ORDER = ((1, "baseline"), (1, "candidate"), (2, "candidate"), (2, "baseline"), (3, "baseline"), (3, "candidate"))
FILES = ("final22_pair.py", "owned_child.py", "native_observations.py",
         "original-verifiers/benchmark_global_engineering_pair.py", "original-verifiers/verify_native_posting_pair.py")
SCHEMA = "final22-native-posting-pair-v1"
METRICS = ("posting_seconds", "throughput", "p50", "p95", "p99", "client_cpu_seconds",
           "container_cpu_seconds", "bounded_batch_read_seconds")
CLEANUP_RESERVE = 120
CHILD_TIMEOUT = 2700
BUSINESS_BUDGET = 1800


def sha(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def unique_object(values: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in values:
        require(key not in result, "Duplicate JSON key")
        result[key] = value
    return result


def read(path: Path) -> dict[str, Any]:
    packet = json.loads(path.read_bytes(), object_pairs_hook=unique_object,
                        parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Nonfinite JSON")))
    require(isinstance(packet, dict), "Expected JSON object")
    return packet


def write(path: Path, packet: dict[str, Any], *, immutable: bool = True) -> str:
    raw = (json.dumps(packet, indent=2, ensure_ascii=True, allow_nan=False) + "\n").encode()
    path.parent.mkdir(parents=True, exist_ok=True)
    if immutable:
        with path.open("xb") as stream:
            stream.write(raw)
    else:
        temporary = path.with_suffix(path.suffix + ".writing")
        temporary.write_bytes(raw)
        temporary.replace(path)
    return hashlib.sha256(raw).hexdigest()


def checked(argv: list[str], *, cwd: Path | None = None, timeout: float = 30,
            environment: dict[str, str] | None = None, deadline: float | None = None) -> bytes:
    timeout = bounded(timeout, deadline)
    result = subprocess.run(argv, cwd=cwd, env=environment, capture_output=True, timeout=timeout, check=False)
    require(result.returncode == 0, f"Read-only or owned command failed: {Path(argv[0]).name}")
    return result.stdout


def bounded(limit: float, deadline: float | None) -> float:
    remaining = limit if deadline is None else min(limit, deadline - time.monotonic())
    require(remaining > 0, "No remaining overall command/cleanup budget")
    return remaining


def source(root: Path, expected: str, *, deadline: float | None = None) -> dict[str, Any]:
    require(root.resolve() in {path.resolve() for path in ROOTS.values()}, "Unexpected runtime root")
    head = checked(["git", "rev-parse", "HEAD"], cwd=root, deadline=deadline).decode().strip()
    require(head == expected, "Frozen source HEAD differs")
    require(not checked(["git", "status", "--porcelain", "--untracked-files=no"], cwd=root, deadline=deadline), "Tracked source dirty")
    require(not checked(["git", "ls-files", "--others", "--exclude-standard", "-z"], cwd=root, deadline=deadline),
            "Nonignored untracked source present")
    names = sorted(name for name in checked(["git", "ls-files", "-z"], cwd=root, deadline=deadline).decode().split("\0") if name)
    digest = hashlib.sha256()
    for name in names:
        require(deadline is None or time.monotonic() < deadline, "Overall deadline exhausted during source verification")
        path = root / name
        require(path.resolve().is_relative_to(root.resolve()) and path.is_file(), "Tracked source missing or escapes root")
        digest.update(name.encode())
        digest.update(bytes.fromhex(sha(path)))
    return {"commit": head, "tracked_sha256": digest.hexdigest(), "tracked_files": len(names),
            "clean_tracked": True, "nonignored_untracked_empty": True, "runtime_root": str(root.resolve())}


def load_oracle() -> Any:
    spec = importlib.util.spec_from_file_location("final22_original_global_oracle", HERE / FILES[3])
    require(spec is not None and spec.loader is not None, "Original stdlib oracle missing")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def check_bundle(plan: dict[str, Any]) -> None:
    require(plan["schema_version"] == "final22-pair-readiness-v1" and plan["commits"] == COMMITS,
            "Readiness source contract differs")
    require(set(plan["tool_sha256"]) == set(FILES), "Readiness tool population differs")
    require(all(sha(HERE / name) == plan["tool_sha256"][name] for name in FILES), "Controller/oracle bytes changed")
    require(sha(PYTHON) == plan["python_sha256"], "Actual Python executable changed")
    harness = ROOTS["candidate"] / ".github/scripts/benchmark_enterprise_finance.py"
    require(str(harness.resolve()) == plan["harness_path"] and sha(harness) == plan["harness_sha256"],
            "Common FINAL22 harness changed")
    require(plan["image"] == IMAGE and plan["business_budget_seconds"] == BUSINESS_BUDGET
            and plan["child_absolute_seconds"] == CHILD_TIMEOUT and plan["cleanup_reserve_seconds"] == CLEANUP_RESERVE
            and type(plan["overall_wall_seconds"]) is int and plan["overall_wall_seconds"] == 7200,
            "Readiness resource bounds differ")


def prepare(path: Path) -> dict[str, Any]:
    require(not path.exists(), "Readiness packet already exists")
    states = {name: source(root, COMMITS[name]) for name, root in ROOTS.items()}
    origins = {}
    for name, root in ROOTS.items():
        code = ("import sys,json,importlib;from pathlib import Path;sys.path.insert(0,sys.argv[1]);"
                "names=['reconforge.infrastructure.postgres_finance_core','reconforge.infrastructure.postgres_finance_posting',"
                "'reconforge.benchmark.resource_sampling','tests.erp_expansion_browser_seed'];"
                "print(json.dumps({n:str(Path(importlib.import_module(n).__file__).resolve()) for n in names}))")
        environment = os.environ.copy()
        environment["PYTHONPATH"] = str(root.resolve())
        raw = checked([str(PYTHON), "-I", "-c", code, str(root.resolve())], cwd=root, environment=environment)
        values = json.loads(raw)
        require(all(Path(value).resolve().is_relative_to(root.resolve()) for value in values.values()),
                "Editable primary runtime import detected")
        origins[name] = values
    harness = ROOTS["candidate"] / ".github/scripts/benchmark_enterprise_finance.py"
    packet = {"schema_version": "final22-pair-readiness-v1", "status": "ready_not_launched",
              "created_at": datetime.now(UTC).isoformat(), "commits": COMMITS, "sources": states,
              "harness_path": str(harness.resolve()), "harness_sha256": sha(harness),
              "python_path": str(PYTHON.resolve()), "python_sha256": sha(PYTHON),
              "tool_sha256": {name: sha(HERE / name) for name in FILES}, "preflight_module_origins": origins,
              "image": IMAGE, "business_budget_seconds": BUSINESS_BUDGET, "child_absolute_seconds": CHILD_TIMEOUT,
              "overall_wall_seconds": 7200, "cleanup_reserve_seconds": CLEANUP_RESERVE,
              "workload": {"counts": [100, 1000], "workers": 4, "posting_warmup": 20, "read_repetitions": 3,
                           "runs": 6, "order": "BC,CB,BC", "measured_cycles": 6000, "warmup_cycles": 120},
              "quiet_window_authorization": "pending human reply; --mode prepare does not launch workloads",
              "initial_high_load_rejection": {"maximum_host_busy_percent": 25, "intervals": 3, "seconds_per_interval": 2},
              "optional_1000_line_gl_snapshot": "off for both variants; separate current stage pending; not commercial orders",
              "host_readiness_observation": observe_scheme(),
              "no_workload_launched": True, "performance_comparison_accepted": False}
    packet["sources_after"] = {name: source(root, COMMITS[name]) for name, root in ROOTS.items()}
    require(packet["sources"] == packet["sources_after"], "Source changed during readiness")
    write(path, packet)
    return packet


def child_command(plan: dict[str, Any], variant: str, destination: Path) -> tuple[list[str], list[str]]:
    root = ROOTS[variant].resolve()
    business = ["--counts", "100", "1000", "--workers", "4", "--repetitions", "3", "--posting-warmup", "20",
                "--max-seconds", str(BUSINESS_BUDGET), "--runtime-root", str(root), "--postgres-image", IMAGE,
                "--output", str(destination.resolve())]
    actual = [str(PYTHON.resolve()), "-I", str(HERE / "owned_child.py"), "--harness", plan["harness_path"],
              "--harness-sha256", plan["harness_sha256"], "--runtime-root", str(root), "--image", IMAGE,
              "--ownership", str(destination.parent / f"{destination.name}-ownership.json"),
              "--origin-report", str(destination.parent / f"{destination.name}-origins.json"),
              "--admission", str(destination.parent / f"{destination.name}-admission.json"), "--", *business]
    return actual, [str(PYTHON.resolve()), plan["harness_path"], *business]


def validate_ownership(value: dict[str, Any], identity: dict[str, Any], inspect: dict[str, Any]) -> str:
    require(value["schema_version"] == "audited-final22-owned-container-v1" and value["process"] == identity,
            "Audited container PID/birth/path ownership differs")
    require(Path(identity["executable"]).resolve() == PYTHON.resolve(), "Owned process executable differs")
    require(value["pre_spawn_exact_name_absent"] is True and value["image"] == IMAGE and value["label"] == "reconforge.owner=enterprise-finance-benchmark"
            and bool(re.fullmatch(r"reconforge-enterprise-finance-[0-9a-f]{12}", value["name"])), "Audited creation differs")
    container = inspect["Id"]
    require(bool(re.fullmatch(r"[0-9a-f]{64}", container)) and inspect["Name"] == "/" + value["name"]
            and inspect["Config"]["Image"] == IMAGE
            and inspect["Config"]["Labels"].get("reconforge.owner") == "enterprise-finance-benchmark",
            "Exact immutable container/name/image/label differ")
    require(datetime.fromisoformat(inspect["Created"]) >= datetime.fromisoformat(value["observed_at"]),
            "Container predates audited creation")
    return container


def inspect_owned(ownership: Path, identity: dict[str, Any], *, deadline: float | None = None) -> dict[str, Any] | None:
    if not ownership.exists():
        return None
    creation_path = ownership.with_suffix(".created.json")
    if not creation_path.exists():
        return None
    value = read(ownership)
    creation = read(creation_path)
    require(value["process"] == identity, "Owned audit identity differs")
    require(creation["schema_version"] == "final22-docker-creation-response-v1" and creation["process"] == identity
            and creation["audit_sha256"] == sha(ownership) and type(creation["returncode"]) is int and creation["returncode"] == 0
            and bool(re.fullmatch(r"[0-9a-f]{64}", creation["container_id"])), "Exact creation response ownership missing")
    # Only these safe inspection fields are retained. Docker Env contains a
    # generated password and is deliberately never requested or written.
    command = ["docker", "inspect", "--format", "{{json .Id}}\t{{json .Name}}\t{{json .Config.Image}}\t{{json .Config.Labels}}\t{{json .Created}}", value["name"]]
    process = subprocess.run(command, capture_output=True, timeout=bounded(5, deadline), check=False)
    if process.returncode:
        return None
    values = [json.loads(word) for word in process.stdout.decode().strip().split("\t")]
    require(len(values) == 5, "Container safe inspection format differs")
    observed = {"Id": values[0], "Name": values[1], "Config": {"Image": values[2], "Labels": values[3]}, "Created": values[4]}
    require(observed["Id"] == creation["container_id"], "Same-name replacement is not the acknowledged created container")
    validate_ownership(value, identity, observed)
    return {"audit_sha256": sha(ownership), "audit": value, "inspection": observed,
            "creation_response_sha256": sha(creation_path), "creation_response": creation}


def stop_owned(process: Any, identity: dict[str, Any], job: Any, *, deadline: float | None = None) -> dict[str, Any]:
    row = {"status": "already_exited", "forced": False, "identity": identity}
    if process.poll() is not None:
        return row
    require(process_identity(process.pid) == identity, "PID birth/path changed; refuse to stop")
    try:
        process.send_signal(signal.CTRL_BREAK_EVENT)
        process.wait(timeout=bounded(20, deadline))
        row["status"] = "gracefully_stopped"
        return row
    except (OSError, subprocess.TimeoutExpired):
        require(job is not None, "No retained process-tree job handle")
        job.terminate()
        if deadline is None or time.monotonic() < deadline:
            process.wait(timeout=bounded(5, deadline))
        row.update(status="forced_retained_job_handle_stop", forced=True)
        return row


def cleanup_container(bound: dict[str, Any] | None, ownership: Path, identity: dict[str, Any], *, aborted: bool,
                      deadline: float | None = None) -> dict[str, Any]:
    if bound is None:
        bound = inspect_owned(ownership, identity, deadline=deadline)
    require(bound is not None, "No immutable audited container binding; cleanup unverified")
    container = validate_ownership(bound["audit"], identity, bound["inspection"])
    # Name may disappear under --rm; inspect only the previously pinned ID.
    current = subprocess.run(["docker", "container", "ls", "--all", "--no-trunc", "--filter", f"id={container}",
                              "--format", "{{.ID}}"], capture_output=True, timeout=bounded(10, deadline), check=False)
    require(current.returncode == 0, "Owned container presence check failed")
    names = current.stdout.decode().split()
    require(not names or names == [container], "Container ID presence ambiguous")
    action = "already_absent"
    if names:
        require(aborted, "Successful harness left its owned container; refuse acceptance")
        checked(["docker", "rm", "--force", container], timeout=20, deadline=deadline)
        action = "removed_exact_audited_id"
    after = checked(["docker", "container", "ls", "--all", "--no-trunc", "--filter", f"id={container}",
                     "--format", "{{.ID}}"], timeout=10, deadline=deadline)
    require(not after.strip(), "Exact owned container remains")
    return {"status": "verified_absent", "container_id": container, "action": action,
            "ownership_audit_sha256": bound["audit_sha256"], "bound_inspection": bound["inspection"],
            "creation_response_sha256": bound["creation_response_sha256"]}


def validate_report(packet: dict[str, Any], variant: str, plan: dict[str, Any], reported_command: list[str]) -> dict[str, Any]:
    root, commit = ROOTS[variant].resolve(), COMMITS[variant]
    require(packet["source_commit"] == packet["source_commit_after"] == commit
            and packet["source_sha256"] == packet["source_sha256_after"] == plan["sources"][variant]["tracked_sha256"],
            "Report does not bind expected original source")
    require(packet["source_unchanged"] is True and packet["owned_container_removed"] is True
            and packet["runtime_role_flags"] == [False, False] and all(type(v) is bool for v in packet["runtime_role_flags"]),
            "Source/cleanup/current nonowner status failed")
    require(packet["harness_sha256"] == packet["harness_sha256_after"] == plan["harness_sha256"]
            and Path(packet["harness_path"]).resolve() == Path(plan["harness_path"]).resolve(), "Common harness provenance differs")
    require(packet["command"] == reported_command and Path(packet["runtime_root"]).resolve() == root
            and Path(packet["launch_cwd"]).resolve() == root, "Actual harness command/runtime origin differs")
    require(packet["image"] == IMAGE and packet["postgres_version"].startswith("17.11")
            and packet["max_seconds"] == BUSINESS_BUDGET and type(packet["max_seconds"]) is int,
            "Image/version/time budget differs")
    require(packet["revision"] == ("0132_pg_stock_inverse_dispatch" if variant == "baseline" else "0136_pg_inventory_scope"),
            "Actual variant migration head differs")
    require(packet["module_origins"] == {
        "posting": str(root / "reconforge/infrastructure/postgres_finance_posting.py"),
        "core": str(root / "reconforge/infrastructure/postgres_finance_core.py")}, "Native module origins differ")
    require(packet["planner_experiment"] == {"join_collapse_limit": 8, "from_collapse_limit": 8}
            and packet["cost_per_transaction"] is None and "failure" not in packet, "Instrumented or failed configuration")
    original = load_oracle()
    summary = original.verify(packet, root, commit, 1000)
    # Preserve separate windows. The legacy verifier's combined counter is
    # deliberately not published or used as an acceptance metric here.
    summary.pop("total_cpu_seconds_per_success", None)
    original._retained.validate_measurement(packet, commit)
    require(summary["oracle_total_minor"] == "493671004", "Independent 1000-cycle oracle differs")
    require(packet["verified_reads"][0]["expected"]["debit_minor"] == "46669102", "Independent 100-cycle prefix differs")
    for field in ("workers", "repetitions", "posting_warmup_cycles", "snapshot_lines"):
        require(type(packet[field]) is int, "Boolean/float count configuration")
    require(packet["posting_profile"]["enabled"] is False and packet["posting_profile"]["raw_phase_observations"] == []
            and packet["posting_profile"]["function_profile"]["enabled"] is False, "Posting profiling enabled")
    sampling = packet["resource_sampling"]
    observer = sampling["host_processor_observation"]
    require(observer["requested"] is True and observer["status"] == "enabled"
            and observer["cleanup"] == {"status": "closed", "api_status": 0}, "Host sampler lifecycle failed")
    require(len(sampling["raw_samples"]) >= 2, "Insufficient sparse host samples")
    for row in sampling["raw_samples"]:
        host = row["host_processor"]
        require(isinstance(host, dict), "Missing original host observation")
        validate_power({"status": "available", "power": host.get("power")})
    summary["resource_scope"] = {"client_cpu": "client posting process_time window; includes concurrent resource observer thread, excludes waits/external processes",
        "database_cpu": "dedicated container cgroup bracketing interval; includes read-only exec/observer overhead and does not have identical client boundaries",
        "sampled_resources": "10-second samples span warmup/posting/read work; sampled peaks may miss spikes; lifetime peaks include setup",
        "whole_host_cpu_or_cost": "unmeasured; no sum of distinct client/container windows", "cost_per_success_currency": None}
    return summary


def safe_path(parent: Path, relative: str) -> Path:
    require(isinstance(relative, str) and relative and "\\" not in relative and ":" not in relative,
            "Nonportable evidence path")
    path = (parent / relative).resolve()
    require(path.is_relative_to(parent.resolve()) and ".." not in Path(relative).parts, "Evidence path escapes")
    return path


def verify_complete(manifest: Path, trusted_sha256: str, plan: dict[str, Any]) -> dict[str, Any]:
    require(sha(manifest) == trusted_sha256 and bool(re.fullmatch(r"[a-f0-9]{64}", trusted_sha256)), "Trusted manifest SHA differs")
    value = read(manifest)
    require(value["schema_version"] == SCHEMA and value["status"] == "passed"
            and value["commits"] == COMMITS and value["pairs"] == 3 and type(value["pairs"]) is int
            and value["count"] == 1000 and type(value["count"]) is int and len(value["runs"]) == 6,
            "Incomplete FINAL22 manifest")
    summaries, effects, containers, hashes = [], set(), set(), set()
    reference = None
    previous_finished = None
    scheme = None
    parameter_sha = None
    original = load_oracle()
    for record, (repetition, variant) in zip(value["runs"], ORDER, strict=True):
        require(record["repetition"] == repetition and type(record["repetition"]) is int
                and record["variant"] == variant and record["child_exit_code"] == 0
                and type(record["child_exit_code"]) is int, "Run order or child result differs")
        report = safe_path(manifest.parent, record["report"])
        digest = sha(report)
        require(digest == record["report_sha256"] and digest not in hashes, "Original report hash differs or repeats")
        hashes.add(digest)
        packet = read(report)
        _actual, reported = child_command(plan, variant, report.parent)
        summary = validate_report(packet, variant, plan, reported)
        cleanup = record["cleanup"]
        require(cleanup["status"] == "verified_absent" and cleanup["container_id"] not in containers, "Cleanup/fresh container closure failed")
        containers.add(cleanup["container_id"])
        final = json.loads(packet["container_resources_final_sample"], object_pairs_hook=unique_object)
        require(final["Container"] == cleanup["container_id"], "Final actual container differs from audited ID")
        population = set(packet["posting"]["ordered_effect_ids"]) | set(packet["posting_warmup"]["effect_ids"])
        require(len(population) == 1020 and not population & effects, "Fresh effect population differs or repeats")
        effects.update(population)
        config = {field: packet[field] for field in original.CONFIG}
        reference = config if reference is None else reference
        require(config == reference, "Matched workload/hardware/database CONFIG differs")
        started, finished = (datetime.fromisoformat(packet[key]) for key in ("started_at", "finished_at"))
        require(started.tzinfo is not None and finished.tzinfo is not None and started < finished
                and (previous_finished is None or previous_finished <= started), "Invalid or overlapping original run timestamps")
        previous_finished = finished
        for phase in ("before", "after"):
            binding = record[f"environment_{phase}"]
            path = safe_path(manifest.parent, binding["path"])
            require(sha(path) == binding["sha256"], "Original power sidecar SHA differs")
            sidecar = read(path)
            scheme = validate_power(sidecar, scheme)
            stdout = base64.b64decode(sidecar["stdout_base64"], validate=True)
            require(hashlib.sha256(stdout).hexdigest() == sidecar["stdout_sha256"], "Powercfg original stdout differs")
            text = stdout.decode("utf-16") if stdout.startswith((b"\xff\xfe", b"\xfe\xff")) else stdout.decode("utf-8", errors="replace")
            matches = re.findall(r"\b[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}\b", text)
            require(len(matches) == 1 and matches[0].lower() == scheme, "Retained GUID differs from original powercfg bytes")
            parameters = sidecar["processor_power_parameters"]
            raw_parameters = base64.b64decode(parameters["stdout_base64"], validate=True)
            require(parameters["exit_code"] == 0 and parameters["command"] == ["powercfg", "/query", scheme, "SUB_PROCESSOR"]
                    and hashlib.sha256(raw_parameters).hexdigest() == parameters["stdout_sha256"], "Processor settings original bytes differ")
            parameter_sha = parameters["stdout_sha256"] if parameter_sha is None else parameter_sha
            require(parameters["stdout_sha256"] == parameter_sha, "Observed processor power parameters changed")
        origins_path = safe_path(manifest.parent, record["origins"]["path"])
        origins = read(origins_path)
        require(sha(origins_path) == record["origins"]["sha256"] and origins["status"] == "passed"
                and origins["foreign_modules"] == [] and origins["process"] == record["process"]
                and origins["harness_sha256_after"] == plan["harness_sha256"]
                and Path(origins["runtime_root"]).resolve() == ROOTS[variant].resolve(),
                "Runtime origin closure failed")
        require(all(Path(row["path"]).resolve().is_relative_to(ROOTS[variant].resolve()) for row in origins["origins"]),
                "Foreign imported source module")
        by_module = {row["module"]: row["path"] for row in origins["origins"]}
        require(len(by_module) == len(origins["origins"]) and all(by_module.get(module) == expected
                for module, expected in plan["preflight_module_origins"][variant].items()),
                "Required actual runtime module origin differs or is missing")
        owned_path = safe_path(manifest.parent, f"{repetition}-{variant}-ownership.json")
        require(sha(owned_path) == cleanup["ownership_audit_sha256"], "Audited Docker ownership original SHA differs")
        require(validate_ownership(read(owned_path), record["process"], cleanup["bound_inspection"]) == cleanup["container_id"],
                "Audited immutable container provenance differs")
        creation_path = owned_path.with_suffix(".created.json")
        require(sha(creation_path) == cleanup["creation_response_sha256"], "Original Docker creation response SHA differs")
        creation = read(creation_path)
        require(creation["container_id"] == cleanup["container_id"] and creation["process"] == record["process"]
                and creation["audit_sha256"] == cleanup["ownership_audit_sha256"] and creation["returncode"] == 0,
                "Exact successful creation-response ownership differs")
        summaries.append({"repetition": repetition, "variant": variant, "report_sha256": digest, "verified": summary})
    medians = {variant: {metric: statistics.median(row["verified"][metric] for row in summaries if row["variant"] == variant)
                         for metric in METRICS} for variant in COMMITS}
    change = {metric: (medians["candidate"][metric] / medians["baseline"][metric] - 1) * 100 for metric in METRICS}
    return {"schema_version": "final22-offline-original-pair-proof-v1", "status": "passed",
            "financial_verification": "passed", "observed_environment_verification": "passed",
            "trusted_manifest_sha256": trusted_sha256, "commits": COMMITS, "runs": summaries,
            "original_measured_cycles": 6000, "original_warmup_cycles": 120,
            "measured_read_requests": 19998, "medians": medians, "descriptive_candidate_change_percent": change,
            "performance_comparison_accepted": False, "cost_per_success_currency": None,
            "limits": ["No external attestation; offline checks bind retained original bytes, not a new database audit.",
                       "Sparse observed AC/saver/scheme plus CONFIG equality does not prove continuous equal load, overlay, scheduling or thermal state.",
                       "One entity USD two-line native cycles include authentication; no mixed ERP/HTTP equivalence or competitor ranking.",
                       "Separate client/container CPU windows are never summed; no whole-host total or monetary cost."]}


def run(plan: dict[str, Any], output: Path) -> dict[str, Any]:
    require(sys.platform == "win32", "Live controller only supports original Windows host")
    require(not output.exists(), "Fresh output directory required")
    check_bundle(plan)
    output.mkdir(parents=True)
    started, deadline = time.monotonic(), time.monotonic() + plan["overall_wall_seconds"]
    state: dict[str, Any] = {"schema_version": SCHEMA, "status": "running", "commits": COMMITS, "pairs": 3, "count": 1000,
        "started_at": datetime.now(UTC).isoformat(), "runs": [], "performance_comparison_accepted": False,
        "overall_wall_seconds": plan["overall_wall_seconds"], "cleanup_reserve_seconds": CLEANUP_RESERVE,
        "financial_verification": "pending", "observed_environment_verification": "pending", "cost_per_success_currency": None}
    guid = None
    try:
        require({name: source(root, COMMITS[name], deadline=deadline) for name, root in ROOTS.items()} == plan["sources"],
                "Source bytes differ from readiness")
        initial = [observe_load()]
        for _ in range(3):
            time.sleep(2)
            initial.append(observe_load())
        state["initial_host_load_observations"] = initial
        busy = []
        for first, last in zip(initial, initial[1:], strict=False):
            validate_power(first)
            validate_power(last)
            a, b = first["host_cpu_100ns"], last["host_cpu_100ns"]
            total = (b["kernel_including_idle"] + b["user"]) - (a["kernel_including_idle"] + a["user"])
            idle = b["idle"] - a["idle"]
            require(total > 0 and 0 <= idle <= total, "Initial host CPU counters invalid")
            busy.append((total - idle) / total * 100)
        state["initial_host_busy_percent"] = busy
        require(max(busy) <= 25, "Initial host load exceeds explicit 25% admission ceiling; foreign workloads untouched")
        for repetition, variant in ORDER:
            require(time.monotonic() < deadline - CLEANUP_RESERVE, "Overall quiet-window admission deadline exhausted")
            check_bundle(plan)
            require(source(ROOTS[variant], COMMITS[variant], deadline=deadline) == plan["sources"][variant], "Source changed before child")
            destination = output / f"{repetition}-{variant}"
            actual, reported = child_command(plan, variant, destination)
            row: dict[str, Any] = {"repetition": repetition, "variant": variant, "command": actual,
                "reported_harness_command": reported, "report": f"{destination.name}/result.json", "child_exit_code": None,
                "child_absolute_seconds": min(CHILD_TIMEOUT, max(1, deadline - CLEANUP_RESERVE - time.monotonic())),
                "host_load_observations": []}
            state["runs"].append(row)
            before = observe_scheme(deadline=deadline - CLEANUP_RESERVE)
            before_path = output / f"{destination.name}-power-before.json"
            row["environment_before"] = {"path": before_path.name, "sha256": write(before_path, before)}
            guid = validate_power(before, guid)
            settings_sha = before["processor_power_parameters"]["stdout_sha256"]
            state.setdefault("processor_power_parameters_sha256", settings_sha)
            require(settings_sha == state["processor_power_parameters_sha256"], "Processor power parameters changed before child")
            write(output / "pair.json", state, immutable=False)
            environment = os.environ.copy()
            environment["PYTHONPATH"] = str(ROOTS[variant].resolve())
            environment.pop("PYTHONHOME", None)
            ownership = output / f"{destination.name}-ownership.json"
            process = None
            job = None
            bound = None
            aborted = True
            with (output / f"{destination.name}.log").open("xb") as log:
                try:
                    process = subprocess.Popen(actual, cwd=ROOTS[variant], env=environment, stdout=log, stderr=subprocess.STDOUT,
                                               creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)
                    identity = process_identity(process.pid)
                    row["process"] = identity
                    try:
                        job = OwnedJob(process)
                    except Exception:
                        process.kill()  # retained Popen process handle; launcher is still admission-gated
                        process.wait(timeout=5)
                        raise
                    row["process_tree_binding"] = "retained kill-on-close Windows Job handle; gated before any child subprocess"
                    write(output / f"{destination.name}-admission.json", {"process": identity, "owned_job_assigned": True})
                    child_deadline = min(deadline - CLEANUP_RESERVE, time.monotonic() + row["child_absolute_seconds"])
                    next_sample = time.monotonic()
                    next_ownership = time.monotonic()
                    while process.poll() is None:
                        now = time.monotonic()
                        require(now < child_deadline, "Owned child or overall wall deadline exhausted")
                        require(not (output / "STOP").exists(), "Operator stop file observed; incomplete population retained")
                        if bound is None and now >= next_ownership:
                            bound = inspect_owned(ownership, identity, deadline=child_deadline)
                            next_ownership = now + 1
                            if bound is not None:
                                row["audited_container_binding"] = bound
                        if now >= next_sample:
                            observation = observe_load()
                            row["host_load_observations"].append(observation)
                            validate_power(observation)
                            next_sample = now + 10
                        time.sleep(min(1, max(.05, child_deadline - now)))
                    row["child_exit_code"] = process.returncode
                    aborted = process.returncode != 0
                finally:
                    if process is not None:
                        try:
                            row["process_cleanup"] = stop_owned(process, identity, job, deadline=deadline)
                        finally:
                            if job is not None:
                                job.close()
                        try:
                            row["cleanup"] = cleanup_container(bound, ownership, identity, aborted=aborted, deadline=deadline)
                        except Exception as cleanup_error:
                            row["cleanup"] = {"status": "unverified", "failure_type": type(cleanup_error).__name__,
                                              "foreign_deletion_refused": True}
                            raise
            after = observe_scheme(deadline=deadline)
            after_path = output / f"{destination.name}-power-after.json"
            row["environment_after"] = {"path": after_path.name, "sha256": write(after_path, after)}
            validate_power(after, guid)
            require(after["processor_power_parameters"]["stdout_sha256"] == state["processor_power_parameters_sha256"],
                    "Processor power parameters changed after child")
            report_path = destination / "result.json"
            require(report_path.is_file(), "Child has no original result; acceptance refused")
            row["report_sha256"] = sha(report_path)
            require(row["child_exit_code"] == 0, "Child failed; original/partial evidence retained")
            origin_path = output / f"{destination.name}-origins.json"
            row["origins"] = {"path": origin_path.name, "sha256": sha(origin_path)}
            require(read(origin_path)["status"] == "passed", "Loaded module origin closure failed")
            row["verified"] = validate_report(read(report_path), variant, plan, reported)
            row["financial_verification"] = "passed"
            require(source(ROOTS[variant], COMMITS[variant], deadline=deadline) == plan["sources"][variant], "Source changed after child")
            write(output / "pair.json", state, immutable=False)
            print(json.dumps({"repetition": repetition, "variant": variant, "financial_verification": "passed",
                              "observed_environment_verification": "passed", "elapsed_seconds": time.monotonic() - started}), flush=True)
        require(time.monotonic() < deadline, "Overall quiet window exhausted before complete validation")
        check_bundle(plan)
        state["sources_after"] = {name: source(root, COMMITS[name], deadline=deadline) for name, root in ROOTS.items()}
        require(state["sources_after"] == plan["sources"], "Final complete source custody changed")
        state.update(status="passed", financial_verification="passed", observed_environment_verification="passed")
        manifest_sha = write(output / "manifest.json", state)
        proof = verify_complete(output / "manifest.json", manifest_sha, plan)
        require(time.monotonic() < deadline, "Overall window exhausted before independent closure")
        state["manifest_sha256"] = manifest_sha
        state["offline_proof_sha256"] = write(output / "offline-proof.json", proof)
    except (Exception, KeyboardInterrupt) as exc:
        state.update(status="interrupted" if isinstance(exc, KeyboardInterrupt) else "failed", failure_type=type(exc).__name__,
                     failure=str(exc), financial_verification="not_accepted_complete_population",
                     observed_environment_verification="not_accepted_complete_population")
        # Preserve any raw child evidence even when it could not pass the gate.
        for row in state["runs"]:
            path = output / row["report"]
            if path.is_file():
                row["retained_raw_report_sha256"] = sha(path)
        if state["runs"] and "environment_after" not in state["runs"][-1] and time.monotonic() < deadline:
            row = state["runs"][-1]
            after_path = output / f"{row['repetition']}-{row['variant']}-power-after-failure.json"
            try:
                row["environment_after_failure"] = {"path": after_path.name, "sha256": write(after_path, observe_scheme(deadline=deadline))}
            except Exception as observation_error:
                row["after_failure_observation_failure_type"] = type(observation_error).__name__
    finally:
        state.update(finished_at=datetime.now(UTC).isoformat(), wall_seconds=time.monotonic() - started)
        write(output / "pair.json", state, immutable=False)
    return state


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("prepare", "run", "verify"), required=True)
    parser.add_argument("--readiness", type=Path, required=True)
    parser.add_argument("--readiness-sha256")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--manifest-sha256")
    args = parser.parse_args()
    if args.mode == "prepare":
        result = prepare(args.readiness.resolve())
        print(json.dumps({"status": result["status"], "readiness_sha256": sha(args.readiness), "no_workload_launched": True}))
        return 0
    require(args.readiness_sha256 is not None and sha(args.readiness) == args.readiness_sha256, "Explicit trusted readiness SHA required")
    plan = read(args.readiness)
    check_bundle(plan)
    require(args.output is not None, "Fresh output required")
    if args.mode == "run":
        result = run(plan, args.output.resolve())
    else:
        require(args.manifest is not None and args.manifest_sha256 is not None, "Trusted original manifest required")
        result = verify_complete(args.manifest.resolve(), args.manifest_sha256, plan)
        write(args.output.resolve(), result)
    print(json.dumps({"status": result["status"], "output": str(args.output), "performance_comparison_accepted": False}))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
