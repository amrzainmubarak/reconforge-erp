"""File-only lifecycle/adversarial tests. No child benchmark/DB/Docker launch."""
from __future__ import annotations

import copy
import json
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

import final22_pair as c
from native_observations import validate_power

ORIGINAL = c.ROOTS["candidate"] / "output/wave5-paired-1k-12fe5f2b/1-baseline/result.json"


def fixture() -> tuple[dict, dict, list[str]]:
    packet = json.loads(ORIGINAL.read_bytes())
    plan = {"harness_path": str(c.ROOTS["candidate"] / ".github/scripts/benchmark_enterprise_finance.py"),
            "harness_sha256": "a" * 64,
            "sources": {"baseline": {"tracked_sha256": packet["source_sha256"]}}}
    _actual, command = c.child_command(plan, "baseline", c.ROOTS["candidate"] / "output/synthetic-only/1-baseline")
    packet.update(max_seconds=1800, harness_path=plan["harness_path"], harness_sha256=plan["harness_sha256"],
                  harness_sha256_after=plan["harness_sha256"], command=command)
    return packet, plan, command


class Contracts(unittest.TestCase):
    def test_original_integer_oracle_and_separate_cpu_windows(self) -> None:
        packet, plan, argv = fixture()
        result = c.validate_report(packet, "baseline", plan, argv)
        self.assertEqual(result["oracle_total_minor"], "493671004")
        self.assertNotIn("total_cpu_seconds_per_success", result)
        self.assertEqual(result["resource_scope"]["cost_per_success_currency"], None)

    def test_source_harness_runtime_and_durability_adversaries(self) -> None:
        for path, changed in (
            (("source_commit",), "0" * 40), (("source_sha256_after",), "b" * 64),
            (("harness_sha256",), "b" * 64), (("runtime_root",), "F:/reconforge-erp"),
            (("module_origins", "core"), "F:/reconforge-erp/reconforge/infrastructure/postgres_finance_core.py"),
            (("postgres_configuration", "fsync"), "off"), (("runtime_role_flags",), [False, True]),
            (("owned_container_removed",), False), (("image",), "postgres:17.11-alpine"),
            (("revision",), "0131_pg_operational_fx_revaluation"), (("max_seconds",), 3600),
            (("posting", "completed_indices"), list(range(999))),
            (("posting", "expected", "cash_minor"), "493671005"), (("workers",), 4.0),
            (("posting_profile", "enabled"), True)):
            with self.subTest(path=path):
                packet, plan, argv = fixture()
                target = packet
                for field in path[:-1]:
                    target = target[field]
                target[path[-1]] = changed
                with self.assertRaises((ValueError, c.load_oracle()._retained.VerificationError)):
                    c.validate_report(packet, "baseline", plan, argv)

    def test_replaced_posting_id_cannot_hide_in_read_population(self) -> None:
        packet, plan, argv = fixture()
        packet["posting"]["ordered_effect_ids"][-1] = "unique-invented-effect"
        with self.assertRaises(ValueError):
            c.validate_report(packet, "baseline", plan, argv)

    def test_rehashed_battery_sample_refuses(self) -> None:
        packet, plan, argv = fixture()
        packet["resource_sampling"]["raw_samples"][-1]["host_processor"]["power"]["ac_online"] = False
        with self.assertRaises(ValueError):
            c.validate_report(packet, "baseline", plan, argv)

    def test_exact_common_harness_explicit_roots_same_argv(self) -> None:
        _, plan, _ = fixture()
        for variant in c.COMMITS:
            actual, reported = c.child_command(plan, variant, Path("C:/synthetic") / variant)
            self.assertEqual(reported[1], plan["harness_path"])
            self.assertEqual(reported[reported.index("--runtime-root") + 1], str(c.ROOTS[variant].resolve()))
            self.assertEqual(reported[reported.index("--postgres-image") + 1], c.IMAGE)
            self.assertIn("-I", actual)
            self.assertIn("--admission", actual)
            self.assertNotIn("--snapshot-lines", reported)

    def test_power_unavailable_saver_changed_not_defaulted(self) -> None:
        for value in ({"status": "unavailable"}, {"status": "available", "power": {"status": "available", "ac_online": None, "battery_saver_on": False}},
                      {"status": "available", "power": {"status": "available", "ac_online": True, "battery_saver_on": True}}):
            with self.assertRaises(ValueError):
                validate_power(value)

    def test_docker_ownership_exact_immutable_identity(self) -> None:
        identity = {"pid": 1234, "birth": 123456, "executable": str(c.PYTHON.resolve()), "method": "mock-only"}
        value = {"schema_version": "audited-final22-owned-container-v1", "process": identity,
                 "name": "reconforge-enterprise-finance-123456abcdef", "image": c.IMAGE,
                 "label": "reconforge.owner=enterprise-finance-benchmark", "pre_spawn_exact_name_absent": True,
                 "observed_at": "2026-10-12T06:00:00+00:00"}
        inspect = {"Id": "b" * 64, "Name": "/" + value["name"], "Config": {"Image": c.IMAGE,
                   "Labels": {"reconforge.owner": "enterprise-finance-benchmark"}}, "Created": "2026-10-12T06:00:01+00:00"}
        self.assertEqual(c.validate_ownership(value, identity, inspect), "b" * 64)
        for mutated in (dict(identity, birth=999), dict(identity, pid=4321), dict(identity, executable="C:/foreign/python.exe")):
            with self.assertRaises(ValueError):
                c.validate_ownership(value, mutated, inspect)
        for field, altered in (("Id", "b" * 12), ("Name", "/foreign")):
            wrong = copy.deepcopy(inspect)
            wrong[field] = altered
            with self.assertRaises(ValueError):
                c.validate_ownership(value, identity, wrong)
        with self.assertRaises(ValueError):
            c.validate_ownership(value, identity, dict(inspect, Created="2026-10-12T05:59:59+00:00"))
        with self.assertRaises(ValueError):
            c.validate_ownership(dict(value, pre_spawn_exact_name_absent=False), identity, inspect)

    def test_actual_candidate_head_and_unknown_head_refusal(self) -> None:
        packet, plan, _ = fixture()
        root = c.ROOTS["candidate"].resolve()
        plan["sources"]["candidate"] = copy.deepcopy(plan["sources"]["baseline"])
        _actual, command = c.child_command(plan, "candidate", root / "output/synthetic-only/1-candidate")
        packet.update(source_commit=c.COMMITS["candidate"], source_commit_after=c.COMMITS["candidate"], runtime_root=str(root),
                      launch_cwd=str(root), command=command, revision="0136_pg_inventory_scope",
                      module_origins={"posting": str(root / "reconforge/infrastructure/postgres_finance_posting.py"),
                                      "core": str(root / "reconforge/infrastructure/postgres_finance_core.py")})
        self.assertEqual(c.validate_report(packet, "candidate", plan, command)["count"], 1000)
        packet["revision"] = "0136_pg_inventory_hierarchy_rls"
        with self.assertRaises(ValueError):
            c.validate_report(packet, "candidate", plan, command)

    def test_forced_stop_uses_retained_job_not_pid_taskkill(self) -> None:
        identity = {"pid": 1234}
        process = Mock(pid=1234)
        process.poll.return_value = None
        process.send_signal.side_effect = OSError()
        job = Mock()
        with patch.object(c, "process_identity", return_value=identity), patch.object(c.signal, "CTRL_BREAK_EVENT", 1, create=True), patch.object(c.subprocess, "run") as external:
            result = c.stop_owned(process, identity, job)
        job.terminate.assert_called_once()
        external.assert_not_called()
        self.assertEqual(result["status"], "forced_retained_job_handle_stop")

    def test_reused_pid_refuses_all_stops(self) -> None:
        process = Mock(pid=1234)
        process.poll.return_value = None
        job = Mock()
        with patch.object(c, "process_identity", return_value={"pid": 1234, "birth": 999}), self.assertRaises(ValueError):
            c.stop_owned(process, {"pid": 1234, "birth": 100}, job)
        process.send_signal.assert_not_called()
        job.terminate.assert_not_called()

    def test_ambiguous_cleanup_never_runs_delete(self) -> None:
        with patch.object(c, "inspect_owned", return_value=None), patch.object(c.subprocess, "run") as external, self.assertRaises(ValueError):
            c.cleanup_container(None, Path("no-audit.json"), {"pid": 1234}, aborted=True)
        external.assert_not_called()

    def test_trusted_manifest_and_complete_population_fail_closed(self) -> None:
        import tempfile
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "manifest.json"
            c.write(path, {"schema_version": c.SCHEMA, "status": "passed", "commits": c.COMMITS,
                           "pairs": 3, "count": 1000, "runs": []})
            with self.assertRaises(ValueError):
                c.verify_complete(path, "f" * 64, {})
            with self.assertRaises(ValueError):
                c.verify_complete(path, c.sha(path), {})

    def test_expired_deadline_never_launches_command(self) -> None:
        with patch.object(c.time, "monotonic", return_value=7201), patch.object(c.subprocess, "run") as external, self.assertRaises(ValueError):
            c.checked(["docker", "container", "ls"], deadline=7200)
        external.assert_not_called()
        with patch.object(c.time, "monotonic", return_value=7199.75):
            self.assertEqual(c.bounded(20, 7200), .25)

    def test_nonfinite_duplicate_and_escaping_json(self) -> None:
        import tempfile
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "report.json"
            for raw in (b'{"a":1,"a":2}', b'{"a":NaN}'):
                path.write_bytes(raw)
                with self.assertRaises(ValueError):
                    c.read(path)
            for value in ("../foreign.json", "C:/foreign.json", "a\\foreign.json"):
                with self.assertRaises(ValueError):
                    c.safe_path(Path(directory), value)

    def test_bundled_oracles_remain_original_bytes(self) -> None:
        for filename in c.FILES[3:]:
            self.assertEqual(c.sha(c.HERE / filename), c.sha(c.ROOTS["candidate"] / ".github/scripts" / Path(filename).name))


if __name__ == "__main__":
    unittest.main()
