from __future__ import annotations

import hashlib
import json
import re
import subprocess
import time
from datetime import UTC, datetime
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('C:/Users/LOQ/.codex/worktrees/reconforge-integration-wave5/reconforge-erp')
CID = 'a218046582c3e81dc3e61f2d7c800ae119ef7d541d4a8239956e0a7c18589a8c'
PROOF = OUT / 'v3-orphan-readonly-current-inventory-proof-v3.json'
FAILURE = ROOT / 'output/wave5-final22-paired-1k-v3/1-baseline/result.json'
DESTINATION = OUT / 'v3-exact-cleanup-after-six-runs-v1'

def require(value: bool, message: str) -> None:
    if not value:
        raise ValueError(message)

def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()

def main() -> None:
    require(not DESTINATION.exists(), 'Preserve any prior exact cleanup packet')
    DESTINATION.mkdir()
    commands = []
    packet = {'schema_version': 'v3-root-authorized-exact-id-post-pair-cleanup-v1', 'status': 'unverified', 'started_at': datetime.now(UTC).isoformat(), 'authorization': 'Root explicitly authorized exact synthetic full ID cleanup after all six V4 runs, based on reviewed causal metadata reconstruction; no retained original response-ID seal.', 'exact_container_id': CID, 'causal_proof_sha256': sha(PROOF.read_bytes()), 'original_failed_report_sha256_before': sha(FAILURE.read_bytes()), 'original_v3_cleanup_status_rebound': False, 'commands': commands, 'stop_executed': False, 'foreign_stop_or_delete_executed': False, 'no_environment_credentials_or_sql_requested': True}
    deadline = time.monotonic() + 45

    def command(argv: list[str], timeout: float) -> subprocess.CompletedProcess:
        remaining = min(timeout, deadline-time.monotonic())
        require(remaining > 0, 'Bounded cleanup deadline exhausted')
        started = time.monotonic()
        row = {'argv': argv, 'started_at': datetime.now(UTC).isoformat()}
        commands.append(row)
        try:
            result = subprocess.run(argv, capture_output=True, timeout=remaining, check=False)
        except subprocess.TimeoutExpired:
            row.update(status='timeout', seconds=time.monotonic()-started)
            raise ValueError('Exact command timed out; cleanup not verified') from None
        row.update(returncode=result.returncode, seconds=time.monotonic()-started, stdout_sha256=sha(result.stdout), stdout_bytes=len(result.stdout), stderr_sha256=sha(result.stderr), stderr_bytes=len(result.stderr))
        return result

    def ids() -> list[str]:
        result = command(['docker','container','ls','--all','--no-trunc','--format','{{.ID}}'],5)
        require(result.returncode == 0 and result.stderr == b'', 'Safe ID inventory failed')
        values = result.stdout.decode().split()
        require(len(set(values)) == len(values) and all(re.fullmatch('[0-9a-f]{64}',value) for value in values), 'Ambiguous Docker ID inventory')
        return sorted(values)

    try:
        require(packet['causal_proof_sha256'] == 'fa42edafe7b58b14b7e275c5fa5156f771840ccb5fd23c02df46aae75240c3a1', 'Approved original causal packet changed')
        require(packet['original_failed_report_sha256_before'] == '5d08a7107cae6aeec2653fe0f40b1fd07203c44b36ab21a8f5b8057f45917201', 'Original failed report changed')
        original = json.loads(PROOF.read_bytes())
        expected = original['safe_exact_id_inspection']
        require(original['exact_container_id'] == CID and expected['Created'] == '2026-10-12T07:17:30.750015611Z' and expected['Name'] == '/reconforge-enterprise-finance-aada0b7c3783', 'Approved immutable identity differs')
        before_ids = ids()
        require(CID in before_ids, 'Target absent before fresh identity verification')
        packet['all_container_ids_before'] = before_ids
        template = '\t'.join(['{{json .Id}}','{{json .Name}}','{{json .Created}}','{{json .Config.Image}}','{{json .Image}}','{{json (index .Config.Labels "reconforge.owner")}}','{{json .Config.Cmd}}','{{json .Config.Entrypoint}}','{{json .HostConfig.AutoRemove}}','{{json .HostConfig.PortBindings}}','{{json .HostConfig.RestartPolicy.Name}}','{{json .State.Running}}','{{json .RestartCount}}'])
        result = command(['docker','container','inspect','--format',template,CID],5)
        require(result.returncode == 0 and result.stderr == b'', 'Fresh exact-ID inspection failed')
        values = [json.loads(value) for value in result.stdout.decode().strip().split('\t')]
        keys = ('Id','Name','Created','Config.Image','Image.ConfigDigest','OwnerLabel','Config.Cmd','Config.Entrypoint','AutoRemove','PortBindings','RestartPolicy','Running','RestartCount')
        require(len(values) == len(keys), 'Exact-ID safe field population differs')
        observed = dict(zip(keys,values,strict=True))
        require(observed == expected, 'Fresh immutable configuration/state differs from approved causal proof; refuse stop')
        packet['safe_before_exact_id_inspection'] = observed
        packet['fresh_before_inspection_exact_match'] = True
        with (DESTINATION/'safe-before-exact-id-inspection.raw').open('xb') as stream:
            stream.write(result.stdout)
        stop_argv = ['docker','container','stop','--time','10',CID]
        packet['stop_executed'] = True
        result = command(stop_argv,15)
        require(result.returncode == 0 and result.stderr == b'' and result.stdout.decode().strip() == CID, 'Exact-ID stop was not successfully acknowledged')
        packet['stop_returned_exact_id'] = True
        with (DESTINATION/'exact-id-stop-safe.raw').open('xb') as stream:
            stream.write(result.stdout)
        absent = False
        absence_deadline = min(deadline,time.monotonic()+25)
        accepted = {f'Error response from daemon: No such container: {CID}',f'Error: No such container: {CID}'}
        packet['absence_error_exact_allowlist'] = sorted(accepted)
        while time.monotonic() < absence_deadline:
            result = command(['docker','container','inspect','--format','{{json .Id}}',CID],min(5,absence_deadline-time.monotonic()))
            if result.returncode == 0:
                require(result.stderr == b'' and json.loads(result.stdout) == CID, 'Presence probe identity ambiguous')
                time.sleep(min(.25,max(0,absence_deadline-time.monotonic())))
                continue
            require(result.returncode == 1 and result.stdout == b'' and result.stderr.decode().strip() in accepted, 'Daemon/permission/ambiguous inspect error; refuse absence claim')
            packet['strict_absence_returncode'] = result.returncode
            packet['strict_absence_safe_error'] = result.stderr.decode().strip()
            with (DESTINATION/'exact-id-absence-safe.raw').open('xb') as stream:
                stream.write(result.stderr)
            absent = True
            break
        require(absent, 'Exact target remains after bounded stop/removal polling')
        after_ids = ids()
        packet['all_container_ids_after'] = after_ids
        require(CID not in after_ids, 'Exact target remains in ID inventory')
        packet['foreign_container_ids_before'] = [value for value in before_ids if value != CID]
        packet['foreign_container_ids_after'] = after_ids
        packet['foreign_container_id_population_unchanged'] = packet['foreign_container_ids_before'] == after_ids
        packet['original_failed_report_sha256_after'] = sha(FAILURE.read_bytes())
        require(packet['original_failed_report_sha256_after'] == packet['original_failed_report_sha256_before'] and sha(PROOF.read_bytes()) == packet['causal_proof_sha256'], 'Original evidence changed during cleanup')
        packet['status'] = 'exact_target_stop_acknowledged_and_strict_absence_verified'
    except (Exception,KeyboardInterrupt) as error:
        packet['failure_type'] = type(error).__name__
        packet['failure'] = str(error) if isinstance(error,ValueError) else 'Unexpected failure; original raw identities and command hashes retained; no additional cleanup.'
    finally:
        packet['finished_at'] = datetime.now(UTC).isoformat()
        target = DESTINATION/'cleanup.json'
        with target.open('xb') as stream:
            stream.write((json.dumps(packet,indent=2)+'\n').encode())
        print(json.dumps({'status':packet['status'],'path':str(target),'sha256':sha(target.read_bytes()),'bytes':target.stat().st_size,'exact_container_id':CID,'stop_executed':packet['stop_executed'],'foreign_container_id_population_unchanged':packet.get('foreign_container_id_population_unchanged'),'original_v3_cleanup_status_rebound':False}))

if __name__ == '__main__':
    main()
