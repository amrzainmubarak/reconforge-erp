from __future__ import annotations

import hashlib
import json
import re
import subprocess
from datetime import datetime, timedelta
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('C:/Users/LOQ/.codex/worktrees/reconforge-integration-wave5/reconforge-erp')
FAILURE = ROOT / 'output/wave5-final22-paired-1k-v3/1-baseline/result.json'
PAIR = ROOT / 'output/wave5-final22-paired-1k-v3/pair.json'
IMAGE = 'postgres:17.11-alpine@sha256:aa90e97ee862e558111d34cfb8b2c4bec768c2b039fb791341686928560263b3'


def require(value: bool, message: str) -> None:
    if not value:
        raise ValueError(message)


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def run(argv: list[str]) -> bytes:
    result = subprocess.run(argv, capture_output=True, timeout=15, check=False)
    require(result.returncode == 0, 'Scoped read-only Docker request failed')
    return result.stdout


def fields(raw: bytes, names: tuple[str, ...]) -> dict:
    values = [json.loads(item) for item in raw.decode().strip().split('\t')]
    require(len(values) == len(names), 'Safe Docker field population differs')
    return dict(zip(names, values, strict=True))


def main() -> None:
    failure_raw = FAILURE.read_bytes()
    require(sha(failure_raw) == '5d08a7107cae6aeec2653fe0f40b1fd07203c44b36ab21a8f5b8057f45917201', 'Original failed report bytes differ')
    failure = json.loads(failure_raw)
    pair = json.loads(PAIR.read_bytes())
    started, finished = [datetime.fromisoformat(failure[key]) for key in ('started_at', 'finished_at')]
    narrow = finished - timedelta(seconds=failure['wall_seconds'])
    require(failure['status'] == pair['status'] == 'failed' and failure['image'] == IMAGE
            and 'posting' not in failure and 'revision' not in failure and 'migration' not in failure,
            'Failure is not the original pre-migration/pre-financial startup')
    command = ['docker', 'events', '--since', started.isoformat(), '--until', finished.isoformat(),
               '--filter', 'type=container', '--filter', 'event=create',
               '--filter', 'label=reconforge.owner=enterprise-finance-benchmark',
               '--format', '{{json .}}']
    events_raw = run(command)
    events = [json.loads(line) for line in events_raw.splitlines() if line.strip()]
    scoped = []
    for event in events:
        actor = event['Actor']
        attributes = actor['Attributes']
        name = attributes.get('name', '')
        require(event['Type'] == 'container' and event['Action'] == 'create'
                and attributes.get('reconforge.owner') == 'enterprise-finance-benchmark'
                and re.fullmatch(r'reconforge-enterprise-finance-[0-9a-f]{12}', name) is not None,
                'Create event differs from exact frozen harness contract')
        container = actor['ID']
        require(re.fullmatch(r'[0-9a-f]{64}', container) is not None, 'Daemon event lacks immutable full ID')
        timestamp = int(event['timeNano'])
        event_utc = datetime.fromtimestamp(timestamp / 1_000_000_000, tz=finished.tzinfo)
        scoped.append({'container_id': container, 'name': name, 'image': attributes['image'],
                       'owner_label': attributes['reconforge.owner'], 'create_time_nano': timestamp,
                       'create_utc': event_utc.isoformat(), 'within_original_report_window': started <= event_utc <= finished,
                       'within_derived_0_937_second_business_window': narrow <= event_utc <= finished})
    proof = {'schema_version': 'readonly-v3-startup-docker-causal-forensics-v1',
             'original_failure_report_sha256': sha(failure_raw), 'original_pair_sha256': sha(PAIR.read_bytes()),
             'original_report_started_at': failure['started_at'], 'original_report_finished_at': failure['finished_at'],
             'original_report_monotonic_wall_seconds': failure['wall_seconds'], 'derived_business_window_start': narrow.isoformat(),
             'event_command': command, 'complete_remote_event_output_sha256': sha(events_raw), 'complete_remote_event_output_bytes': len(events_raw),
             'matching_create_events': scoped, 'read_only': True, 'cleanup_or_stop_executed': False,
             'original_acknowledged_id_record_available': False,
             'causal_binding_policy': 'Unique original daemon CREATE in exact failed startup window plus immutable original harness image/name/label/command flags; no broad inventory, environment or credentials requested.',
             'status': 'unverified_unique_creation'}
    if len(scoped) == 1 and scoped[0]['within_original_report_window'] and scoped[0]['within_derived_0_937_second_business_window']:
        container = scoped[0]['container_id']
        template = '\t'.join(['{{json .Id}}', '{{json .Name}}', '{{json .Created}}', '{{json .Config.Image}}', '{{json .Image}}',
                               '{{json (index .Config.Labels "reconforge.owner")}}', '{{json .Config.Cmd}}', '{{json .Config.Entrypoint}}',
                               '{{json .HostConfig.AutoRemove}}', '{{json .HostConfig.PortBindings}}', '{{json .HostConfig.RestartPolicy.Name}}',
                               '{{json .State.Running}}', '{{json .RestartCount}}'])
        inspect_raw = run(['docker', 'container', 'inspect', '--format', template, container])
        inspected = fields(inspect_raw, ('Id', 'Name', 'Created', 'Config.Image', 'Image.ConfigDigest', 'OwnerLabel', 'Config.Cmd', 'Config.Entrypoint',
                                         'AutoRemove', 'PortBindings', 'RestartPolicy', 'Running', 'RestartCount'))
        image_raw = run(['docker', 'image', 'inspect', '--format', '{{json .Id}}\t{{json .RepoDigests}}\t{{json .Os}}\t{{json .Architecture}}', IMAGE])
        image = fields(image_raw, ('ConfigDigest', 'RepoDigests', 'Os', 'Architecture'))
        require(inspected['Id'] == container and inspected['Name'] == '/' + scoped[0]['name']
                and inspected['Config.Image'] == IMAGE and inspected['OwnerLabel'] == 'enterprise-finance-benchmark', 'Current exact-ID metadata differs')
        require(inspected['Image.ConfigDigest'] == image['ConfigDigest'] and image['Os'] == 'linux' and image['Architecture'] == 'amd64'
                and any(item.endswith('@sha256:aa90e97ee862e558111d34cfb8b2c4bec768c2b039fb791341686928560263b3') for item in image['RepoDigests']),
                'Current container is not the acknowledged pinned image configuration')
        require(inspected['Config.Cmd'] == ['-c', 'join_collapse_limit=8', '-c', 'from_collapse_limit=8']
                and inspected['Config.Entrypoint'] == ['docker-entrypoint.sh'] and inspected['AutoRemove'] is True
                and inspected['RestartPolicy'] == 'no' and inspected['RestartCount'] == 0, 'Code-defined exact startup flags differ')
        bindings = inspected['PortBindings']
        require(set(bindings) == {'5432/tcp'} and len(bindings['5432/tcp']) == 1
                and bindings['5432/tcp'][0]['HostIp'] == '127.0.0.1' and bindings['5432/tcp'][0]['HostPort'] == '',
                'Original loopback-only random-port creation flags differ')
        proof.update(status='unique_causal_creation_metadata_verified', exact_container_id=container,
                     safe_exact_id_inspection=inspected, safe_pinned_image_inspection=image,
                     exact_id_inspection_remote_sha256=sha(inspect_raw), image_inspection_remote_sha256=sha(image_raw),
                     conclusion='One exact daemon CREATE uniquely matches the single acknowledged startup operation and every frozen creation flag. No cleanup issued; root must review/authorize any exact-ID cleanup.')
    target = OUT / 'v3-orphan-readonly-causal-provenance-label-window-v2.json'
    require(not target.exists(), 'Prior forensic proof cannot be overwritten')
    target.write_bytes((json.dumps(proof, indent=2) + '\n').encode())
    print(json.dumps({'status': proof['status'], 'proof_sha256': sha(target.read_bytes()),
                      'matching_create_events': len(scoped), 'exact_container_id': proof.get('exact_container_id'),
                      'cleanup_or_stop_executed': False}))


if __name__ == '__main__':
    main()
