from __future__ import annotations

import hashlib
import json
import re
import subprocess
from datetime import UTC, datetime, timedelta
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('C:/Users/LOQ/.codex/worktrees/reconforge-integration-wave5/reconforge-erp')
OWNER = Path('C:/Users/LOQ/.codex/worktrees/reconforge-manufacturing-wave5/reconforge-erp/output/wave5-final22-pair-readiness-v3-20261012')
CID = 'a218046582c3e81dc3e61f2d7c800ae119ef7d541d4a8239956e0a7c18589a8c'
IMAGE = 'postgres:17.11-alpine@sha256:aa90e97ee862e558111d34cfb8b2c4bec768c2b039fb791341686928560263b3'

def require(value: bool, message: str) -> None:
    if not value:
        raise ValueError(message)

def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()

def run(argv: list[str]) -> bytes:
    result = subprocess.run(argv, capture_output=True, timeout=10, check=False)
    require(result.returncode == 0, 'Scoped read-only Docker request failed')
    return result.stdout

def fields(raw: bytes, names: tuple[str, ...]) -> dict:
    values = [json.loads(item) for item in raw.decode().strip().split('\t')]
    require(len(values) == len(names), 'Safe Docker field population differs')
    return dict(zip(names, values, strict=True))

def main() -> None:
    failure_path = ROOT / 'output/wave5-final22-paired-1k-v3/1-baseline/result.json'
    failure_raw = failure_path.read_bytes()
    require(sha(failure_raw) == '5d08a7107cae6aeec2653fe0f40b1fd07203c44b36ab21a8f5b8057f45917201', 'Original failed report changed')
    failure = json.loads(failure_raw)
    started, finished = [datetime.fromisoformat(failure[key]) for key in ('started_at', 'finished_at')]
    narrow = finished - timedelta(seconds=failure['wall_seconds'])
    wrapper_raw = (OWNER / 'owned_child.py').read_bytes()
    harness_raw = (ROOT / '.github/scripts/benchmark_enterprise_finance.py').read_bytes()
    require(sha(wrapper_raw) == '3a59d5ec4a380c84655e1e0cdc2d756f5c6b6ec5053d955f5092f1efbf085b2c', 'Original V3 wrapper changed')
    require(sha(harness_raw) == '7bce2382df24d439d39386f0e02c07bf362c4f451649dbd8d7f225c8a920396b', 'Common frozen harness changed')
    require(failure['status'] == 'failed' and 'posting' not in failure and 'revision' not in failure and 'migration' not in failure, 'Original failure stage differs')
    wrapper = wrapper_raw.decode().replace('\r\n', '\n')
    require(wrapper.index('result = original_run(*values, **options)') < wrapper.index('require(result.returncode == 0') < wrapper.index('"Docker creation response ID absent or malformed"') < wrapper.index('ownership.read_bytes()'), 'Original success-before-missing-file code flow differs')
    ls_command = ['docker', 'container', 'ls', '--all', '--no-trunc', '--filter', 'label=reconforge.owner=enterprise-finance-benchmark', '--format', '{{json .ID}}\t{{json .Names}}\t{{json .Image}}\t{{json .CreatedAt}}']
    inventory_raw = run(ls_command)
    inventory = [fields(line, ('Id', 'Name', 'Image', 'CreatedAt')) for line in inventory_raw.splitlines() if line.strip()]
    historical_candidates = []
    for row in inventory:
        coarse_created = datetime.strptime(row['CreatedAt'].rsplit(' ', 1)[0], '%Y-%m-%d %H:%M:%S %z')
        if row['Image'] == IMAGE and re.fullmatch(r'reconforge-enterprise-finance-[0-9a-f]{12}', row['Name']) and started <= coarse_created <= finished:
            historical_candidates.append(row)
    require(len(historical_candidates) == 1 and historical_candidates[0]['Id'] == CID, 'Original failed-window creation is not unique in the exact owner-label inventory')
    candidates = historical_candidates
    template = '\t'.join(['{{json .Id}}', '{{json .Name}}', '{{json .Created}}', '{{json .Config.Image}}', '{{json .Image}}', '{{json (index .Config.Labels "reconforge.owner")}}', '{{json .Config.Cmd}}', '{{json .Config.Entrypoint}}', '{{json .HostConfig.AutoRemove}}', '{{json .HostConfig.PortBindings}}', '{{json .HostConfig.RestartPolicy.Name}}', '{{json .State.Running}}', '{{json .RestartCount}}'])
    inspect_raw = run(['docker', 'container', 'inspect', '--format', template, CID])
    inspected = fields(inspect_raw, ('Id', 'Name', 'Created', 'Config.Image', 'Image.ConfigDigest', 'OwnerLabel', 'Config.Cmd', 'Config.Entrypoint', 'AutoRemove', 'PortBindings', 'RestartPolicy', 'Running', 'RestartCount'))
    created = datetime.fromisoformat(inspected['Created'])
    image_raw = run(['docker', 'image', 'inspect', '--format', '{{json .Id}}\t{{json .RepoDigests}}\t{{json .Os}}\t{{json .Architecture}}', IMAGE])
    image = fields(image_raw, ('ConfigDigest', 'RepoDigests', 'Os', 'Architecture'))
    require(inspected['Id'] == CID and inspected['Name'] == '/' + candidates[0]['Name'] and inspected['Config.Image'] == IMAGE and inspected['OwnerLabel'] == 'enterprise-finance-benchmark', 'Exact immutable metadata differs')
    require(started <= created <= finished and narrow <= created <= finished, 'Created is outside original failed startup windows')
    require(inspected['Image.ConfigDigest'] == image['ConfigDigest'] and image['Os'] == 'linux' and image['Architecture'] == 'amd64' and any(value.endswith('@sha256:aa90e97ee862e558111d34cfb8b2c4bec768c2b039fb791341686928560263b3') for value in image['RepoDigests']), 'Pinned immutable image configuration differs')
    require(inspected['Config.Cmd'] == ['-c', 'join_collapse_limit=8', '-c', 'from_collapse_limit=8'] and inspected['Config.Entrypoint'] == ['docker-entrypoint.sh'] and inspected['AutoRemove'] is True and inspected['RestartPolicy'] == 'no' and inspected['RestartCount'] == 0, 'Exact code-defined flags differ')
    require(inspected['PortBindings'] == {'5432/tcp': [{'HostIp': '127.0.0.1', 'HostPort': ''}]}, 'Exact loopback random-port configuration differs')
    negative_records = []
    for name in ('v3-orphan-readonly-causal-provenance.json', 'v3-orphan-readonly-causal-provenance-label-window-v2.json'):
        raw = (OUT / name).read_bytes()
        negative = json.loads(raw)
        require(negative['matching_create_events'] == [] and negative['cleanup_or_stop_executed'] is False, 'Original negative event capture differs')
        negative_records.append({'path': name, 'sha256': sha(raw), 'bytes': len(raw), 'matching_create_events': 0})
    proof = {'schema_version': 'readonly-v3-startup-current-inventory-causal-forensics-v1', 'status': 'unique_current_immutable_creation_metadata_verified', 'captured_at': datetime.now(UTC).isoformat(), 'original_report_sha256': sha(failure_raw), 'original_started_at': failure['started_at'], 'original_finished_at': failure['finished_at'], 'monotonic_wall_seconds': failure['wall_seconds'], 'derived_business_window_start': narrow.isoformat(), 'original_wrapper_sha256': sha(wrapper_raw), 'common_harness_sha256': sha(harness_raw), 'current_scoped_owner_inventory': inventory, 'unique_original_window_inventory_match': historical_candidates, 'inventory_command': ls_command, 'inventory_raw_sha256': sha(inventory_raw), 'inventory_raw_bytes': len(inventory_raw), 'exact_container_id': CID, 'safe_exact_id_inspection': inspected, 'exact_id_inspection_raw_sha256': sha(inspect_raw), 'exact_id_inspection_raw_bytes': len(inspect_raw), 'safe_pinned_image_inspection': image, 'image_inspection_raw_sha256': sha(image_raw), 'image_inspection_raw_bytes': len(image_raw), 'created_within_original_report_window': True, 'created_within_derived_business_window': True, 'original_code_success_before_missing_ownership_read': True, 'native_create_event_capture_available': False, 'negative_create_event_captures': negative_records, 'original_stdout_id_value_retained': False, 'no_environment_or_credentials_requested': True, 'read_only': True, 'cleanup_or_stop_executed': False, 'conclusion': 'One currently retained immutable Docker creation uniquely matches the single successful acknowledged startup operation, original tight time windows, pinned image, owner label, name form and all safe code-defined creation flags. Original response ID bytes and historical CREATE event are unavailable; this is a causal metadata reconstruction, not a retained response-ID seal. No cleanup issued; root must review the exact ID before any task-owned cleanup.'}
    path = OUT / 'v3-orphan-readonly-current-inventory-proof-v3.json'
    require(not path.exists(), 'Prior forensic packet cannot be overwritten')
    path.write_bytes((json.dumps(proof, indent=2) + '\n').encode())
    for name, raw in (('v3-orphan-current-label-inventory-safe.raw', inventory_raw), ('v3-orphan-exact-id-safe.raw', inspect_raw), ('v3-orphan-pinned-image-safe.raw', image_raw)):
        with (OUT / name).open('xb') as stream:
            stream.write(raw)
    print(json.dumps({'status': proof['status'], 'proof_sha256': sha(path.read_bytes()), 'proof_bytes': path.stat().st_size, 'exact_container_id': CID, 'created': inspected['Created'], 'running': inspected['Running'], 'cleanup_or_stop_executed': False}))

if __name__ == '__main__':
    main()
