from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

HERE = Path('C:/Users/LOQ/.codex/worktrees/reconforge-manufacturing-wave5/reconforge-erp/output/wave5-final22-pair-readiness-20261012')
EXPECTED = [('final22_pair.py', '91d788524f84d6e8f45fcd2777972d216eaf6d1cfd5fe36283f0d04744154f47'),
            ('owned_child.py', 'bd1aedf805a95d24fb2508e4ad7b8652bcc40d8bc37687c25338f5103f8423b7'),
            ('native_observations.py', 'a446fceb8bdb1ac7b58db8319fb5bbe01c62e38f309fc995356f7b450630160d'),
            ('readiness-v2.json', '345935eb3033978c869af71f1af23fe0c41fd0206ee8e012c254b492f602893b')]
for name, expected in EXPECTED:
    if hashlib.sha256((HERE / name).read_bytes()).hexdigest() != expected:
        raise ValueError('Frozen review source changed: ' + name)
sys.path.insert(0, str(HERE))
spec = importlib.util.spec_from_file_location('independent_final22_controller', HERE / 'final22_pair.py')
assert spec and spec.loader
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)


def fixture(directory: str):
    identity = {'pid': 12345, 'birth': 123456789, 'executable': str(c.PYTHON.resolve()), 'method': 'offline-only'}
    audit = {'schema_version': 'audited-final22-owned-container-v1', 'process': identity,
             'name': 'reconforge-enterprise-finance-123456abcdef', 'image': c.IMAGE,
             'label': 'reconforge.owner=enterprise-finance-benchmark', 'pre_spawn_exact_name_absent': True,
             'observed_at': '2026-10-12T06:00:00+00:00'}
    owned = Path(directory) / 'ownership.json'
    owned.write_text(json.dumps(audit), encoding='utf-8')
    created = {'schema_version': 'final22-docker-creation-response-v1', 'process': identity,
               'audit_sha256': c.sha(owned), 'container_id': 'a' * 64, 'returncode': 0}
    owned.with_suffix('.created.json').write_text(json.dumps(created), encoding='utf-8')
    inspected = {'Id': 'a' * 64, 'Name': '/' + audit['name'], 'Config': {'Image': c.IMAGE,
                 'Labels': {'reconforge.owner': 'enterprise-finance-benchmark'}},
                 'Created': '2026-10-12T06:00:01+00:00'}
    return owned, identity, audit, created, inspected


def inspection_bytes(value: dict) -> bytes:
    return ('\t'.join(json.dumps(value[key]) for key in ('Id', 'Name')) + '\t'
            + json.dumps(value['Config']['Image']) + '\t' + json.dumps(value['Config']['Labels'])
            + '\t' + json.dumps(value['Created']) + '\n').encode()


class PeerChecks(unittest.TestCase):
    def test_successful_fullid_binding_is_the_acknowledged_id(self):
        with tempfile.TemporaryDirectory() as directory:
            owned, identity, _audit, _created, inspected = fixture(directory)
            with patch.object(c.subprocess, 'run', return_value=SimpleNamespace(returncode=0, stdout=inspection_bytes(inspected))):
                bound = c.inspect_owned(owned, identity)
            self.assertEqual(bound['inspection']['Id'], 'a' * 64)
            self.assertEqual(bound['creation_response']['container_id'], 'a' * 64)

    def test_same_name_replacement_never_binds_or_deletes(self):
        with tempfile.TemporaryDirectory() as directory:
            owned, identity, _audit, _created, inspected = fixture(directory)
            inspected['Id'] = 'b' * 64
            with patch.object(c.subprocess, 'run', return_value=SimpleNamespace(returncode=0, stdout=inspection_bytes(inspected))) as calls:
                with self.assertRaisesRegex(ValueError, 'acknowledged'):
                    c.cleanup_container(None, owned, identity, aborted=True)
            self.assertEqual(len(calls.call_args_list), 1)
            self.assertEqual(calls.call_args.args[0][1], 'inspect')

    def test_preexisting_created_time_refuses(self):
        with tempfile.TemporaryDirectory() as directory:
            owned, identity, _audit, _created, inspected = fixture(directory)
            inspected['Created'] = '2026-10-12T05:59:59+00:00'
            with patch.object(c.subprocess, 'run', return_value=SimpleNamespace(returncode=0, stdout=inspection_bytes(inspected))) as calls:
                with self.assertRaisesRegex(ValueError, 'predates'):
                    c.inspect_owned(owned, identity)
            self.assertEqual(len(calls.call_args_list), 1)

    def test_daemon_error_is_not_absence_and_never_deletes(self):
        with tempfile.TemporaryDirectory() as directory:
            owned, identity, _audit, _created, _inspected = fixture(directory)
            with patch.object(c.subprocess, 'run', return_value=SimpleNamespace(returncode=125, stdout=b'')) as calls:
                with self.assertRaisesRegex(ValueError, 'unverified'):
                    c.cleanup_container(None, owned, identity, aborted=True)
            self.assertEqual(len(calls.call_args_list), 1)
            self.assertEqual(calls.call_args.args[0][1], 'inspect')

    def test_missing_creation_response_never_probes_or_deletes(self):
        with tempfile.TemporaryDirectory() as directory:
            owned, identity, _audit, _created, _inspected = fixture(directory)
            owned.with_suffix('.created.json').unlink()
            with patch.object(c.subprocess, 'run') as calls:
                with self.assertRaisesRegex(ValueError, 'unverified'):
                    c.cleanup_container(None, owned, identity, aborted=True)
            calls.assert_not_called()

    def test_expired_cleanup_budget_never_issues_command(self):
        with tempfile.TemporaryDirectory() as directory:
            owned, identity, audit, created, inspected = fixture(directory)
            bound = {'audit': audit, 'audit_sha256': c.sha(owned), 'inspection': inspected,
                     'creation_response': created, 'creation_response_sha256': c.sha(owned.with_suffix('.created.json'))}
            with patch.object(c.time, 'monotonic', return_value=7201), patch.object(c.subprocess, 'run') as calls:
                with self.assertRaisesRegex(ValueError, 'budget'):
                    c.cleanup_container(bound, owned, identity, aborted=True, deadline=7200)
            calls.assert_not_called()

    def test_still_present_after_exact_remove_never_reports_absence(self):
        with tempfile.TemporaryDirectory() as directory:
            owned, identity, audit, created, inspected = fixture(directory)
            bound = {'audit': audit, 'audit_sha256': c.sha(owned), 'inspection': inspected,
                     'creation_response': created, 'creation_response_sha256': c.sha(owned.with_suffix('.created.json'))}
            replies = [SimpleNamespace(returncode=0, stdout=('a' * 64 + '\n').encode()),
                       SimpleNamespace(returncode=0, stdout=b''),
                       SimpleNamespace(returncode=0, stdout=('a' * 64 + '\n').encode())]
            with patch.object(c.subprocess, 'run', side_effect=replies) as calls:
                with self.assertRaisesRegex(ValueError, 'remains'):
                    c.cleanup_container(bound, owned, identity, aborted=True)
            self.assertEqual(calls.call_args_list[1].args[0], ['docker', 'rm', '--force', 'a' * 64])


if __name__ == '__main__':
    unittest.main(verbosity=2)
