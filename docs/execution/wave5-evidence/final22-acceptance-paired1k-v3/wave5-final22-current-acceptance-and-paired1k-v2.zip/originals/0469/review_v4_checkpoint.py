from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

OUT = Path(__file__).resolve().parent
V4 = Path('C:/Users/LOQ/.codex/worktrees/reconforge-manufacturing-wave5/reconforge-erp/output/wave5-final22-pair-readiness-v4-20261012')

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main() -> None:
    readiness = V4 / 'readiness-v4.json'
    assert sha(readiness) == '7bdd6ee3da407966e2377b3757610e75f3dfea07d984a2284baa92d340405473'
    plan = json.loads(readiness.read_bytes())
    assert all(sha(V4 / name) == value for name, value in plan['tool_sha256'].items())
    assert plan['sources'] == plan['sources_after']
    smoke_path = V4 / 'actual-docker-smoke-1/smoke.json'
    assert sha(smoke_path) == '683eb823aaa5193b8dbc8f25773c735a4fa7c73742d7dd79c92191a562326512'
    smoke = json.loads(smoke_path.read_bytes())
    owned = smoke_path.parent / 'sleep-only-ownership.json'
    created = owned.with_suffix('.created.json')
    crosscheck = owned.with_suffix('.audit-crosscheck.json')
    assert sha(owned) == smoke['audited_binding']['audit_sha256']
    assert sha(created) == smoke['audited_binding']['creation_response_sha256']
    assert sha(crosscheck) == smoke['audited_binding']['native_audit_crosscheck_sha256']
    native = json.loads(crosscheck.read_bytes())
    intent = json.loads(owned.read_bytes())
    response = json.loads(created.read_bytes())
    assert native['status'] == 'matched' and native['audit_argument_form'] == 'str'
    assert native['original_typed_command_sha256'] == intent['command_sha256']
    assert native['process'] == intent['process'] == response['process'] == smoke['process']
    assert response['audit_sha256'] == sha(owned)
    assert smoke['container_cleanup']['status'] == 'verified_absent'
    assert response['container_id'] == smoke['container_cleanup']['container_id'] == 'e3d2e8e8a14d1e54112641310ee9ba52cfd6b51b5c45e4705271686815881ea4'
    assert smoke['no_database_or_financial_commands'] is True and smoke['source_before'] == smoke['source_after']
    probe_records = []
    for variant, probe in plan['actual_physical_interpreter_probes'].items():
        path = Path(probe['report'])
        assert sha(path) == probe['report_sha256']
        observed = json.loads(path.read_bytes())
        assert observed == probe['virtual_context'] and observed['status'] == 'passed'
        assert observed['actual_job_membership'] is True and observed['pid'] == probe['process']['pid']
        assert observed['process'] == probe['process'] and observed['no_docker_or_database_work'] is True
        probe_records.append({'variant': variant, 'path': str(path), 'sha256': sha(path), 'pid': observed['pid'], 'actual_job_membership': True})
    records = [{'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size} for path in (readiness, smoke_path, owned, created, crosscheck, V4 / 'offline-tests-v4-frozen.log', V4 / 'ruff-v4-frozen.log')]
    packet = {'schema_version': 'final22-v4-controller-readonly-peer-review-v1', 'status': 'no_remaining_critical_blocker', 'reviewed_at': datetime.now(UTC).isoformat(), 'readiness_sha256': sha(readiness), 'tool_sha256': plan['tool_sha256'], 'sources_before_after_exact': plan['sources'], 'actual_smoke_original_sha256': sha(smoke_path), 'actual_smoke_id': response['container_id'], 'actual_smoke_cleanup_status': smoke['container_cleanup']['status'], 'actual_windows_audit_argument_form': native['audit_argument_form'], 'physical_venv_job_probe_records': probe_records, 'owner_targeted_test_log': {'tests': 15, 'seconds': 0.276, 'status': 'passed', 'reviewer_reran_tests': False}, 'record_list': records, 'reviewed_code_contracts': ['Original typed argv/name-absence custody before subprocess execution; literal Windows audit string equality to list2cmdline with no command-string parsing.', 'Successful returned immutable64hex CID separately sealed to intent and original PID/birth/executable; same-name replacements refused.', 'Direct physical CPython process with intended venv and retained kill-on-close Job assignment before child subprocess admission.', 'Full source roots, common final22 harness and original stdlib financial oracle bindings retained.', 'Bounded remaining deadlines and120s cleanup reserve; cleanup requires exact audited immutable ID; successful harness residual resource refuses acceptance.', 'Primary child failure preserved separately from cleanup failure; no complete-population acceptance after a failed child.'], 'reviewer_executed_docker_or_database_or_financial_workload': False, 'performance_comparison_accepted': False, 'limits': ['Actual smoke validates one Windows Docker creation/ownership/cleanup path only; it is not financial or benchmark acceptance.', 'Original V2/V3 and both actual failure packets remain separate and unchanged.', 'V3 orphan reconstruction is independently recorded; no cleanup issued during timed V4 posting.']}
    target = OUT / 'v4-readonly-peer-review.json'
    with target.open('xb') as stream:
        stream.write((json.dumps(packet, indent=2) + '\n').encode())
    print(json.dumps({'status': packet['status'], 'path': str(target), 'sha256': sha(target), 'bytes': target.stat().st_size}))

if __name__ == '__main__':
    main()
