from __future__ import annotations

import hashlib
import json
import re
import subprocess
import time
from datetime import UTC,datetime
from pathlib import Path

OUT=Path(__file__).resolve().parent
OLD=OUT/'v3-exact-cleanup-after-six-runs-v1/cleanup.json'
NEW=OUT/'v3-exact-cleanup-after-six-runs-readonly-closure-v2'
CID='a218046582c3e81dc3e61f2d7c800ae119ef7d541d4a8239956e0a7c18589a8c'
FAILURE=Path('C:/Users/LOQ/.codex/worktrees/reconforge-integration-wave5/reconforge-erp/output/wave5-final22-paired-1k-v3/1-baseline/result.json')

def require(value:bool,message:str)->None:
    if not value:raise ValueError(message)

def sha(raw:bytes)->str:return hashlib.sha256(raw).hexdigest()

def main()->None:
    require(not NEW.exists(),'Preserve all original cleanup packets')
    NEW.mkdir()
    old_raw=OLD.read_bytes()
    require(sha(old_raw)=='98f9a6af28c4186ee478675fe775ee1661788918b4b8013630cb4430bbccb2b3','Original first-capture cleanup differs')
    old=json.loads(old_raw)
    stop=old['commands'][-1]
    response=('Flag --time has been deprecated, use --timeout instead\n'+CID+'\n').encode()
    require(old['fresh_before_inspection_exact_match'] is True and old['stop_executed'] is True and stop['argv']==['docker','container','stop','--time','10',CID] and stop['returncode']==0 and stop['stderr_bytes']==0 and stop['stdout_sha256']==sha(response) and stop['stdout_bytes']==len(response),'Original exact-ID stop acknowledgment cannot be proven')
    with (NEW/'reconstructed-stop-response-hash-matched.raw').open('xb') as stream:stream.write(response)
    packet={'schema_version':'v3-post-pair-exact-cleanup-readonly-closure-v2','status':'unverified','started_at':datetime.now(UTC).isoformat(),'original_first_capture_cleanup_sha256':sha(old_raw),'original_first_capture_status_preserved':old['status'],'original_causal_proof_sha256':old['causal_proof_sha256'],'exact_container_id':CID,'fresh_before_inspection_referenced_from_original_packet':True,'stop_executed_by_this_continuation':False,'original_stop_acknowledgment':{'returncode':0,'duration_seconds':stop['seconds'],'stdout_sha256':sha(response),'stdout_bytes':len(response),'reconstruction_method':'Exact public deprecation notice LF plus authorized full container ID LF reconstructs120 original stdout bytes and matches captured SHA256; this file is a reconstruction, not a falsely relabeled original byte capture.','known_notice':'Flag --time has been deprecated, use --timeout instead','id_line':CID},'no_foreign_stop_or_delete':True,'original_startup_response_id_seal_created':False,'original_v3_cleanup_status_rebound':False,'commands':[]}
    deadline=time.monotonic()+25
    def command(argv:list[str])->subprocess.CompletedProcess:
        remaining=min(5,deadline-time.monotonic())
        require(remaining>0,'Bounded read-only deadline exhausted')
        result=subprocess.run(argv,capture_output=True,timeout=remaining,check=False)
        packet['commands'].append({'argv':argv,'returncode':result.returncode,'stdout_sha256':sha(result.stdout),'stdout_bytes':len(result.stdout),'stderr_sha256':sha(result.stderr),'stderr_bytes':len(result.stderr)})
        return result
    try:
        accepted={f'Error response from daemon: No such container: {CID}',f'Error: No such container: {CID}'}
        absent=False
        while time.monotonic()<deadline:
            result=command(['docker','container','inspect','--format','{{json .Id}}',CID])
            if result.returncode==0:
                require(result.stderr==b'' and json.loads(result.stdout)==CID,'Presence probe identity ambiguous')
                time.sleep(min(.25,max(0,deadline-time.monotonic())))
                continue
            require(result.returncode==1 and result.stdout==b'' and result.stderr.decode().strip() in accepted,'Non-absence daemon/permission/error result refuses closure')
            packet['strict_absence_safe_error']=result.stderr.decode().strip()
            with (NEW/'strict-exact-id-absence-original-safe.raw').open('xb') as stream:stream.write(result.stderr)
            absent=True
            break
        require(absent,'Exact target remains; no more stop/delete allowed')
        result=command(['docker','container','ls','--all','--no-trunc','--format','{{.ID}}'])
        require(result.returncode==0 and result.stderr==b'','Safe ID-only after inventory failed')
        after=sorted(result.stdout.decode().split())
        require(len(after)==len(set(after)) and all(re.fullmatch('[0-9a-f]{64}',value) for value in after),'After inventory is ambiguous')
        require(CID not in after,'Target is still present in after inventory')
        before=[value for value in old['all_container_ids_before'] if value!=CID]
        packet['foreign_container_ids_before']=before
        packet['foreign_container_ids_after']=after
        packet['foreign_container_id_population_unchanged']=before==after
        with (NEW/'after-container-ids-only-original-safe.raw').open('xb') as stream:stream.write(result.stdout)
        packet['original_failed_report_sha256_after']=sha(FAILURE.read_bytes())
        require(packet['original_failed_report_sha256_after']==old['original_failed_report_sha256_before'] and sha(OLD.read_bytes())==sha(old_raw),'Original historical evidence changed')
        packet['status']='exact_target_stop_acknowledgment_and_strict_absence_verified'
    except Exception as error:
        packet['failure_type']=type(error).__name__
        packet['failure']=str(error) if isinstance(error,ValueError) else 'Unexpected read-only failure; no additional cleanup executed'
    finally:
        packet['finished_at']=datetime.now(UTC).isoformat()
        target=NEW/'closure.json'
        with target.open('xb') as stream:stream.write((json.dumps(packet,indent=2)+'\n').encode())
        print(json.dumps({'status':packet['status'],'path':str(target),'sha256':sha(target.read_bytes()),'bytes':target.stat().st_size,'foreign_ids_unchanged':packet.get('foreign_container_id_population_unchanged'),'foreign_container_count':len(packet.get('foreign_container_ids_after',[])),'additional_stop_or_delete_executed':False}))

if __name__=='__main__':main()
