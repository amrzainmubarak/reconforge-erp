from __future__ import annotations

import hashlib
import importlib
import json
import os
import subprocess
import sys
from pathlib import Path

OUT = Path(__file__).resolve().parent
HELPER = Path('C:/Users/LOQ/.codex/worktrees/reconforge-manufacturing-wave5/reconforge-erp/output/wave5-final22-pair-readiness-20261012')
VENV = Path('F:/reconforge-erp/.venv-baseline-20261008/Scripts/python.exe').resolve()
PREFIX = VENV.parents[1]
ROOTS = [('baseline', Path('C:/Users/LOQ/.codex/worktrees/reconforge-integration-wave4/reconforge-erp')),
         ('candidate', Path('C:/Users/LOQ/.codex/worktrees/reconforge-integration-wave5/reconforge-erp'))]
sys.path.insert(0, str(HELPER))
from native_observations import OwnedJob, process_identity


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def digest(path: Path) -> str:
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def child(root: Path) -> int:
    def no_processes(event: str, args: object) -> None:
        if event == 'subprocess.Popen':
            raise ValueError('No child subprocess/Docker launch is admitted by this probe')
    sys.addaudithook(no_processes)
    identity = process_identity(os.getpid())
    initial = {'worker_pid': os.getpid(), 'identity': identity, 'sys_executable': str(Path(sys.executable).resolve()),
               'sys_base_executable': str(Path(sys._base_executable).resolve()),
               'sys_prefix': str(Path(sys.prefix).resolve()), 'sys_base_prefix': str(Path(sys.base_prefix).resolve())}
    print(json.dumps(initial), flush=True)
    require(sys.stdin.read(1) == 'G', 'Parent Job admission missing')
    if Path(sys.prefix).resolve() != PREFIX or Path(sys.executable).resolve() != VENV:
        print(json.dumps({'status': 'refused_venv_context_before_modules', 'initial': initial}), flush=True)
        return 3
    sys.path.insert(0, str(root.resolve()))
    required = ['reconforge.infrastructure.postgres_finance_core', 'reconforge.infrastructure.postgres_finance_posting',
                'reconforge.benchmark.resource_sampling', 'tests.erp_expansion_browser_seed']
    origins = []
    for name in required:
        origin = Path(importlib.import_module(name).__file__).resolve()
        require(origin.is_relative_to(root.resolve()), 'Mixed source origin in direct base probe')
        origins.append({'module': name, 'path': str(origin)})
    foreign = []
    for name, module in sys.modules.items():
        if name == 'reconforge' or name.startswith(('reconforge.', 'tests.')):
            filename = getattr(module, '__file__', None)
            if filename and not Path(filename).resolve().is_relative_to(root.resolve()):
                foreign.append(name)
    require(not foreign, 'Imported primary or foreign source module')
    dependency = Path(importlib.import_module('psycopg').__file__).resolve()
    require(dependency.is_relative_to(PREFIX), 'Venv dependency origin differs')
    print(json.dumps({'status': 'passed', 'initial': initial, 'runtime_root': str(root.resolve()),
                      'source_module_origins': origins, 'foreign_source_modules': foreign,
                      'dependency_psycopg_origin': str(dependency), 'no_subprocess_allowed': True,
                      'financial_or_database_calls': 0}), flush=True)
    return 0


def probe(base: Path, variant: str, root: Path, *, preserve_venv: bool) -> dict:
    environment = os.environ.copy()
    environment.pop('PYTHONHOME', None)
    environment.pop('__PYVENV_LAUNCHER__', None)
    if preserve_venv:
        environment['__PYVENV_LAUNCHER__'] = str(VENV)
    process = subprocess.Popen([str(base), '-I', str(Path(__file__).resolve()), '--child', str(root.resolve())],
                               cwd=root, env=environment, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, text=True, creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)
    job = None
    try:
        initial = json.loads(process.stdout.readline())
        parent_identity = process_identity(process.pid)
        require(initial['worker_pid'] == process.pid, 'Redirector PID mismatch remains')
        require(initial['identity'] == parent_identity, 'Actual worker birth/path differs from retained Popen process')
        require(Path(parent_identity['executable']).resolve() == base, 'Actual physical executable differs')
        job = OwnedJob(process)
        # No child subprocess or repository import is admitted until exact
        # physical worker handle is assigned to the retained Windows Job.
        process.stdin.write('G')
        process.stdin.flush()
        tail, diagnostic = process.communicate(timeout=30)
        require(not diagnostic, 'Probe produced an unexpected diagnostic; no raw content is printed')
        result = json.loads(tail)
        require(process.returncode == (0 if preserve_venv else 3), 'Unexpected probe result')
        require(result['status'] == ('passed' if preserve_venv else 'refused_venv_context_before_modules'), 'Venv admission result differs')
        return {'variant': variant, 'preserve_venv': preserve_venv, 'actual_popen_pid': process.pid,
                'actual_worker_pid': initial['worker_pid'], 'actual_identity': parent_identity,
                'retained_job_assigned_before_admission': True, 'exit_code': process.returncode,
                'result': result, 'environment_captured': False, 'docker_or_database_calls': 0}
    finally:
        if job is not None:
            job.close()
        elif process.poll() is None:
            process.kill()  # Retained exact Popen handle; probe never admitted any child subprocess.
        process.wait(timeout=5)


def main() -> int:
    base = Path(sys._base_executable).resolve()
    require(base != VENV and base.is_file(), 'Physical CPython executable not independently resolved')
    rows = [probe(base, variant, root, preserve_venv=True) for variant, root in ROOTS]
    rows.append(probe(base, 'negative_without_venv_launcher', ROOTS[1][1], preserve_venv=False))
    packet = {'schema_version': 'independent-windows-direct-base-venv-job-probe-v1',
              'status': 'passed', 'physical_python_path': str(base), 'physical_python_sha256': digest(base),
              'venv_python_path': str(VENV), 'venv_python_sha256': digest(VENV),
              'intended_venv_prefix': str(PREFIX), 'probe_script_sha256': digest(Path(__file__)),
              'native_helper_original_v2_sha256': digest(HELPER / 'native_observations.py'),
              'probes': rows, 'no_workload_launched': True, 'performance_acceptance': False,
              'limits': 'Actual Windows interpreter/PID/Job/source-origin probe only; separate V3 source review remains required.'}
    target = OUT / 'windows-direct-base-original-probe.json'
    require(not target.exists(), 'Prior real probe evidence cannot be overwritten')
    target.write_bytes((json.dumps(packet, indent=2) + '\n').encode())
    print(json.dumps({'status': 'passed', 'report_sha256': digest(target), 'physical_python_sha256': digest(base),
                      'actual_probes': len(rows), 'actual_worker_equals_popen': True,
                      'venv_source_contexts': 2, 'negative_wrong_venv_refused': True,
                      'docker_or_database_calls': 0}))
    return 0


if __name__ == '__main__':
    raise SystemExit(child(Path(sys.argv[2])) if len(sys.argv) == 3 and sys.argv[1] == '--child' else main())
