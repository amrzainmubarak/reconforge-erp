"""Exclusive bounded original cloud custody; no runtime/DB imports or retries."""
import argparse
from datetime import UTC, datetime
import hashlib
import importlib.util
import io
import json
from pathlib import Path, PurePosixPath
import stat
import subprocess
import zipfile

OWN=Path(__file__).resolve().parents[1]
OUT=OWN/'output/wave5-native10k-62c41c42-38252859442'
SOURCE='62c41c42d66924039c4fbdae6b260cc0d33996e7'
RUNTIME='22ebfd78e293aafa13d81b3a0bbf287491951115'
RUN=38252859442
REPO='repos/amrzainmubarak/reconforge-erp/'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def api(path):
    proc=subprocess.run(['gh','api',REPO+path],capture_output=True,timeout=60,check=False)
    if proc.returncode or len(proc.stdout)>128*1024*1024:
        raise RuntimeError('Bounded original API response unavailable: '+path)
    return proc.stdout


def put(name,raw):
    target=OUT/name
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():
        assert target.read_bytes()==raw,'Original capture cannot change'
    else:
        with target.open('xb') as stream:
            stream.write(raw)
    return target


def save(name,value):
    return put(name,(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())


def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    return mod


def capture_artifact(artifact,private):
    key=f"artifact-{artifact['id']}"
    prior=OUT/(key+'-original-index.json')
    if prior.exists():
        value=json.loads(prior.read_bytes())
        assert sha((OUT/value['original_zip_file']).read_bytes())==value['original_zip_sha256']
        return value
    metaraw=api(f"actions/artifacts/{artifact['id']}")
    meta=json.loads(metaraw)
    assert meta['id']==artifact['id'] and not meta['expired']
    assert meta['workflow_run']['id']==RUN and meta['workflow_run']['head_sha']==SOURCE
    assert meta['name']=='wave5-native-10k-'+SOURCE
    put(key+'-original-api.json',metaraw)
    raw=api(f"actions/artifacts/{artifact['id']}/zip")
    assert meta['digest']=='sha256:'+sha(raw),'Original ZIP detached from API pin'
    records=[];pending=[]
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        infos=[info for info in archive.infolist() if not info.is_dir()]
        assert len(infos)<=1000 and len({info.filename for info in infos})==len(infos)
        assert sum(info.file_size for info in infos)<=128*1024*1024
        for info in infos:
            path=PurePosixPath(info.filename)
            assert not path.is_absolute() and '..' not in path.parts and ':' not in info.filename and '\\' not in info.filename
            assert stat.S_IFMT(info.external_attr>>16)!=stat.S_IFLNK and not info.flag_bits&1
            assert info.file_size<=32*1024*1024
            data=archive.read(info)
            assert len(data)==info.file_size
            matches={kind:len(pattern.findall(data)) for kind,pattern in private.items() if pattern.search(data)}
            if matches:
                pending.append({'entry_name':info.filename,'signature_types_and_counts':matches,'bytes':len(data),'sha256':sha(data)})
            records.append({'entry_name':info.filename,'bytes':len(data),'sha256':sha(data)})
        assert archive.read('workflow-source-commit.txt').decode().strip()==SOURCE
    value={'run_id':RUN,'source_commit':SOURCE,'accepted_runtime_source':RUNTIME,'artifact_id':meta['id'],
        'artifact_name':meta['name'],'original_zip_file':key+'-original.zip','original_zip_bytes':len(raw),
        'original_zip_sha256':sha(raw),'api_digest':meta['digest'],'records':records,
        'private_signature_review_pending':pending,'complete_original_zip_retained':not pending,
        'performance_comparison_accepted':False}
    if pending:
        save(key+'-private-signature-hold.json',value)
        raise ValueError('Original private signatures require literal/source review; no raw ZIP persisted')
    put(key+'-original.zip',raw)
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        for record in records:
            data=archive.read(record['entry_name'])
            assert sha(data)==record['sha256']
            put('original-members/'+record['entry_name'],data)
    save(key+'-original-index.json',value)
    return value


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--terminal',action='store_true')
    args=parser.parse_args()
    OUT.mkdir(exist_ok=True)
    stamp=datetime.now(UTC).strftime('%Y%m%dT%H%M%S%fZ')
    runraw,jobsraw,artsraw=(api(f'actions/runs/{RUN}'),api(f'actions/runs/{RUN}/jobs?per_page=100'),api(f'actions/runs/{RUN}/artifacts?per_page=100'))
    run,jobs,arts=map(json.loads,[runraw,jobsraw,artsraw])
    assert run['id']==RUN and run['head_sha']==SOURCE and run['run_attempt']==1
    assert jobs['total_count']==len(jobs['jobs'])<=10 and arts['total_count']==len(arts['artifacts'])<=10
    for label,raw in [('run',runraw),('jobs',jobsraw),('artifacts',artsraw)]:
        put(f'original-{label}-{stamp}.json',raw)
    projection={'source_commit':SOURCE,'runtime_commit':RUNTIME,'run_id':RUN,'run_status':run['status'],'run_conclusion':run['conclusion'],
        'jobs':[{key:job[key] for key in ['id','name','status','conclusion','started_at','completed_at']}|
                {'steps':[{key:step[key] for key in ['name','status','conclusion']} for step in job['steps']]}
                for job in jobs['jobs']], 'artifacts':arts['total_count'],'financial_acceptance':None,
        'performance_comparison_accepted':False}
    save('original-status-'+stamp+'.json',projection)
    if args.terminal:
        assert run['status']=='completed' and all(job['status']=='completed' for job in jobs['jobs'])
        private=load_module('private_signature_scope',OWN/'output/capture_wave5_large_journal_0756.py').PRIVATE
        span=load_module('safe_original_job_spans',OWN/'output/capture_final_ci_22ebfd78.py')
        artifacts=[capture_artifact(artifact,private) for artifact in arts['artifacts']]
        logs=[]
        for job in jobs['jobs']:
            key=f"job-{job['id']}"
            if (OUT/(key+'-log-provenance.json')).exists():
                logs.append(json.loads((OUT/(key+'-log-provenance.json')).read_bytes()));continue
            raw=api(f"actions/jobs/{job['id']}/logs")
            safe,retained,omitted=span.safe_spans(raw)
            assert safe==b''.join(raw[row['start_byte']:row['end_byte']] for row in retained)
            put(key+'-safe-original-spans.log',safe)
            value={'run_id':RUN,'source_commit':SOURCE,'job_id':job['id'],'job_conclusion':job['conclusion'],
                'remote_log_bytes':len(raw),'remote_log_sha256':sha(raw),'safe_projection_bytes':len(safe),
                'safe_projection_sha256':sha(safe),'retained_spans':retained,'omitted_spans':omitted,
                'original_complete_log_bytes_retained':not omitted,
                'full_remote_log_scope':'Private setup/auth/env excluded from public capture; original complete remote SHA/size/span provenance retained.'}
            save(key+'-log-provenance.json',value);logs.append(value)
        sources=[]
        for commit,relative in [(SOURCE,'.github/workflows/wave5-native-10k-capacity.yml'),
                (SOURCE,'.github/scripts/benchmark_wave5_profile_diagnostics.py'),(SOURCE,'tests/test_wave5_profile_diagnostics.py'),
                (RUNTIME,'.github/scripts/benchmark_enterprise_finance.py')]:
            raw=subprocess.check_output(['git','show',commit+':'+relative],cwd=OWN,timeout=30)
            blob=subprocess.check_output(['git','rev-parse',commit+':'+relative],cwd=OWN,text=True,timeout=30).strip()
            assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob
            file='original-git/'+commit+'/'+relative
            put(file,raw)
            sources.append({'source_commit':commit,'repository_path':relative,'entry_name':file,
                            'git_blob_sha1':blob,'bytes':len(raw),'sha256':sha(raw)})
        save('original-terminal-custody.json',{'schema_version':'wave5-native10k-terminal-original-custody-v1',
            **projection,'artifacts':artifacts,'logs':logs,'source_records':sources,
            'financial_acceptance':'Pending independent original file verification; workflow success alone not silently treated as financial proof.',
            'prior_setup_failure_source':'f04debf94bedc8c563a91bcc6c2de00342a4a4a5',
            'prior_setup_failure_preserved':True})
    print(json.dumps(projection))


if __name__=='__main__':
    main()
