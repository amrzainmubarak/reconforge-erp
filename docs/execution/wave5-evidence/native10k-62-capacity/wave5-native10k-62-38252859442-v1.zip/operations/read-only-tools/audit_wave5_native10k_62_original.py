"""Independent stdlib file-only original capacity custody and integer oracle."""
import argparse
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import re
import xml.etree.ElementTree as ET
import zipfile

SOURCE='62c41c42d66924039c4fbdae6b260cc0d33996e7'
CURRENT='22ebfd78e293aafa13d81b3a0bbf287491951115'
CURRENT_LINUX_SHA='acd60e50895d0d3b59af741ed4d36e5f62d98c205f0b48201a9eeb0a7beeba88'
DRIVER='d005e84654b412393c36c4fc2b7f81f25789a3bb8c6ce354e449bb6ef28cca76'
HARNESS='7bce2382df24d439d39386f0e02c07bf362c4f451649dbd8d7f225c8a920396b'
IMAGE='postgres:17.11-alpine@sha256:aa90e97ee862e558111d34cfb8b2c4bec768c2b039fb791341686928560263b3'


def need(condition,message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def unique(pairs):
    result={}
    for key,value in pairs:
        need(key not in result,'Duplicate original JSON member')
        result[key]=value
    return result


def decode(raw):
    return json.loads(raw,object_pairs_hook=unique,parse_constant=lambda _:need(False,'Nonfinite original JSON'))


def ints(values,names):
    need(all(type(values[name]) is int for name in names),'Exact nonboolean integer counter required')


def numeric(value):
    return type(value) in (int,float) and math.isfinite(value) and value>=0


def percentile(raw,summary):
    need(type(raw) is list and raw and all(numeric(value) for value in raw),'Invalid raw latency vector')
    ordered=sorted(raw)
    for label,p in [('p50',.50),('p95',.95),('p99',.99)]:
        need(summary[label]==ordered[max(0,math.ceil(len(raw)*p)-1)],'Latency percentile differs from original raw vector')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--packet',type=Path,required=True)
    parser.add_argument('--artifact-index',type=Path,required=True)
    parser.add_argument('--expected-index-sha256',required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    index_raw=args.artifact_index.read_bytes()
    need(re.fullmatch(r'[a-f0-9]{64}',args.expected_index_sha256) and sha(index_raw)==args.expected_index_sha256,'Separately trusted original artifact index differs')
    index=decode(index_raw)
    need(index['run_id']==38252859442 and index['source_commit']==SOURCE and index['accepted_runtime_source']==CURRENT,'Original artifact source/run differs')
    need(index['private_signature_review_pending']==[] and index['complete_original_zip_retained'] is True,'Original artifact private custody incomplete')
    packet=args.packet
    archive_raw=(packet/index['original_zip_file']).read_bytes()
    need(len(archive_raw)==index['original_zip_bytes'] and sha(archive_raw)==index['original_zip_sha256'] and index['api_digest']=='sha256:'+sha(archive_raw),'Original complete ZIP/API pin differs')
    records={row['entry_name']:row for row in index['records']}
    need(len(records)==len(index['records']),'Duplicate original member index')
    with zipfile.ZipFile(packet/index['original_zip_file']) as archive:
        members=[info.filename for info in archive.infolist() if not info.is_dir()]
        need(len(members)==len(records) and set(members)==set(records),'Original complete membership differs')
        for name in members:
            raw=archive.read(name)
            need(len(raw)==records[name]['bytes'] and sha(raw)==records[name]['sha256'] and raw==(packet/'original-members'/name).read_bytes(),'Original ZIP member custody differs')
    original=packet/'original-members'
    need((original/'workflow-source-commit.txt').read_text().strip()==SOURCE,'Original workflow header differs')
    junit=ET.parse(original/'pure-contracts.xml')
    need(len(junit.findall('.//testcase'))==245 and not any(junit.findall('.//'+tag) for tag in ['failure','error','skipped']),'Actual245 pure contracts did not complete without skips')
    capacity=decode((original/'capacity/capacity.json').read_bytes())
    child=original/'capacity/current-native-10000'
    diagnostic=decode((child/'diagnostic.json').read_bytes())
    native_raw=(child/'native/result.json').read_bytes()
    native=decode(native_raw)
    spec=decode((child/'spec.json').read_bytes())
    need(capacity['status']==diagnostic['status']==native['status']=='passed','Actual capacity financial/source/cleanup result failed')
    need(capacity['controller_source']['commit']==SOURCE and capacity['runtime_source']['commit']==CURRENT,'Controller/runtime conflated')
    need(capacity['launcher_sha256']==DRIVER and capacity['harness_sha256']==HARNESS,'Original controller/harness source differs')
    need(capacity['selected_entries']==10000 and type(capacity['selected_entries']) is int and capacity['selected_runs']==1,'Full10000 one-book capacity not selected')
    need([capacity[key] for key in ['harness_business_seconds','business_envelope_seconds','child_seconds','overall_seconds','cleanup_reserve_seconds']]==[7200,7500,7800,8400,120],'Original outer budgets differ')
    need(capacity['performance_comparison_accepted'] is False and capacity['cost_per_transaction'] is None,'Capacity silently promoted to comparison/cost')
    need((datetime.fromisoformat(capacity['finished_at'])-datetime.fromisoformat(capacity['started_at'])).total_seconds()<8400,'Actual overall deadline exceeded')
    need(diagnostic['source_before']==diagnostic['source_after']==capacity['runtime_source'],'Actual source changed')
    need(diagnostic['original_result_sha256']==sha(native_raw),'Native original report SHA detached')
    need(diagnostic['process_cleanup']['status']=='verified_exited' and diagnostic['container_cleanup']['status']=='verified_absent','Actual exact ownership cleanup incomplete')
    need(native['source_commit']==native['source_commit_after']==CURRENT and native['source_sha256']==native['source_sha256_after']==CURRENT_LINUX_SHA,'Runtime full source differs from accepted22')
    need(native['harness_sha256']==native['harness_sha256_after']==HARNESS and native['source_unchanged'] is True and native['owned_container_removed'] is True,'Native source/harness/cleanup incomplete')
    need(native['revision']=='0136_pg_inventory_scope' and native['image']==IMAGE and native['postgres_version'].startswith('17.11'),'Unexpected migration/image/runtime version')
    need(native['runtime_role_flags']==[False,False] and all(type(value) is bool for value in native['runtime_role_flags']),'Native role elevated')
    need(all(native['postgres_configuration'][key]=='on' for key in ['fsync','full_page_writes','synchronous_commit']),'Native durability relaxed')
    need(native['counts']==[10000] and type(native['counts'][0]) is int and native['workers']==4 and native['repetitions']==3 and native['posting_warmup_cycles']==20 and native['max_seconds']==7200 and native['snapshot_lines']==0,'Actual native admission differs')
    need('snapshot_reads' not in native and 'posting_database_profile' not in native,'Excluded profiling or big-journal mode executed')
    need(native['profile']=='native-three-human-cash-equity-v1' and native['seed']=='enterprise-native-v1','Original financial seed/profile differs')
    root=PurePosixPath(capacity['runtime_source']['root'])
    need(PurePosixPath(native['runtime_root'])==root==PurePosixPath(native['launch_cwd']),'Native runtime orcwd detached')
    need(PurePosixPath(native['harness_path'])==root/'.github/scripts/benchmark_enterprise_finance.py','Original common harness path detached')
    expected_output=PurePosixPath(spec['directory'])/'native'
    expected_command=['--counts','10000','--workers','4','--repetitions','3','--posting-warmup','20','--max-seconds','7200','--runtime-root',str(root),'--postgres-image',IMAGE,'--snapshot-lines','0','--output',str(expected_output)]
    need(native['command']==[native['command'][0],str(root/'.github/scripts/benchmark_enterprise_finance.py'),*expected_command],'Native command differs from one fixed capacity mode')
    need(spec['business_args']==expected_command and spec['mode']=='current-capacity' and spec['root']==str(root) and spec['harness']==str(root/'.github/scripts/benchmark_enterprise_finance.py') and spec['launcher_sha256']==DRIVER,'Original child spec not bound to fixed current capacity command')
    posting=native['posting'];warm=native['posting_warmup']
    ints(posting,['requested_cycles','admitted_cycles','completed_cycles','error_count','not_admitted_cycles'])
    need(posting['requested_cycles']==posting['admitted_cycles']==posting['completed_cycles']==10000 and posting['error_count']==posting['not_admitted_cycles']==0 and posting['failed_cycles']==[],'Actual full population partial/failed')
    need(posting['completed_indices']==list(range(10000)) and all(type(value) is int for value in posting['completed_indices']),'Reordered/missing/replayed native population')
    total=sum(1+int.from_bytes(hashlib.sha256(('enterprise-native-v1:'+str(i)).encode()).digest()[:8],'big')%1000000 for i in range(10000))
    need(total==5028151631,'Independent integer oracle source changed')
    expected={key:str(total) for key in ['debit_minor','credit_minor','cash_minor','equity_minor']}
    need(posting['expected']==expected,'Original native financial totals differ from independent seed')
    effects=posting['ordered_effect_ids']
    need(len(effects)==len(set(effects))==10000 and all(type(value) is str and re.fullmatch(r'PST-[a-f0-9]{32}',value) for value in effects),'Missing/duplicate original native effect population')
    need(warm['status']=='passed' and warm['completed_cycles']==20 and warm['indices']==list(range(10000,10020)) and all(type(value) is int for value in warm['indices']) and warm['outside_measured_population'] is True,'Original warmup population differs')
    need(len(warm['effect_ids'])==len(set(warm['effect_ids']))==20 and not set(warm['effect_ids'])&set(effects),'Warmup reused measured effect')
    effect_hash=sha(json.dumps(effects,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())
    reads=native['verified_reads']
    need(type(reads) is list and len(reads)==1,'Missing measured read population')
    read=reads[0]
    need(read['count']==10000 and read['status']=='passed' and read['expected']==expected and read['dataset_effect_ids_sha256']==effect_hash and set(read['samples'])=={'per_effect_baseline','bounded_batch'},'Measured read/source population detached')
    requests=0
    for mode,rows in read['samples'].items():
        need(len(rows)==3 and [row['repetition'] for row in rows]==[0,1,2],'Missing three original read repetitions')
        for row in rows:
            ints(row,['repetition','requested_effects','effects','error_count'])
            need(row['status']=='complete' and row['requested_effects']==row['effects']==10000 and row['error_count']==0 and row['debit_minor']==row['credit_minor']==str(total),'Original read financial totals differ')
            need(row['effects_digest']==read['financial_effects_digest'],'Original read effect digest differs')
            need(len(row['raw_request_latency_seconds'])==(10000 if mode=='per_effect_baseline' else 100),'Original measured request count differs')
            requests+=len(row['raw_request_latency_seconds']);percentile(row['raw_request_latency_seconds'],row['request_latency_seconds'])
    need(requests==30300,'Actual30300 reads incomplete')
    need(len(posting['raw_cycle_latency_seconds'])==10000,'Missing original native latency vector')
    percentile(posting['raw_cycle_latency_seconds'],posting['cycle_latency_seconds'])
    need(numeric(posting['seconds']) and posting['seconds']>0 and posting['native_postings_per_second']==10000/posting['seconds'] and posting['client_cpu_seconds_per_completed_cycle']==posting['client_process_cpu_seconds']/10000,'Native throughput/CPU arithmetic differs')
    admission=decode((child/'admission.json').read_bytes());origins=decode((child/'origins.json').read_bytes())
    need(admission['retained_pidfd'] is True and admission['process']==diagnostic['process']==origins['process'],'Actual retained native PID/session custody detached')
    need(origins['status']=='passed' and origins['runtime_root']==str(root) and origins['foreign_modules']==[] and origins['harness_sha256_after']==HARNESS,'Native module origin closure differs')
    need(all(PurePosixPath(row['path']).is_relative_to(root) for row in origins['origins']),'Imported module outside accepted22')
    required={'reconforge.infrastructure.postgres_finance_core','reconforge.infrastructure.postgres_finance_posting','reconforge.benchmark.resource_sampling','tests.erp_expansion_browser_seed'}
    need(required.issubset({row['module'] for row in origins['origins']}),'Missing four exact runtime origin probes')
    process=diagnostic['process']
    need(set(process)=={'pid','start_ticks','executable','session','process_group'} and all(type(process[key]) is int and process[key]>0 for key in ['pid','start_ticks','session','process_group']) and process['pid']==process['session']==process['process_group'],'Original retained process birth/session malformed')
    intent_raw=(child/'creation-intent.json').read_bytes();audit_raw=(child/'creation-audit.json').read_bytes()
    intent=decode(intent_raw);audit=decode(audit_raw)
    response=decode((child/'creation-response.json').read_bytes());created=decode((child/'created-container.json').read_bytes())
    cid=response['container_id']
    need(re.fullmatch(r'[a-f0-9]{64}',cid) and cid==created['container_id']==diagnostic['container_cleanup']['container_id'],'Original acknowledged fullCID/cleanup detached')
    need(response['returncode']==0 and type(response['returncode']) is int and response['process']==intent['process']==audit['process']==process,'Creation response not original admitted process')
    need(response['intent_sha256']==sha(intent_raw) and response['audit_sha256']==sha(audit_raw) and audit['status']=='matched' and audit['command_sha256']==intent['command_sha256'],'Pre-spawn intent/audit response SHA custody differs')
    need(intent['pre_spawn_exact_name_absent'] is True and created['name']=='/'+intent['name'] and re.fullmatch(r'reconforge-enterprise-finance-[a-f0-9]{12}',intent['name']),'Original exactname preexistence/collision guard absent')
    need(created['image']==intent['image']==IMAGE and created['owner_label']==intent['label']=='reconforge.owner=enterprise-finance-benchmark' and created['cmd']==intent['cmd']==['-c','join_collapse_limit=8','-c','from_collapse_limit=8'] and created['entrypoint']==intent['entrypoint']==['docker-entrypoint.sh'],'Immutable owned image/labels/entrypoint/command differs')
    need(datetime.fromisoformat(created['created_at'].replace('Z','+00:00'))>=datetime.fromisoformat(intent['observed_at']),'Acknowledged creation predates owned intent')
    need(created['auto_remove'] is True and created['publish_all_ports'] is False and created['privileged'] is False and created['restart_policy']=={'Name':'no','MaximumRetryCount':0},'Owned lifecycle config is unsafe/drifted')
    need(created['port_bindings']=={'5432/tcp':[{'HostIp':'127.0.0.1','HostPort':''}]} and set(created['actual_ports'])=={'5432/tcp'} and len(created['actual_ports']['5432/tcp'])==1 and created['actual_ports']['5432/tcp'][0]['HostIp']=='127.0.0.1' and created['actual_ports']['5432/tcp'][0]['HostPort'].isdigit(),'Owned loopback port custody differs')
    report={'schema_version':'wave5-independent-original-native10k-custody-integer-oracle-v1','status':'passed',
        'controller_source':SOURCE,'runtime_source':CURRENT,'run_id':38252859442,'artifact_id':index['artifact_id'],
        'trusted_index_sha256':sha(index_raw),'original_zip_sha256':sha(archive_raw),'original_members':len(records),
        'pure_contracts':{'passed':245,'failure':0,'error':0,'skip':0},'financial_verification':'passed',
        'independent_integer_seed_minor':str(total),'cycles':10000,'warmups':20,'measured_read_requests':30300,
        'original_native_report_sha256':sha(native_raw),'ordered_effect_ids_sha256':effect_hash,
        'financial_effects_digest':read['financial_effects_digest'],'native_postings_per_second':posting['native_postings_per_second'],
        'posting_seconds':posting['seconds'],'posting_client_cpu_seconds':posting['client_process_cpu_seconds'],
        'raw_cycle_percentiles':posting['cycle_latency_seconds'],'process_cleanup':'verified_exited','container_cleanup':'verified_absent','acknowledged_container_id':cid,
        'financial_scope':'Independent full seed arithmetic plus original native read totals/ordered population/source custody; no separate10000 raw native journal-line export or new isolation proof.',
        'resource_scope':'Original distinct client CPU/read and cgroup windows; no whole-host/process-tree CPU, fair source comparison or monetary cost.',
        'original_f04_setup_failure_preserved':True,'performance_comparison_accepted':False,'cost_per_transaction':None}
    need(not args.output.exists(),'Fresh immutable audit output required')
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps({'report':str(args.output),'sha256':sha(args.output.read_bytes()),'cycles':10000,'minor':str(total),'read_requests':requests,'performance_comparison_accepted':False}))


if __name__=='__main__':
    main()
