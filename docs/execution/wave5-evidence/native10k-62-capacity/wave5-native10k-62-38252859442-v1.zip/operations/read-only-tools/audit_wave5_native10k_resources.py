"""Original counter windows only; stdlib/file reads, no live resource queries."""
import hashlib
import json
from pathlib import Path

OUT=Path(__file__).resolve().parent/'wave5-native10k-62c41c42-38252859442'
raw=(OUT/'original-members/capacity/current-native-10000/native/result.json').read_bytes()
if hashlib.sha256(raw).hexdigest()!='38175801c65ccf4fb872d755a4fdc2fd5435d4db76a8695146c9cf11ba06def6':
    raise ValueError('Separately pinned original native report differs')
data=json.loads(raw)


def need(value, message):
    if not value:
        raise ValueError(message)


def counters(item):
    original=item['raw']
    cpu={}
    for line in original['cpu'].splitlines():
        key,value=line.split()
        need(key not in cpu,'Duplicate native CPU counter')
        cpu[key]=int(value)
    io={}
    for line in original['io'].splitlines():
        device,*fields=line.split()
        need(device not in io,'Duplicate native I/O device')
        values={}
        for field in fields:
            key,value=field.split('=',1)
            need(key not in values,'Duplicate native I/O counter')
            values[key]=int(value)
        io[device]=values
    network={}
    for line in original['network'].splitlines():
        if ':' in line:
            interface,fields=line.split(':',1)
            values=fields.split()
            need(len(values)==16 and interface.strip() not in network,'Malformed original network counter')
            network[interface.strip()]={'received_bytes':int(values[0]),'transmitted_bytes':int(values[8])}
    observed={'cpu_microseconds':cpu,'memory_current_bytes':int(original['memory_current']),
              'container_lifetime_peak_memory_bytes':int(original['memory_peak']),
              'block_io_by_device':io,'network_by_interface':network}
    need(all(item['parsed'][key]==value for key,value in observed.items()),'Raw/parsed original counters differ')
    return observed


before=counters(data['posting_container_counters_before'])
after=counters(data['posting_container_counters_after'])
cpu={key:after['cpu_microseconds'][key]-value for key,value in before['cpu_microseconds'].items()}
need(all(value>=0 for value in cpu.values()),'CPU counter reset/drift')
io={device:{key:after['block_io_by_device'][device][key]-value for key,value in fields.items()}
    for device,fields in before['block_io_by_device'].items()}
network={interface:{key:after['network_by_interface'][interface][key]-value for key,value in fields.items()}
         for interface,fields in before['network_by_interface'].items()}
need(all(value>=0 for fields in [*io.values(),*network.values()] for value in fields.values()),'I/O/network counter reset/drift')
sampler=data['resource_sampling'];samples=sampler['raw_samples']
need(sampler['status']=='complete' and sampler['errors']==[] and sampler['thread_still_running'] is False and sampler['interval_seconds']==10 and len(samples)==369,'Incomplete original sampler')
need(all(a['elapsed_seconds']<b['elapsed_seconds'] for a,b in zip(samples,samples[1:])),'Unordered original sampler')
db={key:samples[-1]['postgres_database_counters'][key]-value for key,value in samples[0]['postgres_database_counters'].items()}
wal={key:int(samples[-1]['postgres_wal_counters'][key])-int(value) for key,value in samples[0]['postgres_wal_counters'].items()}
need(all(value>=0 for value in [*db.values(),*wal.values()]),'Database/WAL counters reset/drift')
report={'schema_version':'wave5-native10k-original-resource-window-review-v1','status':'passed',
        'run_id':38252859442,'controller_source':'62c41c42d66924039c4fbdae6b260cc0d33996e7',
        'runtime_source':'22ebfd78e293aafa13d81b3a0bbf287491951115','native_report_sha256':hashlib.sha256(raw).hexdigest(),
        'posting_seconds':data['posting']['seconds'],'posting_client_cpu_seconds':data['posting']['client_process_cpu_seconds'],
        'posting_client_cpu_seconds_per_completed_cycle':data['posting']['client_cpu_seconds_per_completed_cycle'],
        'posting_container_cpu_delta_microseconds':cpu,'posting_container_block_io_delta':io,
        'posting_container_network_delta':network,'container_memory_current_before_bytes':before['memory_current_bytes'],
        'container_memory_current_after_bytes':after['memory_current_bytes'],
        'observed_container_lifetime_peak_after_posting_bytes':after['container_lifetime_peak_memory_bytes'],
        'max_observed_client_getrusage_lifetime_peak_rss_bytes':max(point['client_memory']['process_lifetime_peak_rss_bytes'] for point in samples),
        'sampler':{'points':len(samples),'interval_seconds':10,'first_elapsed_seconds':samples[0]['elapsed_seconds'],
                   'last_elapsed_seconds':samples[-1]['elapsed_seconds'],'pg_database_delta':db,'pg_wal_delta':wal},
        'database_bytes':data['database_bytes'],'host_observation':sampler['host_processor_observation'],
        'native_container_scope':data['posting_container_counters_after']['parsed']['scope'],
        'native_sampler_scope':sampler['scope'],'native_io_timing_interpretation':data['postgres_io_timing_interpretation'],
        'window_limits':['Client process_time measures client threads/in-process work only; container cgroupCPU is a different interval, includes observer exec overhead, and is not whole-host/process-tree CPU.',
                         'Counter files are sampled sequentially, not atomically; network and I/O deltas are container counters rather than application payload/cost.',
                         'Container lifetime peak includes startup/migration/warmup; client max observed getrusage lifetime peak can predate admission and omits any later unsampled peak.',
                         'Sampler covers warmup/posting/read/source intervals; database/WAL cumulative differences overlap and are not the isolated posting cgroup interval.',
                         'track_io_timing=off zero read/write milliseconds do not prove zero I/O latency; no I/O peak inferred.',
                         'Host processor frequency/power/neighbors unavailable; one current-only Linux book, not comparative acceptance.'],
        'total_host_cpu_computed':False,'overall_memory_peak_claimed':False,'performance_comparison_accepted':False,'monetary_cost_per_transaction':None}
target=OUT/'independent-resource-windows.json'
need(not target.exists(),'Fresh original supplemental report required')
target.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'report':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
                  'posting_cpu_cgroup_delta_usec':cpu['usage_usec'],'client_observed_lifetime_rss_bytes':report['max_observed_client_getrusage_lifetime_peak_rss_bytes'],
                  'container_lifetime_peak_bytes':report['observed_container_lifetime_peak_after_posting_bytes']}))
