"""One fresh read-only artifact retrieval; no workload retry, no auth output."""
from datetime import UTC, datetime
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import re
import subprocess
import zipfile

BASE=Path(__file__).resolve().parent
OUT=BASE/'wave5-native10k-62c41c42-38252859442'
ID=11751937667
meta=json.loads((OUT/f'artifact-{ID}-original-api.json').read_bytes())
need_digest='39bd08b84bf3867e2aba4661333a9e52681725b32a6d69f8418c6df6f6b5acee'
assert meta['digest']=='sha256:'+need_digest and meta['size_in_bytes']==609566
original=BASE/'capture_wave5_native10k_62_cloud.py'
copied=OUT/'original-first-capture-script.py'
assert not copied.exists()
copied.write_bytes(original.read_bytes())
stamp=datetime.now(UTC).strftime('%Y%m%dT%H%M%S%fZ')
path=f'repos/amrzainmubarak/reconforge-erp/actions/artifacts/{ID}/zip?evidence_capture={stamp}'
result=subprocess.run(['gh','api',path],capture_output=True,timeout=60,check=False)
record={'artifact_id':ID,'run_id':38252859442,'source_commit':'62c41c42d66924039c4fbdae6b260cc0d33996e7',
        'read_only_fresh_retrieval':True,'workload_retry':False,'client_returncode':result.returncode,
        'stdout_bytes':len(result.stdout),'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),
        'stderr_bytes':len(result.stderr),'stderr_sha256':hashlib.sha256(result.stderr).hexdigest(),
        'safe_http_status_codes':re.findall(r'HTTP ([0-9]{3})',result.stderr.decode(errors='replace')),
        'initial_capture_failure':'Original terminal collector returned RuntimeError before ZIP scan/persistence; client stderr discarded by that version, so original detailed network cause unavailable.'}
assert result.returncode==0 and hashlib.sha256(result.stdout).hexdigest()==need_digest
spec=importlib.util.spec_from_file_location('private_signature_screen',BASE/'capture_wave5_large_journal_0756.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
pending=[]
with zipfile.ZipFile(io.BytesIO(result.stdout)) as archive:
    infos=[item for item in archive.infolist() if not item.is_dir()]
    assert sum(item.file_size for item in infos)<128*1024*1024
    for item in infos:
        raw=archive.read(item)
        counts={kind:len(pattern.findall(raw)) for kind,pattern in module.PRIVATE.items() if pattern.search(raw)}
        if counts:
            pending.append({'member':item.filename,'signature_types_and_counts':counts,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
record['private_signature_review_pending']=pending
(OUT/'original-zip-read-recovery-metadata.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
assert not pending,'Private signature pending; raw ZIP not persisted'
target=OUT/f'artifact-{ID}-original.zip'
assert not target.exists()
target.write_bytes(result.stdout)
print(json.dumps({'file':str(target),'bytes':len(result.stdout),'sha256':need_digest,'members':len(infos),'private_signatures':0}))
