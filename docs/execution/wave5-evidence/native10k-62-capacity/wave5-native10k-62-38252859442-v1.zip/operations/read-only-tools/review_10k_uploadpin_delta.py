"""Same-byte single-line repair and retained setup log clarification only."""
import hashlib
import json
from pathlib import Path
import subprocess

OWN=Path(__file__).resolve().parents[1]
COMM=Path('C:/Users/LOQ/.codex/worktrees/reconforge-manufacturing-wave5/reconforge-erp')
OUT=OWN/'output/wave5-native-10k-f04-38251695820'
SOURCE='f04debf94bedc8c563a91bcc6c2de00342a4a4a5'
relative='.github/workflows/wave5-native-10k-capacity.yml'
old=subprocess.check_output(['git','show',SOURCE+':'+relative],cwd=OWN,timeout=30)
new=(COMM/relative).read_bytes()
bad=b'actions/upload-artifact@043fb7292af3fe63682d807b04f06a83c4b2b658 # v4'
good=b'actions/upload-artifact@043fb46d1a93c77aae656e7c1c64a875d1fc6a0a # v7'
assert old.count(bad)==1 and new==old.replace(bad,good)
driver=(COMM/'.github/scripts/benchmark_wave5_profile_diagnostics.py').read_bytes()
assert hashlib.sha256(driver).hexdigest()=='d005e84654b412393c36c4fc2b7f81f25789a3bb8c6ce354e449bb6ef28cca76'
assert driver==subprocess.check_output(['git','show',SOURCE+':.github/scripts/benchmark_wave5_profile_diagnostics.py'],cwd=OWN,timeout=30)
meta=json.loads((OUT/'original-full-job-log-provenance.json').read_bytes())
log=(OUT/'original-job-safe-spans.log').read_bytes()
assert len(log)==meta['remote_log_bytes']==meta['safe_projection_bytes']==1910
assert hashlib.sha256(log).hexdigest()==meta['remote_log_sha256']==meta['safe_projection_sha256']=='fde8e46474a56c7e7d28637c1954bb2ab5230ec1759260aa687706cf455dbce2'
assert not meta['omitted_spans'] and meta['retained_spans']==[{'first_line':1,'last_line':31,'start_byte':0,'end_byte':1910}]
summary={'schema_version':'wave5-native10k-onepin-repair-and-original-log-clarification-v1',
    'status':'passed','original_failure_source':SOURCE,
    'original_workflow_sha256':hashlib.sha256(old).hexdigest(),'corrected_workflow_sha256':hashlib.sha256(new).hexdigest(),
    'raw_byte_single_line_replacement_exact':True,'unchanged_driver_sha256':hashlib.sha256(driver).hexdigest(),
    'no_runtime_or_bounds_changes':True,'corrected_upload_action':'043fb46d1a93c77aae656e7c1c64a875d1fc6a0a',
    'official_object_source_api_sha256':'109202fcc476e130aa3e31914293eb202acd61caddd76b61c623fa8e2abe06be',
    'original_full_log_safe_spans_alias':{'entry_name':'original-job-safe-spans.log','bytes':1910,'sha256':hashlib.sha256(log).hexdigest(),
    'retained_all_original_bytes':True,'omitted_spans':0,
    'clarification':'Original conservative provenance said no separate full raw named file stored; actual safe projection is byte-identical to all1910 original remote log bytes. Original provenance remains unchanged.'},
    'actual_capacity_workload_from_failure':False,'new_run_executed_by_operations':False,'performance_comparison_accepted':False}
target=OUT/'onepin-repair-and-original-log-clarification.json'
assert not target.exists()
target.write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'file':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}))
