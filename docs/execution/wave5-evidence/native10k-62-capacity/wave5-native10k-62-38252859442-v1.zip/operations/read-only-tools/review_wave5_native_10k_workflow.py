"""Static-only deadline, source and artifact review; never imports runtime code."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import yaml

ROOT = Path('C:/Users/LOQ/.codex/worktrees/reconforge-manufacturing-wave5/reconforge-erp')
OUT = Path(__file__).resolve().parent / 'wave5-native-10k-workflow-static-review-20261012'
WF = ROOT / '.github/workflows/wave5-native-10k-capacity.yml'
DRIVER = ROOT / '.github/scripts/benchmark_wave5_profile_diagnostics.py'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    raw, driver = WF.read_bytes(), DRIVER.read_bytes()
    config = yaml.load(raw, Loader=yaml.BaseLoader)
    assert config['on'] == {'push': {'branches': ['amr/wave5-native-10k-capacity-20261012']}}
    assert config['permissions'] == {'contents': 'read'}
    assert config['concurrency']['cancel-in-progress'] == 'false'
    assert list(config['jobs']) == ['native-10k-capacity']
    job = config['jobs']['native-10k-capacity']
    assert job['runs-on'] == 'ubuntu-24.04' and job['timeout-minutes'] == '150'
    steps = job['steps']
    assert steps[0]['run'].index('mkdir') < steps[0]['run'].index('workflow-source-commit.txt')
    assert '$RUNNER_TEMP/wave5-native-10k' in steps[0]['run'] and '$GITHUB_SHA' in steps[0]['run']
    checkouts = [step for step in steps if step.get('uses', '').startswith('actions/checkout@')]
    assert len(checkouts) == 2
    for step in checkouts:
        assert step['uses'] == 'actions/checkout@93cb6efe18208431cddfb8368fd83d5badbf9bfd'
        assert step['with']['persist-credentials'] == 'false' and step['with']['fetch-depth'] == '0'
    assert checkouts[0]['with']['path'] == 'control'
    assert checkouts[0]['with'].get('ref', '${{ github.sha }}') == '${{ github.sha }}'
    assert checkouts[1]['with']['ref'] == '22ebfd78e293aafa13d81b3a0bbf287491951115'
    assert checkouts[1]['with']['path'] == 'current'
    uses = [step['uses'] for step in steps if 'uses' in step]
    assert all(len(value.rsplit('@', 1)[1]) == 40 for value in uses)
    assert set(uses) == {
        'actions/checkout@93cb6efe18208431cddfb8368fd83d5badbf9bfd',
        'actions/setup-python@a309ff8b426b58ec0e2a45f0f869d46889d02405',
        'astral-sh/setup-uv@c771a70e6277c0a99b617c7a806ffedaca235ff9',
        'actions/upload-artifact@043fb46d1a93c77aae656e7c1c64a875d1fc6a0a'}
    proven = subprocess.check_output(['git','show','0756dc49b7f7b3cbb4f5434e735fac64bf845b99:.github/workflows/wave5-large-journal-diagnostics.yml'],cwd=ROOT)
    approved = yaml.load(proven,Loader=yaml.BaseLoader)
    prior_uses = {step['uses'] for job in approved['jobs'].values() for step in job['steps'] if 'uses' in step}
    assert set(uses).issubset(prior_uses)
    assert 'uv sync --locked --all-extras --no-editable' in '\n'.join(step.get('run', '') for step in steps)
    calls = [step for step in steps if '--current-capacity-entries' in step.get('run', '')]
    assert len(calls) == 1 and calls[0]['working-directory'] == 'control'
    command = calls[0]['run']
    assert '--current-root ../current' in command and '--current-capacity-entries 10000' in command
    assert '--output "$RUNNER_TEMP/wave5-native-10k/capacity"' in command
    assert all(flag not in command for flag in ['--baseline-root', '--projection-root', '--large-snapshot-repetitions',
                                               '--include-serial', '--profile-stages', '--profile-cpu', '--profile-database'])
    upload = steps[-1]
    assert upload['if'] == 'always()'
    assert upload['uses'] == 'actions/upload-artifact@043fb46d1a93c77aae656e7c1c64a875d1fc6a0a'
    assert upload['with'] == {'name': 'wave5-native-10k-${{ github.sha }}',
                             'path': '${{ runner.temp }}/wave5-native-10k',
                             'if-no-files-found': 'error', 'retention-days': '30'}
    values = {}
    for node in ast.parse(driver).body:
        if isinstance(node, ast.Assign):
            try:
                value = ast.literal_eval(node.value)
            except (ValueError, TypeError):
                continue
            for target in node.targets:
                if isinstance(target, ast.Name):
                    values[target.id] = value
                elif isinstance(target, ast.Tuple):
                    for member, part in zip(target.elts, value, strict=True):
                        values[member.id] = part
    assert [values[key] for key in ['CAPACITY_HARNESS_SECONDS', 'CAPACITY_BUSINESS_SECONDS',
                                    'CAPACITY_CHILD_SECONDS', 'CAPACITY_TOTAL_SECONDS', 'RESERVE']] == [7200,7500,7800,8400,120]
    assert values['CURRENT'] == checkouts[1]['with']['ref']
    assert values['CAPACITY_ENTRIES'] == 10000 and values['CAPACITY_ORACLE_MINOR'] == '5028151631'
    assert values['HARNESS_SHA'] == '7bce2382df24d439d39386f0e02c07bf362c4f451649dbd8d7f225c8a920396b'
    assert values['IMAGE'] == 'postgres:17.11-alpine@sha256:aa90e97ee862e558111d34cfb8b2c4bec768c2b039fb791341686928560263b3'
    assert WF.read_bytes() == raw and DRIVER.read_bytes() == driver
    OUT.mkdir(exist_ok=True)
    suffix = sha(raw)[:12] + '-' + sha(driver)[:12]
    report = {'schema_version': 'wave5-native-10k-static-workflow-custody-review-v1', 'status': 'passed',
              'workflow_sha256': sha(raw), 'driver_sha256': sha(driver),
              'base_commit': subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
              'source_state': 'Reviewed file-byte checkpoint; no claim of committed cloud/native execution.',
              'runtime_commit': values['CURRENT'], 'harness_sha256': values['HARNESS_SHA'],
              'workflow_budget_seconds': 9000, 'driver_overall_seconds': 8400,
              'cleanup_reserve_within_driver_seconds': 120, 'setup_upload_headroom_seconds': 600,
              'headroom_limit': 'Setup and artifact elapsed time not pre-guaranteed; job timeout still fails and is preserved.',
              'selected_runs': 1, 'selected_entries': 10000, 'seed_oracle_minor': '5028151631',
              'expected_measured_read_requests': 30300, 'warmups': 20, 'runtime_revision': '0136_pg_inventory_scope',
              'controller_subject': 'Push event immutable github.sha checkout; exact source check by driver default GITHUB_SHA.',
              'artifact_policy': 'Early workflow subject before checkout; always artifact includes partial/negative reports; missing evidence fails.',
              'action_pins': 'All exact action objects reused from actual successful0756 workflow; corrected upload-object additionally resolved through official Git API109202fcc476e130aa3e31914293eb202acd61caddd76b61c623fa8e2abe06be.',
              'deadline_verdict': 'No static blocker;7200harness<7500admission<7800child<8400overall<9000job.',
              'native_or_financial_execution': False, 'performance_comparison_accepted': False}
    for name, data in [('workflow-original.yml',raw),('driver-checkpoint.py',driver),
                       ('review.json',(json.dumps(report,indent=2)+'\n').encode())]:
        path = OUT / (suffix + '-' + name)
        if path.exists():
            assert path.read_bytes() == data
        else:
            path.write_bytes(data)
    print(json.dumps({'report':str(OUT/(suffix+'-review.json')),
                      'sha256':sha((OUT/(suffix+'-review.json')).read_bytes()),'workflow_sha256':sha(raw),'driver_sha256':sha(driver)}))


if __name__ == '__main__':
    main()
