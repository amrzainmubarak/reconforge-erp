"""Original hosted10K file/Git/oracle review only; stdlib, no live ERP imports."""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import math
import re
import statistics
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime
from pathlib import Path, PurePosixPath

OWN = Path(__file__).resolve().parent
ROOT = Path(r"C:\Users\LOQ\.codex\worktrees\reconforge-integration-wave5\reconforge-erp")
CAP = Path(r"C:\Users\LOQ\.codex\worktrees\reconforge-operations-wave5\reconforge-erp\output\wave5-native10k-62c41c42-38252859442")
CONTROL = "62c41c42d66924039c4fbdae6b260cc0d33996e7"
CURRENT = "22ebfd78e293aafa13d81b3a0bbf287491951115"
ZIP_SHA = "39bd08b84bf3867e2aba4661333a9e52681725b32a6d69f8418c6df6f6b5acee"
INDEX_SHA = "e6d45579546883bce32b91e2014269d55088158ba9ecce9d1e36c565a03483b8"
FILES = {}

def need(value, reason):
    if not value:
        raise ValueError(reason)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def pairs(rows):
    result = {}
    for key, value in rows:
        need(key not in result, "Duplicate JSON member")
        result[key] = value
    return result

def read(path, expected=None):
    raw = path.read_bytes()
    need(expected is None or sha(raw) == expected, "Trusted original file SHA differs")
    FILES[str(path)] = {"sha256": sha(raw), "bytes": len(raw)}
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()

def git(*args):
    return subprocess.run(["git", *args], cwd=ROOT, capture_output=True, check=True, timeout=25).stdout

def git_fingerprint(commit):
    entries = []
    for entry in git("ls-tree", "-r", "--full-tree", "-z", commit).split(b"\0"):
        if entry:
            header, name = entry.split(b"\t", 1)
            mode, kind, ref = header.split()
            need(kind == b"blob" and mode in (b"100644", b"100755"), "Unsupported source-tree file semantics")
            entries.append((name.decode(), ref.decode()))
    entries.sort()
    stream = subprocess.Popen(["git", "cat-file", "--batch"], cwd=ROOT, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    need(stream.stdin is not None and stream.stdout is not None, "Read-only Git object pipe missing")
    result = hashlib.sha256()
    total = 0
    # Process request/response synchronously so neither pipe requires buffering
    # the complete tracked tree or crosses its small OS pipe capacity.
    for name, ref in entries:
        stream.stdin.write((ref + "\n").encode()); stream.stdin.flush()
        actual_ref, kind, size = stream.stdout.readline().split()
        remaining = int(size)
        need(actual_ref.decode() == ref and kind == b"blob", "Source Git object header differs")
        item = hashlib.sha256()
        while remaining:
            chunk = stream.stdout.read(min(remaining, 65536))
            need(bool(chunk), "Source Git object truncated")
            item.update(chunk); remaining -= len(chunk); total += len(chunk)
        need(stream.stdout.read(1) == b"\n", "Source Git object separator differs")
        result.update(name.encode()); result.update(item.digest())
    stream.stdin.close()
    need(stream.wait(timeout=25) == 0, "Source Git object read failed")
    return {"tracked_sha256": result.hexdigest(), "tracked_files": len(entries), "git_tree": git("rev-parse", commit + "^{tree}").decode().strip(),
            "independently_hashed_git_blob_bytes": total, "names": {name for name, _ in entries}}

class LinuxPath(PurePosixPath):
    def resolve(self, *args, **kwargs):
        need(self.is_absolute() and ".." not in self.parts, "Canonical original Linux path required")
        return self

def percentiles(values):
    need(values and all(type(v) in (int, float) and math.isfinite(v) and v >= 0 for v in values), "Malformed raw latency")
    ordered = sorted(values)
    return {label: ordered[min(len(ordered) - 1, math.ceil(len(ordered) * fraction) - 1)]
            for label, fraction in (("p50", .5), ("p95", .95), ("p99", .99))}

def kernel(packet):
    raw = packet["raw"]
    cpu = {key: int(value) for key, value in (line.split() for line in raw["cpu"].splitlines())}
    io = {}
    for line in raw["io"].splitlines():
        device, *fields = line.split()
        need(device not in io, "Duplicate block device")
        io[device] = {key: int(value) for key, value in (field.split("=", 1) for field in fields)}
    network = {}
    for line in raw["network"].splitlines():
        if ":" in line:
            name, values = line.split(":", 1)
            values = values.split(); need(len(values) == 16, "Invalid network record")
            network[name.strip()] = {"received_bytes": int(values[0]), "transmitted_bytes": int(values[8])}
    parsed = {"cpu_microseconds": cpu, "memory_current_bytes": int(raw["memory_current"]),
              "container_lifetime_peak_memory_bytes": int(raw["memory_peak"]), "block_io_by_device": io, "network_by_interface": network}
    need(all(packet["parsed"][key] == value for key, value in parsed.items()), "Original raw/parsed kernel counters differ")
    return parsed

def main():
    parser = argparse.ArgumentParser(); parser.add_argument("--output", type=Path, required=True); args = parser.parse_args()
    need(not args.output.exists(), "Never overwrite original independent review")
    index = read(CAP / "artifact-11751937667-original-index.json", INDEX_SHA)
    api = read(CAP / "artifact-11751937667-original-api.json")
    archive = CAP / "artifact-11751937667-original.zip"
    raw_zip = archive.read_bytes()
    need(len(raw_zip) == index["original_zip_bytes"] == 609566 and sha(raw_zip) == ZIP_SHA
         and index["api_digest"] == api["digest"] == "sha256:" + ZIP_SHA and api["id"] == 11751937667, "Original ZIP/API trust differs")
    need(index["source_commit"] == CONTROL and index["accepted_runtime_source"] == CURRENT and index["run_id"] == 38252859442, "Source subject differs")
    members = {}
    with zipfile.ZipFile(archive) as z:
        names = z.namelist()
        need(len(names) == len(set(names)) == len(index["records"]) == 15 and set(names) == {r["entry_name"] for r in index["records"]}, "Original ZIP membership differs")
        for row in index["records"]:
            path = PurePosixPath(row["entry_name"])
            need(not path.is_absolute() and ".." not in path.parts and "\\" not in row["entry_name"], "Unsafe archive member")
            raw = z.read(row["entry_name"]); local = CAP / "original-members" / row["entry_name"]
            need(raw == local.read_bytes() and sha(raw) == row["sha256"] and len(raw) == row["bytes"], "Original member hash/size/extraction differs")
            members[row["entry_name"]] = read(local, row["sha256"]) if row["entry_name"].endswith(".json") else raw
            FILES[str(local)] = {"sha256": sha(raw), "bytes": len(raw)}
    need(members["workflow-source-commit.txt"].decode().strip() == CONTROL, "Actual workflow subject differs")
    base = "capacity/current-native-10000/"
    packet, diagnostic, overall = members[base + "native/result.json"], members[base + "diagnostic.json"], members["capacity/capacity.json"]
    sources = {label: git_fingerprint(commit) for label, commit in (("runtime", CURRENT), ("controller", CONTROL))}
    for label, fingerprint in sources.items():
        subject = overall[label + "_source"]
        need(all(subject[key] == fingerprint[key] for key in ("tracked_sha256", "tracked_files", "git_tree")), "Independent complete Git source fingerprint differs")
    originals = [
        (CONTROL, ".github/scripts/benchmark_wave5_profile_diagnostics.py", "d005e84654b412393c36c4fc2b7f81f25789a3bb8c6ce354e449bb6ef28cca76"),
        (CONTROL, ".github/workflows/wave5-native-10k-capacity.yml", "30f2fe682d4d43bc69ce41c47de377b41c3569b29f498fbcd503f5aec5712b30"),
        (CURRENT, ".github/scripts/benchmark_enterprise_finance.py", "7bce2382df24d439d39386f0e02c07bf362c4f451649dbd8d7f225c8a920396b"),
        (CONTROL, "tests/test_wave5_profile_diagnostics.py", "a6fd9e7ef6263f5b5b73babfe95cb1250252981f93abf0003cc93f1ff2771353")]
    bound = []
    for commit, path, expected in originals:
        file = CAP / "original-git" / commit / path
        raw = file.read_bytes(); need(sha(raw) == expected and raw == git("show", f"{commit}:{path}"), "Original runtime/controller source capture differs")
        FILES[str(file)] = {"sha256": sha(raw), "bytes": len(raw)}; bound.append({"commit": commit, "repository_path": path, "sha256": expected, "bytes": len(raw)})
    # Invoke only the pinned controller's pure report verifier, never main/child.
    driver_path = CAP / "original-git" / CONTROL / originals[0][1]
    spec = importlib.util.spec_from_file_location("original62_file_oracle", driver_path)
    need(spec is not None and spec.loader is not None, "Original stdlib oracle loader missing")
    driver = importlib.util.module_from_spec(spec); spec.loader.exec_module(driver); driver.Path = LinuxPath
    expected_source = overall["runtime_source"]; harness = LinuxPath(packet["harness_path"])
    run_spec = members[base + "spec.json"]
    command = [packet["command"][0], str(harness), *run_spec["business_args"]]
    need(command[0] == overall["controller_source"]["root"] + "/.venv/bin/python3", "Original venv launcher path differs")
    original_proof = driver.verify_capacity(packet, expected_source, command, harness)
    need(original_proof == overall["financial_verification"] == diagnostic["verification"], "Original financial proof replay differs")
    total = sum(1 + int.from_bytes(hashlib.sha256(f"enterprise-native-v1:{i}".encode()).digest()[:8], "big") % 1000000 for i in range(10000))
    need(total == 5028151631, "Independent10K generator arithmetic differs")
    posting = packet["posting"]
    need(posting["completed_indices"] == list(range(10000)) and len(set(posting["ordered_effect_ids"])) == 10000
         and percentiles(posting["raw_cycle_latency_seconds"]) == posting["cycle_latency_seconds"], "Whole original primary latency/membership differs")
    need(diagnostic["source_before"] == diagnostic["source_after"] == expected_source and diagnostic["original_result_sha256"] == sha((CAP / "original-members" / (base + "native/result.json")).read_bytes()), "Final source/result binding differs")
    process = diagnostic["process"]; admission = members[base + "admission.json"]
    intent, audit, response, created = [members[base + name + ".json"] for name in ("creation-intent", "creation-audit", "creation-response", "created-container")]
    need(process["pid"] == process["session"] == process["process_group"] == 2539 and process["start_ticks"] == 4293
         and admission["retained_pidfd"] is True and admission["process"] == intent["process"] == audit["process"] == response["process"] == process,
         "Original PID birth/session/retained admission differs")
    need(process["executable"] == overall["python_executable"] and re.fullmatch(r"[a-f0-9]{64}", response["container_id"]), "Original physical interpreter/CID differs")
    need(response["intent_sha256"] == FILES[str(CAP / "original-members" / (base + "creation-intent.json"))]["sha256"]
         and response["audit_sha256"] == FILES[str(CAP / "original-members" / (base + "creation-audit.json"))]["sha256"]
         and response["response_sha256"] == sha((response["container_id"] + "\n").encode()) and response["returncode"] == 0
         and audit["command_sha256"] == intent["command_sha256"] and intent["pre_spawn_exact_name_absent"] is True, "Original typed creation/response custody differs")
    words = ["docker", "run", "--detach", "--rm", "--name", intent["name"], "--label", intent["label"], "-e", "POSTGRES_PASSWORD", "-p", "127.0.0.1::5432", intent["image"], *intent["cmd"]]
    need(sha(json.dumps(words, separators=(",", ":")).encode()) == intent["command_sha256"], "Original Docker typed command differs")
    need(created["container_id"] == response["container_id"] == diagnostic["container_cleanup"]["container_id"] and created["name"] == "/" + intent["name"]
         and created["image"] == packet["image"] == intent["image"] and created["cmd"] == intent["cmd"] and created["entrypoint"] == ["docker-entrypoint.sh"]
         and created["auto_remove"] is True and created["restart_policy"]["Name"] == "no" and created["publish_all_ports"] is False and created["privileged"] is False,
         "Immutable original container configuration differs")
    need(created["port_bindings"]["5432/tcp"][0]["HostIp"] == created["actual_ports"]["5432/tcp"][0]["HostIp"] == "127.0.0.1"
         and diagnostic["process_cleanup"]["status"] == "verified_exited" and diagnostic["container_cleanup"]["status"] == "verified_absent"
         and members[base + "worker-complete.json"] == {"exit_code": 0, "origin_status": "passed"}, "Final normal owned cleanup/worker closure differs")
    origins = members[base + "origins.json"]
    need(origins["process"] == process and origins["runtime_root"] == expected_source["root"] and origins["status"] == "passed"
         and origins["foreign_modules"] == [] and origins["harness_sha256_after"] == packet["harness_sha256"], "Module source admission differs")
    for row in origins["origins"]:
        path = LinuxPath(row["path"]); runtime = LinuxPath(expected_source["root"])
        need(path.is_relative_to(runtime) and path.relative_to(runtime).as_posix() in sources["runtime"]["names"], "Actual module origin is not a tracked current22 file")
    before, after = [kernel(packet[key]) for key in ("posting_container_counters_before", "posting_container_counters_after")]
    need(set(before["block_io_by_device"]) == set(after["block_io_by_device"]) and set(before["network_by_interface"]) == set(after["network_by_interface"]), "Kernel counter identity differs")
    io_delta = {key: sum(after["block_io_by_device"][dev][key] - before["block_io_by_device"][dev][key] for dev in before["block_io_by_device"])
                for key in ("rbytes", "wbytes", "rios", "wios", "dbytes", "dios")}
    net_delta = {key: sum(after["network_by_interface"][dev][key] - before["network_by_interface"][dev][key] for dev in before["network_by_interface"])
                 for key in ("received_bytes", "transmitted_bytes")}
    cpu_delta = {key: after["cpu_microseconds"][key] - before["cpu_microseconds"][key] for key in ("usage_usec", "user_usec", "system_usec")}
    samples = packet["resource_sampling"]["raw_samples"]
    need(len(samples) == 369 and all(row["client_pid"] == process["pid"] and row["host_processor"] is None for row in samples), "Resource process/sample scope differs")
    reads = packet["verified_reads"][0]
    read_metrics = {}
    for label, rows in reads["samples"].items():
        for row in rows:
            need(row["request_latency_seconds"] == percentiles(row["raw_request_latency_seconds"]) and row["verified_effects_per_second"] == 10000 / row["seconds"], "Original read latency/rate differs")
        read_metrics[label] = {"repetitions": [{key: value for key, value in row.items() if key != "raw_request_latency_seconds"} for row in rows],
            "seconds_median": statistics.median(row["seconds"] for row in rows),
            "client_cpu_seconds_median": statistics.median(row["client_process_cpu_seconds"] for row in rows),
            "traced_python_allocation_peak_median": statistics.median(row["peak_python_allocated_bytes"] for row in rows)}
    terminal = read(CAP / "original-terminal-custody.json")
    jobs = read(CAP / "original-jobs-20261012T141212390845Z.json")
    need(terminal["source_commit"] == CONTROL and terminal["runtime_commit"] == CURRENT and terminal["run_conclusion"] == "success"
         and jobs["total_count"] == len(jobs["jobs"]) == 1 and jobs["jobs"][0]["head_sha"] == CONTROL and jobs["jobs"][0]["id"] == 114823309885
         and jobs["jobs"][0]["conclusion"] == "success" and all(step["conclusion"] == "success" for step in jobs["jobs"][0]["steps"]), "Terminal original workflow/job subject differs")
    xml = members["pure-contracts.xml"]
    cases = list(ET.fromstring(xml).iter("testcase")); need(len(cases) == 245 and not any(list(c.iter(t)) for c in cases for t in ("failure", "error", "skipped")), "Original245 hosted pure gate differs")
    logs = read(CAP / "job-114823309885-log-provenance.json")
    full = (CAP / logs["local_only_raw_log_file"]).read_bytes(); safe = (CAP / "job-114823309885-safe-original-spans.log").read_bytes()
    need(len(full) == logs["remote_log_bytes"] == 66994 and sha(full) == logs["remote_log_sha256"] == "0ea88d00748524720ad00760d142844ea7b9834a0f42e12d0cbba63ae75ebf3a"
         and len(safe) == logs["safe_projection_bytes"] == 63129 and sha(safe) == logs["safe_projection_sha256"]
         and b"".join(full[row["start_byte"]:row["end_byte"]] for row in logs["retained_spans"]) == safe,
         "Original local full log / exact public span reconstruction differs")
    all_ranges = sorted((r["start_byte"], r["end_byte"]) for r in logs["retained_spans"] + logs["omitted_spans"])
    need(all_ranges[0][0] == 0 and all_ranges[-1][1] == len(full) and all(a[1] == b[0] for a, b in zip(all_ranges, all_ranges[1:])), "Full original log ranges fail exact coverage")
    report = {"schema_version": "wave5-actual62-native10k-independent-file-review-v1", "status": "passed", "source_control": CONTROL, "runtime_source": CURRENT,
        "run_id": 38252859442, "job_id": 114823309885, "artifact_id": 11751937667, "original_zip_sha256": ZIP_SHA, "original_index_sha256": INDEX_SHA,
        "original_member_count": 15, "source_bindings": bound, "independent_complete_git_fingerprints": {k: {a: b for a, b in v.items() if a != "names"} for k, v in sources.items()},
        "pinned_original_pure_oracle_reproduced": original_proof, "cross_platform_path_adapter": "Only canonical absolute PurePosixPath comparison; original source/report bytes unchanged; no host Linux filesystem assertion.",
        "counts": {"primary_effects": 10000, "disjoint_warm_effects": 20, "total_native_effects": 10020, "read_requests": 30300, "pure_passed": 245},
        "independent_integer_total_minor": str(total), "normal_retained_custody": {"process": process, "container_id": response["container_id"], "source_origin_files": len(origins["origins"]),
            "retained_pidfd_admission": True, "exact_cid_verified_absent": True, "process_verified_exited": True},
        "descriptive_metrics": {"whole_harness_wall_seconds": packet["wall_seconds"], "controller_wall_seconds": (datetime.fromisoformat(overall["finished_at"]) - datetime.fromisoformat(overall["started_at"])).total_seconds(),
            "posting_wall_seconds": posting["seconds"], "posting_throughput": posting["native_postings_per_second"], "posting_latency_seconds": posting["cycle_latency_seconds"],
            "posting_client_process_cpu_seconds": posting["client_process_cpu_seconds"], "posting_client_cpu_per_cycle_seconds": posting["client_cpu_seconds_per_completed_cycle"],
            "posting_cgroup_cpu_seconds": cpu_delta["usage_usec"] / 1000000, "posting_cgroup_cpu_microseconds": cpu_delta, "posting_bracket_io_delta": io_delta,
            "posting_bracket_network_delta": net_delta, "posting_end_container_lifetime_peak_bytes": after["container_lifetime_peak_memory_bytes"],
            "posting_end_container_current_bytes": after["memory_current_bytes"], "sampled_client_lifetime_rss_peak_bytes": max(r["client_memory"]["process_lifetime_peak_rss_bytes"] for r in samples),
            "resource_samples": len(samples), "sampled_wal_delta_bytes": int(samples[-1]["postgres_wal_counters"]["wal_bytes"]) - int(samples[0]["postgres_wal_counters"]["wal_bytes"]),
            "database_size_bytes": packet["database_bytes"], "sampled_database_counter_deltas": {k: samples[-1]["postgres_database_counters"][k] - samples[0]["postgres_database_counters"][k] for k in samples[0]["postgres_database_counters"]},
            "read_metrics": read_metrics},
        "full_log_local_only": {"bytes": len(full), "sha256": sha(full), "public_exact_span_bytes": len(safe), "public_exact_span_sha256": sha(safe), "omitted_bytes": len(full) - len(safe),
            "full_original_log_not_embedded_or_printed": True, "all_retained_omitted_ranges_exactly_cover_original": True},
        "original_file_index": FILES, "performance_comparison_accepted": False, "cost_per_transaction": None,
        "limits": ["File-only original15-member/Git/pure oracle/normal custody review; no DB/Docker/network/workload/application imports.",
            "One current22 native repository population; no matched baseline,3 independent populations, competitor comparison or fair performance/resource gain.",
            "10000 real three-human two-line USD cycles; not HTTP/mixedERP/manufacturing or1000-line commercial orders;100K/1M remain unestablished.",
            "Complete seeded arithmetic/membership/read digests are independently recomputed; raw10000 retained native snapshot rows were not exported in this packet. Per-cycle account correctness is enforced by original pinned harness, separate from arithmetic proof.",
            "Posting client process CPU and cgroup bracket counters have distinct boundaries; do not sum into whole-host/process-tree cost. Container counter bracket includes observer/exec overhead.",
            "Container peak at posting-end includes startup/migration/warm; sampled getrusage lifetime RSS is neither Python allocation peak nor current RSS. Read tracemalloc peaks have separate scopes.",
            "Sampled WAL/counters span warm/post/read work and miss final tail; cgroup I/O has separate posting bracket. Zero read bytes or track_io_timing=off zeros do not prove no database/host I/O.",
            "All369 Linux host processor samples are unavailable; no physical frequency/power/neighbor-load equality or Windows power evidence is borrowed.",
            "Normal successful PID/CID cleanup was exercised; actual timeout/group-stop paths remain pure/static reviewed rather than actual fault-exercised.",
            "Original F04 setup failure and original62 retrieval error remain historical; successful fresh ZIP read is transport recovery, not business retry.",
            "Full66994B job log remains local-only; public63129B exact spans and3865B explicit omissions are separate, never represented as the full raw log."]}
    args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"status": "passed", "members": 15, "cycles": 10000, "oracle_minor": str(total), "report_sha256": sha(args.output.read_bytes())}))

if __name__ == "__main__":
    main()
