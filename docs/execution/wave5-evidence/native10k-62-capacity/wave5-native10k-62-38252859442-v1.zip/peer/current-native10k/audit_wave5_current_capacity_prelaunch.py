"""File-only independent source and generator review; no app/test/runtime imports."""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

BASE = "0756dc49b7f7b3cbb4f5434e735fac64bf845b99"
REPO = Path(__file__).resolve().parents[1]
DRIVER = ".github/scripts/benchmark_wave5_profile_diagnostics.py"
TESTS = "tests/test_wave5_profile_diagnostics.py"
WORKFLOW = ".github/workflows/wave5-native-10k-capacity.yml"


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def require(value: bool, reason: str) -> None:
    if not value:
        raise ValueError(reason)


def git(*args: str) -> bytes:
    return subprocess.run(["git", *args], cwd=REPO, capture_output=True, check=True, timeout=20).stdout


def node_digest(node: ast.AST) -> str:
    return sha(ast.dump(node, include_attributes=False).encode())


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--driver-sha256", required=True)
    parser.add_argument("--tests-sha256", required=True)
    parser.add_argument("--xml", type=Path, required=True)
    parser.add_argument("--xml-sha256", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), "Never overwrite previous review")
    originals = args.output.parent / (args.output.stem + "-originals")
    require(not originals.exists(), "Never overwrite captured source")
    current_bytes = (REPO / DRIVER).read_bytes()
    tests_bytes = (REPO / TESTS).read_bytes()
    workflow_bytes = (REPO / WORKFLOW).read_bytes()
    xml_bytes = args.xml.read_bytes()
    require(sha(current_bytes) == args.driver_sha256, "Driver differs from reviewed checkpoint")
    require(sha(tests_bytes) == args.tests_sha256, "Tests differ from reviewed checkpoint")
    require(sha(xml_bytes) == args.xml_sha256, "Original targeted XML differs")
    require(sha(workflow_bytes) == "846cf244a98b76f9265a19105997aac53b5af9066e0edf0ef57aa70e58a620ef", "Workflow checkpoint differs")
    baseline = git("show", f"{BASE}:{DRIVER}")
    old_tree, current_tree = ast.parse(baseline), ast.parse(current_bytes)
    old = {n.name: n for n in old_tree.body if isinstance(n, ast.FunctionDef)}
    new = {n.name: n for n in current_tree.body if isinstance(n, ast.FunctionDef)}
    unchanged = []
    for name, node in old.items():
        if name != "main":
            require(name in new and node_digest(node) == node_digest(new[name]), f"Original function changed: {name}")
            unchanged.append({"name": name, "ast_sha256": node_digest(node)})
    main_node = new["main"]
    removed = []
    retained = []
    for node in main_node.body:
        selector = (isinstance(node, ast.Expr) and isinstance(node.value, ast.Call)
            and any(isinstance(arg, ast.Constant) and arg.value == "--current-capacity-entries" for arg in node.value.args))
        dispatcher = (isinstance(node, ast.If) and isinstance(node.test, ast.Compare)
            and isinstance(node.test.left, ast.Attribute) and node.test.left.attr == "current_capacity_entries")
        if selector or dispatcher:
            removed.append(node_digest(node))
        else:
            retained.append(node)
    main_node.body = retained
    require(len(removed) == 2 and node_digest(main_node) == node_digest(old["main"]), "Old main behavior changed beyond additive selector")
    assignments = {}
    for node in current_tree.body:
        if isinstance(node, ast.Assign):
            try:
                value = ast.literal_eval(node.value)
            except (ValueError, TypeError):
                continue
            for target in node.targets:
                if isinstance(target, ast.Name):
                    assignments[target.id] = value
                elif isinstance(target, ast.Tuple):
                    assignments.update(zip((t.id for t in target.elts), value, strict=True))
    require({name: assignments[name] for name in (
        "CAPACITY_ENTRIES", "CAPACITY_ORACLE_MINOR", "CAPACITY_HARNESS_SECONDS",
        "CAPACITY_BUSINESS_SECONDS", "CAPACITY_CHILD_SECONDS", "CAPACITY_TOTAL_SECONDS", "RESERVE")} == {
        "CAPACITY_ENTRIES": 10000, "CAPACITY_ORACLE_MINOR": "5028151631", "CAPACITY_HARNESS_SECONDS": 7200,
        "CAPACITY_BUSINESS_SECONDS": 7500, "CAPACITY_CHILD_SECONDS": 7800, "CAPACITY_TOTAL_SECONDS": 8400, "RESERVE": 120},
        "Capacity contract constants drifted")
    values = [1 + int.from_bytes(hashlib.sha256(f"enterprise-native-v1:{i}".encode("ascii")).digest()[:8], "big") % 1000000
              for i in range(10020)]
    require(sum(values[:10000]) == 5028151631 and len(values) == 10020, "Independent seed/minor oracle differs")
    require(3 * 10000 + 3 * ((10000 + 99) // 100) == 30300, "Full read request population differs")
    xml = ET.fromstring(xml_bytes)
    cases = list(xml.iter("testcase"))
    require(cases and not any(list(c.iter(tag)) for c in cases for tag in ("failure", "error", "skipped")), "Original pure gate failed/skipped")
    require(any("post_completion_source_timeout" in c.attrib["name"] and "capacity" in c.attrib["name"] for c in cases),
            "New capacity orchestrator lacks actual pure deadline regression")
    originals.mkdir(parents=True)
    raw_files = {"driver.py": current_bytes, "tests.py": tests_bytes, "workflow.yml": workflow_bytes,
                 "base0756-driver.py": baseline, "pure-targeted.xml": xml_bytes}
    for name, raw in raw_files.items():
        (originals / name).write_bytes(raw)
    report = {
        "schema_version": "wave5-current-capacity-independent-prelaunch-review-v1", "status": "passed",
        "base_commit": BASE, "head_observed": git("rev-parse", "HEAD").decode().strip(),
        "mode": "current-only-10000-native-capacity", "runtime_commit": assignments["CURRENT"],
        "runtime_revision": assignments["REVISIONS"]["current"], "common_harness_sha256": assignments["HARNESS_SHA"],
        "captured_files": [{"path": str(originals / name), "bytes": len(raw), "sha256": sha(raw)} for name, raw in raw_files.items()],
        "original_function_ast_equality": unchanged, "original_main_equality_after_only_two_additive_selector_nodes": True,
        "independent_financial_oracle": {"generator": "SHA256 first8 bytes big-endian modulo1000000 plus1; integer minor units",
            "primary_indices": [0, 9999], "primary_count": 10000, "debit_minor": str(sum(values[:10000])),
            "credit_minor": str(sum(values[:10000])), "cash_minor": str(sum(values[:10000])), "equity_minor": str(sum(values[:10000])),
            "warm_indices": [10000, 10019], "warm_count": 20, "warm_total_minor": str(sum(values[10000:])),
            "warm_excluded_from_primary": True, "read_requests": 30300},
        "bounds_seconds": {"harness": 7200, "business_success_and_source": 7500, "child": 7800, "overall": 8400, "cleanup_reserve": 120},
        "original_pure_gate": {"path": str(args.xml), "sha256": sha(xml_bytes), "passed": len(cases), "failures": 0, "errors": 0, "skips": 0,
            "attribution": "Owner executed original pure/mock gate on exact captured source; reviewer did not rerun tests"},
        "reviewed_controls": ["retained pidfd/session leader and pre-admission identity", "exact acknowledged64hex CID and immutable Docker configuration",
            "7500 success-side work cap retains overall cleanup allowance", "failed complete/partial/source/read admission stops process and performs owned cleanup",
            "one22/revision136 only; no baseline/projection/serial/large/SQL/cProfile flags", "all10000 ordered effects and20 disjoint warmups; three read repetitions eachmode",
            "contents:read workflow, exact runtime/source refs, pinned actions,150minute job, always original artifact capture"],
        "limits": ["Read-only static/source/generator/XML review; no native workload, DB, Docker, application import or test execution by reviewer.",
            "Pure/mock timeout tests do not establish actual timeout-path behavior on hosted Docker.", "Capacity result is pending; performance_comparison_accepted remains false and cost_per_transaction null.",
            "One eventual current book cannot establish comparative performance, competitor superiority,100K/1M or commercial/manufacturing orders."]}
    args.output.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"status": "passed", "original_functions": len(unchanged), "pure_cases": len(cases), "proof_sha256": sha(args.output.read_bytes())}))


if __name__ == "__main__":
    main()
