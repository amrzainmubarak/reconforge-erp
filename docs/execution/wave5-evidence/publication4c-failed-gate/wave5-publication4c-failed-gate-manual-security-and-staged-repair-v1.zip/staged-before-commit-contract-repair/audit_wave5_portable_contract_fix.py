"""Read-only source, original-pin, XML and documentation review; no tests/imports."""
import ast
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(r"C:\Users\LOQ\.codex\worktrees\reconforge-integration-wave5\reconforge-erp")
OWN = Path(__file__).resolve().parent
TEST = "tests/test_wave5_profile_diagnostics.py"
DRIVER = ".github/scripts/benchmark_wave5_profile_diagnostics.py"
BASE = "4c464b67f8b1fe9dbead40e5cf158dc1a5d9ff91"
XML = ROOT / "output/wave5-final-portable-contracts-4c-fix-r3.xml"
DEVELOPMENT = ROOT / "output/wave5-publication4c-portable-fix-development-v1.json"

def require(value, reason):
    if not value:
        raise ValueError(reason)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def git(*args):
    return subprocess.run(["git", *args], cwd=ROOT, capture_output=True, check=True, timeout=20).stdout

def pins(tree):
    return next(ast.literal_eval(node.value) for node in tree.body if isinstance(node, ast.Assign)
                and any(isinstance(target, ast.Name) and target.id == "ORIGINAL0756_FUNCTION_AST_SHA256" for target in node.targets))

raw = (ROOT / TEST).read_bytes()
require(sha(raw) == "1ea1f8e00397703cd8e1f65703e9e323ad98e768eda0d9ca980a7f29ef9414ae", "Fixed test checkpoint differs")
old = git("show", f"{BASE}:{TEST}")
tree, before = ast.parse(raw), ast.parse(old)
require(pins(tree) == pins(before) and len(pins(tree)) == 25, "Original0756 hash pins changed")
main_pin = b"6a2312a6182d2fe83527f967472ce685d488c69d59d28934ca558f055d5e88da"
require(raw.count(main_pin) == old.count(main_pin) == 1, "Original main pin changed")
require(git("diff", "--name-only").decode().splitlines() == ["docs/execution/DECISIONS.md", "docs/execution/EVIDENCE.md", "docs/execution/STATE.md", TEST],
        "Worktree diff extends authorized scope")
require(git("diff", BASE, "--", DRIVER) == b"", "Controller runtime changed")
require(git("diff", "22ebfd78e293aafa13d81b3a0bbf287491951115", "--", "reconforge", "alembic", "apps/web") == b"", "Application runtime changed")
xml_raw, development_raw = XML.read_bytes(), DEVELOPMENT.read_bytes()
require(sha(xml_raw) == "ecac0a5493365d91ac9cb1afa7375675918173d4a160fd2b5d4e510aa87a763a", "Original targeted XML differs")
require(sha(development_raw) == "083100696057134e80f8bfbd7d54a7cc01810a9712e8fec636104a530ccfefbe", "Original developer record differs")
development = json.loads(development_raw)
cases = list(ET.fromstring(xml_raw).iter("testcase"))
require(len(cases) == 264 and not any(list(case.iter(tag)) for case in cases for tag in ("failure", "error", "skipped")), "Actual264 pure gate differs")
case_names = [case.attrib["name"] for case in cases]
require(sum(name.startswith("test_portable_ast_only_admits_the_absent_empty_legacy_generic_field") for name in case_names) == 3
        and "test_controller_import_is_independent_in_a_fresh_isolated_interpreter" in case_names,
        "Meaningful import/AST refusal cases absent from actual XML")
require(development["changed_test_sha256"] == sha(raw) and development["targeted_xml_sha256"] == sha(xml_raw)
        and development["runtime_changed"] is False and development["historical_pins_changed"] is False
        and development["targeted_counts"] == {"tests": "264", "failures": "0", "errors": "0", "skipped": "0"}, "Source/gate developer record mismatch")
docs = []
for name in ("docs/execution/DECISIONS.md", "docs/execution/EVIDENCE.md", "docs/execution/STATE.md"):
    doc_raw = (ROOT / name).read_bytes()
    current = doc_raw.decode("utf-8").replace("\r\n", "\n")
    original = git("show", f"{BASE}:{name}").decode("utf-8").replace("\r\n", "\n")
    heading, tail = original.split("\n\n", 1)
    require(current.startswith(heading + "\n\n") and current.endswith(tail), "Historical execution text changed")
    added = current[len(heading) + 2:-len(tail)]
    require("5543passed/2failed/663" in added and "5544passed/1failed/663" in added and "264cases/0failures/errors/skips" in added
            and "Full corrected-source hosted acceptance remains pending" in added and "still in progress" in added
            and "this gate is not a success" in added, "New documentation misstates counts/status")
    docs.append({"path": name, "sha256": sha(doc_raw), "historical_body_unchanged": True, "added_text_sha256": sha(added.encode())})
capture = OWN / "wave5-portable-contract-fix-independent-originals-v1"
require(not capture.exists(), "Never overwrite reviewed originals")
capture.mkdir()
originals = {"fixed-tests.py": raw, "original4c-tests.py": old, "actual-targeted264.xml": xml_raw, "developer-record.json": development_raw}
for name, value in originals.items():
    (capture / name).write_bytes(value)
report = {"schema_version": "wave5-portable-contract-fix-independent-review-v1", "status": "passed", "failed_source": BASE,
    "fixed_test_sha256": sha(raw), "original_fixed_source_snapshots": [{"path": str(capture / name), "bytes": len(value), "sha256": sha(value)} for name, value in originals.items()],
    "original25_AST_pins_and_main_pin_unchanged": True, "driver_runtime_unchanged": True, "application_alembic_web_exact22": True,
    "reviewed_isolation": "Temporary patch.dict restores diagnostic registration; fresh -I subprocess checks no reconforge import and no retained controller registration.",
    "reviewed_normalization": "Deep-copy; append only absent legacy empty type_params to FunctionDef/AsyncFunctionDef/ClassDef; preserve nonempty generic fields/body changes/original AST.",
    "actual_owner_targeted_gate": {"tests": 264, "failures": 0, "errors": 0, "skips": 0, "xml_path": str(XML), "sha256": sha(xml_raw)},
    "documentation": docs, "failed_gate_retained": development["actual_failed_ci_run"], "previous_py311": development["actual_py311"], "previous_py312": development["actual_py312"],
    "limits": ["File/Git/AST/XML review only; reviewer ran no tests, imports, DB, workload or network.",
        "Targeted gate is owner development evidence, not clean-final-source full hosted acceptance.",
        "Failed4c full gate remains failure; corrected hosted acceptance and actual62 10K remain pending.",
        "Original failed remote counts are retained developer-source metadata checked for documentation consistency, not a new remote-log audit."]}
output = OWN / "wave5-portable-contract-fix-independent-review-v1.json"
require(not output.exists(), "Never overwrite review")
output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"status": "passed", "tests": 264, "report_sha256": sha(output.read_bytes())}))
