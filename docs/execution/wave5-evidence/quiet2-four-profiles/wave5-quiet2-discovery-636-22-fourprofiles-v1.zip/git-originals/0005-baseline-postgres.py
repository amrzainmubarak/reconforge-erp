"""Optional PostgreSQL connection and tenant-isolation boundary.

This module deliberately does not import psycopg at module import time.  The
local SQLite installation must remain usable without server dependencies, while
server deployments get a real PostgreSQL connection and database-enforced
tenant scope when the ``server`` extra is installed.

The application role used with the schema in this module must not own the
tables and must not be a PostgreSQL superuser or a role with ``BYPASSRLS``.
Those operational requirements are part of the security boundary and are
enforced on every application/worker lease by the runtime factories. Generic
factories remain available for administrative migrations and backup operations.
"""

from __future__ import annotations

import importlib
import re
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass, field
from queue import Empty, Queue
from threading import Condition
from time import monotonic
from types import ModuleType
from typing import Any, Protocol

_SCOPE_ID_PATTERN = re.compile(r"^[a-z0-9][a-z0-9_-]{0,63}$")


class PostgresConfigurationError(ValueError):
    """Raised when PostgreSQL settings or a tenant scope are unsafe."""


class PostgresUnavailableError(RuntimeError):
    """Raised when the optional PostgreSQL driver is not installed."""


class PostgresRuntimeRoleError(PostgresConfigurationError):
    """The runtime connection could not establish a safe database role."""


class PostgresConnectionPoolClosedError(RuntimeError):
    """Raised when a connection is requested after a pool has closed."""


class ConnectionFactory(Protocol):
    """Minimal connection-factory contract used by tenant-scoped services."""

    def connect(self) -> Any:
        """Return a connection supporting ``transaction``, ``execute``, and ``close``."""


@dataclass(frozen=True)
class PostgresConnectionPoolSnapshot:
    """Bounded, non-sensitive pool lifecycle counters."""

    max_size: int
    total: int
    idle: int
    leased: int
    closed: bool


def normalize_scope_id(value: str, *, field_name: str = "tenant_id") -> str:
    """Normalize and validate an identifier used in a PostgreSQL scope.

    IDs are intentionally restricted to the same conservative alphabet used by
    the local tenant router.  Values are passed as SQL parameters; this
    validation is an additional defense against accidental scope ambiguity and
    unsafe operational identifiers.
    """

    normalized = str(value or "").strip().lower()
    if not _SCOPE_ID_PATTERN.fullmatch(normalized):
        raise PostgresConfigurationError(
            f"{field_name} must use 1-64 lowercase letters, numbers, hyphens, or underscores."
        )
    return normalized


def validate_tenant_id(tenant_id: str) -> str:
    """Return a validated tenant identifier."""

    return normalize_scope_id(tenant_id, field_name="tenant_id")


def validate_organization_id(organization_id: str | None) -> str | None:
    """Return a validated optional organization identifier."""

    if organization_id is None:
        return None
    return normalize_scope_id(organization_id, field_name="organization_id")


def validate_workspace_id(workspace_id: str | None) -> str | None:
    """Return a validated optional workspace identifier."""

    if workspace_id is None:
        return None
    return normalize_scope_id(workspace_id, field_name="workspace_id")


def validate_legal_entity_id(legal_entity_id: str | None) -> str | None:
    """Return a validated optional legal-entity identifier."""

    if legal_entity_id is None:
        return None
    return normalize_scope_id(legal_entity_id, field_name="legal_entity_id")


@dataclass(frozen=True)
class PostgresExecutionScope:
    """Immutable tenant hierarchy attached to one database transaction.

    Optional child scopes are explicit rather than inferred.  Callers that
    operate tenant-wide leave them unset; entity/workspace-bound use cases must
    provide them so database policies can fail closed at the same boundary.
    """

    tenant_id: str
    organization_id: str | None = None
    workspace_id: str | None = None
    legal_entity_id: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "tenant_id", validate_tenant_id(self.tenant_id))
        object.__setattr__(self, "organization_id", validate_organization_id(self.organization_id))
        object.__setattr__(self, "workspace_id", validate_workspace_id(self.workspace_id))
        object.__setattr__(self, "legal_entity_id", validate_legal_entity_id(self.legal_entity_id))
        if self.legal_entity_id is not None and self.organization_id is None:
            raise PostgresConfigurationError("legal_entity_id requires organization_id.")


@dataclass(frozen=True)
class PostgresSettings:
    """Connection settings for the optional PostgreSQL server boundary."""

    dsn: str = field(repr=False)
    application_name: str = "reconforge"
    connect_timeout_seconds: int = 10
    statement_timeout_ms: int = 30_000
    require_tls: bool = True

    def __post_init__(self) -> None:
        if not self.dsn.strip():
            raise PostgresConfigurationError("PostgreSQL DSN must not be blank.")
        if not self.application_name.strip():
            raise PostgresConfigurationError("PostgreSQL application name must not be blank.")
        if self.connect_timeout_seconds <= 0:
            raise PostgresConfigurationError("PostgreSQL connect timeout must be positive.")
        if self.statement_timeout_ms <= 0:
            raise PostgresConfigurationError("PostgreSQL statement timeout must be positive.")


def _load_psycopg() -> ModuleType:
    try:
        return importlib.import_module("psycopg")
    except ImportError as exc:
        raise PostgresUnavailableError(
            "PostgreSQL support is optional. Install the server extra with `pip install 'reconforge-erp[server]'`."
        ) from exc


class PostgresConnectionFactory:
    """Create configured psycopg connections without leaking the DSN."""

    def __init__(self, settings: PostgresSettings) -> None:
        self.settings = settings

    def connect(self) -> Any:
        """Open a PostgreSQL connection with bounded, secure defaults."""

        psycopg = _load_psycopg()
        connect_kwargs: dict[str, Any] = {
            "connect_timeout": self.settings.connect_timeout_seconds,
            "application_name": self.settings.application_name,
            "options": f"-c statement_timeout={self.settings.statement_timeout_ms}",
            "row_factory": _hybrid_row_factory,
        }
        if self.settings.require_tls:
            connect_kwargs["sslmode"] = "verify-full"
        return psycopg.connect(self.settings.dsn, **connect_kwargs)


class PostgresConnectionPool:
    """Bounded, rollback-on-release pool for short tenant-scoped transactions.

    The pool deliberately wraps an existing ``ConnectionFactory`` instead of
    importing a third-party pool implementation.  ``PostgresTenantBoundary``
    still calls ``close`` after each transaction; the proxy returns the
    connection to this pool, so high-partition workers do not churn thousands
    of ephemeral TCP ports.  Transaction-local RLS settings are cleared by the
    surrounding commit/rollback, and release performs a defensive rollback
    before reuse.
    """

    def __init__(
        self,
        connection_factory: ConnectionFactory,
        *,
        max_size: int = 8,
        acquire_timeout_seconds: float = 30.0,
    ) -> None:
        if max_size < 1:
            raise ValueError("max_size must be positive")
        if acquire_timeout_seconds <= 0:
            raise ValueError("acquire_timeout_seconds must be positive")
        self.connection_factory = connection_factory
        self.max_size = max_size
        self.acquire_timeout_seconds = acquire_timeout_seconds
        self._idle: Queue[Any] = Queue(maxsize=max_size)
        self._condition = Condition()
        self._total = 0
        self._closed = False

    @property
    def snapshot(self) -> PostgresConnectionPoolSnapshot:
        """Return pool counters without exposing connection or tenant data."""

        with self._condition:
            idle = self._idle.qsize()
            return PostgresConnectionPoolSnapshot(
                max_size=self.max_size,
                total=self._total,
                idle=idle,
                leased=self._total - idle,
                closed=self._closed,
            )

    def connect(self) -> Any:
        """Lease one pooled connection, waiting only up to the configured bound."""

        deadline = monotonic() + self.acquire_timeout_seconds
        with self._condition:
            while True:
                if self._closed:
                    raise PostgresConnectionPoolClosedError("PostgreSQL connection pool is closed")
                try:
                    connection = self._idle.get_nowait()
                except Empty:
                    if self._total < self.max_size:
                        self._total += 1
                        break
                    remaining = deadline - monotonic()
                    if remaining <= 0:
                        raise TimeoutError("timed out waiting for a PostgreSQL pooled connection") from None
                    self._condition.wait(timeout=remaining)
                    continue
                return _PooledPostgresConnection(self, connection)
        try:
            connection = self.connection_factory.connect()
        except Exception:
            with self._condition:
                self._total -= 1
                self._condition.notify()
            raise
        return _PooledPostgresConnection(self, connection)

    def _release(self, connection: Any) -> None:
        reusable = True
        try:
            if bool(getattr(connection, "closed", False)):
                reusable = False
            else:
                connection.rollback()
        except Exception:
            reusable = False
        with self._condition:
            if self._closed or not reusable:
                self._total -= 1
                try:
                    connection.close()
                finally:
                    self._condition.notify()
                return
            self._idle.put_nowait(connection)
            self._condition.notify()

    def close(self) -> None:
        """Close all idle connections; active leases close when returned."""

        with self._condition:
            if self._closed:
                return
            self._closed = True
            while True:
                try:
                    connection = self._idle.get_nowait()
                except Empty:
                    break
                self._total -= 1
                connection.close()
            self._condition.notify_all()


class PostgresPooledConnectionFactory(PostgresConnectionFactory):
    """PostgreSQL factory with bounded connection reuse for server profiles.

    The class intentionally subclasses ``PostgresConnectionFactory`` so the
    existing server capability checks remain source-compatible.  Each
    request-scoped boundary still leases and closes a proxy; ``close`` returns
    the underlying connection to the bounded pool rather than closing the TCP
    socket.  Application shutdown must call :meth:`close` to release idle
    connections.
    """

    def __init__(
        self,
        settings: PostgresSettings,
        *,
        max_size: int = 8,
        acquire_timeout_seconds: float = 30.0,
    ) -> None:
        super().__init__(settings)
        self._pool = PostgresConnectionPool(
            PostgresConnectionFactory(settings),
            max_size=max_size,
            acquire_timeout_seconds=acquire_timeout_seconds,
        )

    def connect(self) -> Any:
        """Lease one bounded pooled connection."""

        return self._pool.connect()

    def close(self) -> None:
        """Close idle connections and prevent new leases."""

        self._pool.close()

    @property
    def max_size(self) -> int:
        """Return the configured maximum number of physical connections."""

        return self._pool.max_size

    @property
    def acquire_timeout_seconds(self) -> float:
        """Return the bounded lease wait timeout."""

        return self._pool.acquire_timeout_seconds

    @property
    def pool_snapshot(self) -> PostgresConnectionPoolSnapshot:
        """Return bounded pool lifecycle counters for health/diagnostic surfaces."""

        return self._pool.snapshot


# PostgreSQL 16+ SET membership and USAGE inheritance are different capabilities.
# A SET-reachable identity can inherit ownership from another role. ADMIN on a
# membership allows granting SET back to oneself, including ADMIN available
# through an inherited role, so those edges are reachable too.
# Catalogs/functions are qualified against a modified search_path.
_RUNTIME_ROLE_SAFETY_SQL = """
WITH RECURSIVE reachable_identities(oid) AS (
    SELECT oid
    FROM pg_catalog.pg_roles
    WHERE rolname IN (SESSION_USER, CURRENT_USER)
    UNION
    SELECT membership.roleid
    FROM reachable_identities identity
    JOIN pg_catalog.pg_auth_members membership
      ON (membership.member = identity.oid AND membership.set_option)
      OR (membership.admin_option
          AND pg_catalog.pg_has_role(identity.oid, membership.member, 'USAGE'))
), runtime_identities AS MATERIALIZED (
    SELECT role.* FROM pg_catalog.pg_roles role
    JOIN reachable_identities identity ON identity.oid = role.oid
), protected_owners AS MATERIALIZED (
    SELECT datdba AS owner FROM pg_catalog.pg_database WHERE datname = pg_catalog.current_database()
    UNION
    SELECT nspowner FROM pg_catalog.pg_namespace
    WHERE nspname !~ '^pg_' AND nspname <> 'information_schema'
    UNION
    SELECT c.relowner FROM pg_catalog.pg_class c
    JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
    WHERE n.nspname !~ '^pg_' AND n.nspname <> 'information_schema'
    UNION
    SELECT p.proowner FROM pg_catalog.pg_proc p
    JOIN pg_catalog.pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname !~ '^pg_' AND n.nspname <> 'information_schema'
)
SELECT CURRENT_USER = SESSION_USER
   AND pg_catalog.current_setting('row_security') = 'on'
   AND COALESCE(pg_catalog.current_setting('app.tenant_id', true), '') = ''
   AND COALESCE(pg_catalog.current_setting('app.organization_id', true), '') = ''
   AND COALESCE(pg_catalog.current_setting('app.workspace_id', true), '') = ''
   AND COALESCE(pg_catalog.current_setting('app.legal_entity_id', true), '') = ''
   AND COALESCE(pg_catalog.current_setting('app.entity_id', true), '') = ''
   AND NOT EXISTS (
       SELECT 1 FROM runtime_identities
       WHERE rolsuper OR rolbypassrls OR rolcreaterole OR rolcreatedb OR rolreplication
   )
   AND NOT EXISTS (
       SELECT 1 FROM runtime_identities identity
       JOIN protected_owners owned
         ON pg_catalog.pg_has_role(identity.oid, owned.owner, 'USAGE')
   )
   AND NOT EXISTS (
       SELECT 1 FROM runtime_identities identity
       JOIN pg_catalog.pg_roles privileged
         ON privileged.rolname IN (
             'pg_read_server_files', 'pg_write_server_files', 'pg_execute_server_program'
         )
       WHERE pg_catalog.pg_has_role(identity.oid, privileged.oid, 'USAGE')
   )
   AND NOT EXISTS (
       SELECT 1 FROM runtime_identities identity
       CROSS JOIN pg_catalog.pg_database database
       WHERE database.datname = pg_catalog.current_database()
         AND pg_catalog.has_database_privilege(identity.oid, database.oid, 'CREATE')
   )
   AND NOT EXISTS (
       SELECT 1 FROM runtime_identities identity
       CROSS JOIN pg_catalog.pg_namespace namespace
       WHERE namespace.nspname !~ '^pg_' AND namespace.nspname <> 'information_schema'
         AND pg_catalog.has_schema_privilege(identity.oid, namespace.oid, 'CREATE')
   )
   AND NOT EXISTS (
       SELECT 1 FROM runtime_identities identity
       CROSS JOIN pg_catalog.pg_class relation
       JOIN pg_catalog.pg_namespace namespace ON namespace.oid = relation.relnamespace
       WHERE namespace.nspname !~ '^pg_' AND namespace.nspname <> 'information_schema'
         AND relation.relkind IN ('r', 'p', 'f')
         AND pg_catalog.has_table_privilege(identity.oid, relation.oid, 'TRUNCATE,TRIGGER,REFERENCES')
   )
   AND NOT EXISTS (
       SELECT 1 FROM runtime_identities identity
       CROSS JOIN pg_catalog.pg_proc routine
       JOIN pg_catalog.pg_namespace namespace ON namespace.oid = routine.pronamespace
       WHERE namespace.nspname !~ '^pg_' AND namespace.nspname <> 'information_schema'
         AND routine.prosecdef
         AND routine.prorettype NOT IN (
             'pg_catalog.trigger'::pg_catalog.regtype, 'pg_catalog.event_trigger'::pg_catalog.regtype
         )
         AND pg_catalog.has_function_privilege(identity.oid, routine.oid, 'EXECUTE')
   )
   AS runtime_role_safe
"""


def _validate_runtime_connection(connection: Any) -> Any:
    """Validate one fresh lease and discard it on rejection or catalog failure.

    One catalog query and rollback precede application transactions on every
    checkout; there is no cached safety result. This detects deployment role
    mistakes and privilege drift between leases, including effective DDL,
    table-wide privileges and callable user-schema SECURITY DEFINER routines.
    Installed trigger routines remain part of the trusted schema: PostgreSQL
    forbids calling them directly and runtime TRIGGER/CREATE rights are denied.
    Database administrators and
    application code remain trusted: a shared role can set tenant GUCs, and an
    administrator can change privileges after this check.
    """

    try:
        row = connection.execute(_RUNTIME_ROLE_SAFETY_SQL).fetchone()
        connection.rollback()
        if row is None or row[0] is not True:
            raise PostgresRuntimeRoleError("PostgreSQL runtime role safety check failed.")
    except Exception:
        try:
            if isinstance(connection, _PooledPostgresConnection):
                connection.discard()
            else:
                connection.close()
        except Exception:
            raise PostgresRuntimeRoleError("PostgreSQL runtime role safety check failed.") from None
        raise PostgresRuntimeRoleError("PostgreSQL runtime role safety check failed.") from None
    return connection


class PostgresRuntimePooledConnectionFactory(PostgresPooledConnectionFactory):
    """Application pool enforcing runtime role safety on every lease."""

    def connect(self) -> Any:
        try:
            connection = super().connect()
        except Exception:
            raise PostgresRuntimeRoleError("PostgreSQL runtime connection unavailable.") from None
        return _validate_runtime_connection(connection)


class PostgresRuntimeConnectionFactory:
    """Enforce runtime safety for workers supplied with any connection factory.

    Generic factories remain available for administrative migrations and backup
    operations. Wrapping an already guarded application pool does not duplicate
    the query; that pool still validates each checkout itself.
    """

    def __init__(self, connection_factory: ConnectionFactory) -> None:
        self.connection_factory = connection_factory

    def connect(self) -> Any:
        try:
            connection = self.connection_factory.connect()
        except PostgresRuntimeRoleError:
            raise
        except Exception:
            raise PostgresRuntimeRoleError("PostgreSQL runtime connection unavailable.") from None
        if isinstance(
            self.connection_factory, (PostgresRuntimeConnectionFactory, PostgresRuntimePooledConnectionFactory)
        ):
            return connection
        return _validate_runtime_connection(connection)

    def close(self) -> None:
        closer = getattr(self.connection_factory, "close", None)
        if callable(closer):
            closer()


class _PooledPostgresConnection:
    """Minimal proxy whose close returns its underlying connection to a pool."""

    def __init__(self, pool: PostgresConnectionPool, connection: Any) -> None:
        self._pool = pool
        self._connection = connection
        self._released = False

    def __getattr__(self, name: str) -> Any:
        return getattr(self._connection, name)

    def close(self) -> None:
        if self._released:
            return
        self._released = True
        self._pool._release(self._connection)

    def discard(self) -> None:
        """Physically close a rejected lease instead of returning it to idle."""

        if self._released:
            return
        self._released = True
        try:
            self._connection.close()
        finally:
            with self._pool._condition:
                self._pool._total -= 1
                self._pool._condition.notify()


class _HybridPostgresRow:
    """Expose one immutable driver row by stable name and positional index."""

    __slots__ = ("_index", "_names", "_values")

    def __init__(self, names: tuple[str, ...], values: tuple[object, ...]) -> None:
        self._names = names
        self._values = values
        self._index = {name: index for index, name in enumerate(names)}

    def __getitem__(self, key: str | int | slice) -> object:
        if isinstance(key, str):
            return self._values[self._index[key]]
        return self._values[key]

    def __iter__(self):  # type: ignore[no-untyped-def]
        return iter(self._values)

    def __len__(self) -> int:
        return len(self._values)

    def keys(self) -> tuple[str, ...]:
        return self._names

    def get(self, key: str, default: object = None) -> object:
        index = self._index.get(key)
        return default if index is None else self._values[index]


def _hybrid_row_factory(cursor: Any):  # type: ignore[no-untyped-def]
    names = tuple(column.name for column in (cursor.description or ()))

    def make_row(values: tuple[object, ...]) -> _HybridPostgresRow:
        return _HybridPostgresRow(names, values)

    return make_row


def set_local_tenant_scope(
    connection: Any,
    tenant_id: str,
    organization_id: str | None = None,
    *,
    workspace_id: str | None = None,
    legal_entity_id: str | None = None,
) -> PostgresExecutionScope:
    """Set transaction-local tenant context using parameterized SQL.

    ``set_config(..., true)`` is equivalent to ``SET LOCAL`` for the custom
    settings used by the RLS policies.  The transaction-local flag ensures a
    pooled connection cannot retain one request's tenant after commit or
    rollback.
    """

    scope = PostgresExecutionScope(
        tenant_id=tenant_id,
        organization_id=organization_id,
        workspace_id=workspace_id,
        legal_entity_id=legal_entity_id,
    )
    connection.execute("SELECT set_config('app.tenant_id', %s, true)", (scope.tenant_id,))
    connection.execute("SELECT set_config('app.organization_id', %s, true)", (scope.organization_id or "",))
    connection.execute("SELECT set_config('app.workspace_id', %s, true)", (scope.workspace_id or "",))
    connection.execute("SELECT set_config('app.legal_entity_id', %s, true)", (scope.legal_entity_id or "",))
    connection.execute("SELECT set_config('app.entity_id', %s, true)", (scope.legal_entity_id or "",))
    return scope


class PostgresTenantBoundary:
    """Own one connection and transaction for a tenant-scoped operation."""

    def __init__(self, connection_factory: ConnectionFactory) -> None:
        self.connection_factory = connection_factory

    @contextmanager
    def transaction(
        self,
        tenant_id: str,
        *,
        organization_id: str | None = None,
        workspace_id: str | None = None,
        legal_entity_id: str | None = None,
    ) -> Iterator[Any]:
        """Yield a connection whose current transaction is tenant-scoped."""

        connection = self.connection_factory.connect()
        try:
            with connection.transaction():
                set_local_tenant_scope(
                    connection,
                    tenant_id,
                    organization_id,
                    workspace_id=workspace_id,
                    legal_entity_id=legal_entity_id,
                )
                yield connection
        finally:
            connection.close()


POSTGRES_RLS_SCHEMA_SQL = """
CREATE SCHEMA IF NOT EXISTS reconforge;

CREATE TABLE IF NOT EXISTS reconforge.tenants (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS reconforge.organizations (
    tenant_id TEXT NOT NULL,
    id TEXT NOT NULL,
    name TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (tenant_id, id),
    FOREIGN KEY (tenant_id) REFERENCES reconforge.tenants(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS reconforge.tenant_memberships (
    tenant_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    role_name TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (tenant_id, user_id, role_name),
    FOREIGN KEY (tenant_id) REFERENCES reconforge.tenants(id) ON DELETE CASCADE
);

ALTER TABLE reconforge.tenants ENABLE ROW LEVEL SECURITY;
ALTER TABLE reconforge.tenants FORCE ROW LEVEL SECURITY;
ALTER TABLE reconforge.organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE reconforge.organizations FORCE ROW LEVEL SECURITY;
ALTER TABLE reconforge.tenant_memberships ENABLE ROW LEVEL SECURITY;
ALTER TABLE reconforge.tenant_memberships FORCE ROW LEVEL SECURITY;

DO $reconforge$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies
        WHERE schemaname = 'reconforge'
          AND tablename = 'tenants'
          AND policyname = 'tenant_scope'
    ) THEN
        CREATE POLICY tenant_scope ON reconforge.tenants
            USING (id = current_setting('app.tenant_id', true))
            WITH CHECK (id = current_setting('app.tenant_id', true));
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies
        WHERE schemaname = 'reconforge'
          AND tablename = 'organizations'
          AND policyname = 'tenant_scope'
    ) THEN
        CREATE POLICY tenant_scope ON reconforge.organizations
            USING (tenant_id = current_setting('app.tenant_id', true))
            WITH CHECK (tenant_id = current_setting('app.tenant_id', true));
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies
        WHERE schemaname = 'reconforge'
          AND tablename = 'tenant_memberships'
          AND policyname = 'tenant_scope'
    ) THEN
        CREATE POLICY tenant_scope ON reconforge.tenant_memberships
            USING (tenant_id = current_setting('app.tenant_id', true))
            WITH CHECK (tenant_id = current_setting('app.tenant_id', true));
    END IF;
END
$reconforge$;
"""


def install_postgres_rls_schema(connection: Any) -> None:
    """Install the idempotent foundation schema using a caller-owned transaction."""

    connection.execute(POSTGRES_RLS_SCHEMA_SQL)
