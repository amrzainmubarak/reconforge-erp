"""Small ignored discovery launcher; --action prepare never starts a workload.

Run only after ROOT explicitly authorizes an additional quiet window. Reuses
the unchanged V4 physical interpreter, Job/admission, typed Docker intent,
Windows audit crosscheck, acknowledged full-ID cleanup, and final22 harness.
These instrumented100-cycle diagnostics never grant performance acceptance.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import statistics
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
V4 = HERE.parent / "pair"
sys.path.insert(0, str(V4))
import final22_pair as owner  # noqa: E402 - exact immutable stdlib V4 protocol

TRUSTED_V4 = "7b904ff39d3db18634b581e83dde73d928d1e9d8783466749f9e42e3fbff33ca"
BUSINESS_SECONDS, CHILD_SECONDS, OVERALL_SECONDS = 600, 900, 1200
MODES = {"four-worker": (4, ["--profile-stages", "--profile-database"]),
         "serial-cpu": (1, ["--profile-stages", "--profile-cpu"])}
PLAN_FIELDS = {"schema_version", "status", "variant", "mode", "created_at", "launcher_sha256", "v4_readiness_sha256",
               "commit", "source_sha256", "harness_sha256", "business_seconds", "child_seconds", "overall_seconds",
               "cleanup_reserve_seconds", "quiet_window", "no_workload_launched", "performance_comparison_accepted"}
QUIET_PENDING = "Human approved additional quiet window; ROOT authorizes diagnostic discovery2026-10-12T14:19:35UTC"


def exact_ints(value: dict[str, Any], names: tuple[str, ...]) -> None:
    owner.require(all(type(value[name]) is int for name in names), "Population counter must be an exact nonboolean integer")


def validate_plan(plan: dict[str, Any]) -> dict[str, Any]:
    owner.require(type(plan) is dict and set(plan) == PLAN_FIELDS, "Incomplete/unknown discovery plan envelope")
    owner.require(type(plan["variant"]) is str and plan["variant"] in owner.COMMITS
                  and type(plan["mode"]) is str and plan["mode"] in MODES, "Unknown discovery source/mode")
    exact_ints(plan, ("business_seconds", "child_seconds", "overall_seconds", "cleanup_reserve_seconds"))
    owner.require((plan["business_seconds"], plan["child_seconds"], plan["overall_seconds"], plan["cleanup_reserve_seconds"])
                  == (BUSINESS_SECONDS, CHILD_SECONDS, OVERALL_SECONDS, owner.CLEANUP_RESERVE), "Discovery time bounds differ")
    owner.require(plan["schema_version"] == "final22-profile-discovery-plan-v1" and plan["status"] == "prepared_not_launched"
                  and plan["quiet_window"] == QUIET_PENDING and plan["no_workload_launched"] is True
                  and plan["performance_comparison_accepted"] is False, "Discovery admission state differs")
    owner.require(type(plan["created_at"]) is str and datetime.fromisoformat(plan["created_at"]).utcoffset() is not None,
                  "Plan creation time requires an explicit timezone")
    v4 = frozen()
    owner.require(plan["launcher_sha256"] == owner.sha(Path(__file__)) and plan["v4_readiness_sha256"] == TRUSTED_V4,
                  "Discovery launcher/immutable protocol changed")
    owner.require(plan["commit"] == owner.COMMITS[plan["variant"]]
                  and plan["source_sha256"] == v4["sources"][plan["variant"]]["tracked_sha256"]
                  and plan["harness_sha256"] == v4["harness_sha256"], "Plan original source/harness differs")
    return v4


def validate_warm(warm: dict[str, Any], effects: list[str]) -> None:
    exact_ints(warm, ("completed_cycles",))
    owner.require(warm["status"] == "passed" and warm["completed_cycles"] == 20 and warm["indices"] == list(range(100, 120))
                  and all(type(value) is int for value in warm["indices"])
                  and warm["outside_measured_population"] is True and len(warm["effect_ids"]) == len(set(warm["effect_ids"])) == 20
                  and all(type(value) is str and value for value in warm["effect_ids"])
                  and not set(warm["effect_ids"]) & set(effects), "Warmup population differs")


def validate_phases(observations: list[dict[str, Any]]) -> None:
    expected_keys = {(index, f"{stage}.{phase}") for index in range(120) for stage in ("prepare", "review", "post")
                     for phase in ("identity_enter", "business", "transaction_exit")}
    owner.require(all(type(row["index"]) is int and type(row["phase"]) is str for row in observations),
                  "Phase identity must use exact integer/string types")
    owner.require(len(observations) == len(expected_keys) and {(row["index"], row["phase"]) for row in observations} == expected_keys
                  and all(row["failure_type"] is None for row in observations), "Missing/failed profiled phases including warmups")
    owner.require(all(type(row[name]) in (int, float) and math.isfinite(row[name]) and row[name] >= 0
                      for row in observations for name in ("seconds", "thread_cpu_seconds")), "Invalid phase timing observation")


def frozen() -> dict[str, Any]:
    path = V4 / "readiness-v4.json"
    owner.require(owner.sha(path) == TRUSTED_V4, "Immutable V4 readiness changed")
    value = owner.read(path)
    owner.check_bundle(value)
    return value


def command(plan: dict[str, Any], destination: Path) -> tuple[list[str], list[str]]:
    v4 = frozen()
    actual, _reported = owner.child_command(v4, plan["variant"], destination)
    workers, flags = MODES[plan["mode"]]
    root = owner.ROOTS[plan["variant"]].resolve()
    business = ["--counts", "100", "--workers", str(workers), "--repetitions", "3", "--posting-warmup", "20",
                "--max-seconds", str(BUSINESS_SECONDS), "--runtime-root", str(root), "--postgres-image", owner.IMAGE,
                "--snapshot-lines", "0", *flags, "--output", str(destination.resolve())]
    return [*actual[:actual.index("--") + 1], *business], [str(owner.PYTHON.resolve()), v4["harness_path"], *business]


def verify(packet: dict[str, Any], plan: dict[str, Any], reported: list[str]) -> dict[str, Any]:
    v4 = frozen()
    variant, mode = plan["variant"], plan["mode"]
    root = owner.ROOTS[variant].resolve()
    owner.require(packet["status"] == "passed" and packet["source_unchanged"] is True and packet["owned_container_removed"] is True,
                  "Incomplete source/financial/cleanup run")
    owner.require(packet["source_commit"] == packet["source_commit_after"] == owner.COMMITS[variant]
                  and packet["source_sha256"] == packet["source_sha256_after"] == v4["sources"][variant]["tracked_sha256"],
                  "Unexpected actual runtime source")
    owner.require(packet["harness_sha256"] == packet["harness_sha256_after"] == v4["harness_sha256"]
                  and packet["command"] == reported and Path(packet["runtime_root"]).resolve() == root
                  and Path(packet["launch_cwd"]).resolve() == root, "Common harness/actual command provenance differs")
    owner.require(packet["counts"] == [100] and packet["workers"] == MODES[mode][0] and packet["repetitions"] == 3
                  and packet["posting_warmup_cycles"] == 20 and packet["max_seconds"] == BUSINESS_SECONDS
                  and packet["snapshot_lines"] == 0 and packet["image"] == owner.IMAGE
                  and packet["runtime_role_flags"] == [False, False] and packet["cost_per_transaction"] is None,
                  "Discovery profile configuration differs")
    owner.require(all(type(value) is int for value in packet["counts"]), "Count population must be exact integers")
    owner.require(packet["seed"] == "enterprise-native-v1" and packet["profile"] == "native-three-human-cash-equity-v1"
                  and packet["revision"] == ("0132_pg_stock_inverse_dispatch" if variant == "baseline" else "0136_pg_inventory_scope")
                  and packet["postgres_version"].startswith("17.11")
                  and all(type(packet[name]) is int for name in ("workers", "repetitions", "posting_warmup_cycles", "max_seconds", "snapshot_lines"))
                  and all(type(value) is bool for value in packet["runtime_role_flags"]), "Typed version/current role/profile differs")
    owner.require(all(packet["postgres_configuration"][name] == "on" for name in ("fsync", "full_page_writes", "synchronous_commit")),
                  "Durability disabled")
    posting = packet["posting"]
    exact_ints(posting, ("requested_cycles", "admitted_cycles", "completed_cycles", "error_count", "not_admitted_cycles"))
    owner.require(posting["requested_cycles"] == posting["admitted_cycles"] == posting["completed_cycles"] == 100
                  and posting["completed_indices"] == list(range(100))
                  and all(type(value) is int for value in posting["completed_indices"])
                  and posting["error_count"] == posting["not_admitted_cycles"] == 0 and posting["failed_cycles"] == [],
                  "Incomplete/failed posting population")
    total = str(sum(1 + int(hashlib.sha256(f"enterprise-native-v1:{index}".encode()).hexdigest()[:16], 16) % 1_000_000
                    for index in range(100)))
    expected = dict.fromkeys(("debit_minor", "credit_minor", "cash_minor", "equity_minor"), total)
    owner.require(total == "46669102" and posting["expected"] == expected, "Independent integer oracle differs")
    effects = posting["ordered_effect_ids"]
    owner.require(len(effects) == len(set(effects)) == 100 and all(isinstance(value, str) and value for value in effects), "Duplicate/missing native effects")
    warm = packet["posting_warmup"]
    validate_warm(warm, effects)
    original = owner.load_oracle()
    original._retained.validate_percentiles(posting["raw_cycle_latency_seconds"], posting["cycle_latency_seconds"])
    owner.require(len(posting["raw_cycle_latency_seconds"]) == 100, "Missing original latency vector")
    reads = packet["verified_reads"]
    owner.require(len(reads) == 1, "Missing original read profile")
    exact_ints(reads[0], ("count",))
    owner.require(len(reads) == 1 and reads[0]["count"] == 100 and reads[0]["status"] == "passed"
                  and reads[0]["expected"] == expected, "Missing verified100-effect reads")
    profile = reads[0]
    digest = hashlib.sha256(json.dumps(effects, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()
    owner.require(profile["dataset_effect_ids_sha256"] == digest and set(profile["samples"]) == {"per_effect_baseline", "bounded_batch"},
                  "Read population differs from original posting")
    for label, rows in profile["samples"].items():
        owner.require(all(type(row["repetition"]) is int for row in rows), "Read repetition must be an exact integer")
        owner.require([row["repetition"] for row in rows] == [0, 1, 2], "Missing read repetitions")
        for row in rows:
            exact_ints(row, ("error_count", "requested_effects", "effects"))
            owner.require(row["status"] == "complete" and row["error_count"] == 0 and row["requested_effects"] == row["effects"] == 100
                          and row["debit_minor"] == row["credit_minor"] == total and row["effects_digest"] == profile["financial_effects_digest"]
                          and len(row["raw_request_latency_seconds"]) == (100 if label == "per_effect_baseline" else 1),
                          "Read oracle/population failed")
            original._retained.validate_percentiles(row["raw_request_latency_seconds"], row["request_latency_seconds"])
    retained = packet["posting_profile"]
    owner.require(retained["enabled"] is True and retained["function_profile"]["enabled"] is (mode == "serial-cpu"),
                  "Requested stage/CPU instrumentation missing")
    observations = retained["raw_phase_observations"]
    validate_phases(observations)
    if mode == "four-worker":
        owner.require(packet["posting_database_profile"]["status"] == "complete" and packet["postgres_configuration"]["track_io_timing"] == "on",
                      "Owned PostgreSQL discovery missing")
    else:
        exact_ints(retained["function_profile"], ("cycle_ceiling",))
        owner.require(retained["function_profile"]["cycle_ceiling"] == 32 and retained["function_profile"]["functions"],
                      "Bounded serial function profile missing")
    original._retained.resources(packet)
    original.verify_observation_counters(packet["resource_sampling"]["raw_samples"])
    measured = [row for row in observations if row["index"] < 100]
    phases = {phase: {"observations": len(rows), "wall_seconds_sum": sum(row["seconds"] for row in rows),
                     "thread_cpu_seconds_sum": sum(row["thread_cpu_seconds"] for row in rows),
                     "wall_seconds_median": statistics.median(row["seconds"] for row in rows)}
              for phase in sorted({row["phase"] for row in measured})
              if (rows := [row for row in measured if row["phase"] == phase])}
    return {"financial_verification": "passed", "independent100_oracle_minor": total,
            "measured_cycles": 100, "warmup_cycles": 20, "measured_read_requests": 303,
            "measured_phase_aggregates": phases, "performance_comparison_accepted": False,
            "cpu_attribution": "Phase thread CPU excludes other workers; client posting process CPU includes observer; cProfile wall includes I/O/blocking and profiles at most32 serial cycles.",
            "database_attribution": "Restricted-role top-level and nested pg_stat_statements counters after warmup reset through posting; overlapping/nested times must not be summed into wall time; no SQL text/parameters.",
            "limits": ["Instrumented diagnostic, not fair performance acceptance.", "Four-worker and serial modes are different workloads.",
                       "Identity-enter includes connection, scope, KDF, permissions and commit; no direct auth-SQL split.",
                       "Business statement timings exclude identity-entry SQL; deferred source closures occur in transaction exit.",
                       "No separate backend process CPU, whole-host ERP CPU or monetary cost; sampled peaks may miss spikes."]}


def prepare(path: Path, variant: str, mode: str) -> dict[str, Any]:
    v4 = frozen()
    owner.require(variant in owner.COMMITS and mode in MODES, "Unknown diagnostic profile")
    for label, root in owner.ROOTS.items():
        owner.require(owner.checked(["git", "rev-parse", "HEAD"], cwd=root).decode().strip() == owner.COMMITS[label]
                      and not owner.checked(["git", "status", "--porcelain", "--untracked-files=no"], cwd=root), "Frozen source changed")
    packet = {"schema_version": "final22-profile-discovery-plan-v1", "status": "prepared_not_launched", "variant": variant, "mode": mode,
              "created_at": datetime.now(UTC).isoformat(), "launcher_sha256": owner.sha(Path(__file__)), "v4_readiness_sha256": TRUSTED_V4,
              "commit": owner.COMMITS[variant], "source_sha256": v4["sources"][variant]["tracked_sha256"],
              "harness_sha256": v4["harness_sha256"], "business_seconds": BUSINESS_SECONDS, "child_seconds": CHILD_SECONDS,
              "overall_seconds": OVERALL_SECONDS, "cleanup_reserve_seconds": owner.CLEANUP_RESERVE,
              "quiet_window": QUIET_PENDING,
              "no_workload_launched": True, "performance_comparison_accepted": False}
    owner.write(path, packet)
    return packet


def run(plan: dict[str, Any], output: Path) -> dict[str, Any]:
    v4 = validate_plan(plan)  # Validate the complete envelope before output or process admission.
    variant = plan["variant"]
    owner.require(not output.exists(), "Fresh output required")
    output.mkdir(parents=True)
    begin = time.monotonic()
    deadline = begin + OVERALL_SECONDS
    packet = {"schema_version": "final22-profile-discovery-result-v1", "status": "failed", "variant": variant, "mode": plan["mode"],
              "started_at": datetime.now(UTC).isoformat(), "plan": plan, "performance_comparison_accepted": False}
    destination = output / "native-profile"
    ownership = output / "native-profile-ownership.json"
    actual, reported = command(plan, destination)
    packet.update(command=actual, reported_harness_command=reported)
    process = job = bound = identity = None
    aborted = True
    try:
        packet["source_before"] = owner.source(owner.ROOTS[variant], owner.COMMITS[variant], deadline=deadline)
        owner.require(packet["source_before"] == v4["sources"][variant], "Source differs from approved V4")
        packet["environment_before"] = owner.observe_scheme(deadline=deadline)
        environment = os.environ.copy()
        environment["__PYVENV_LAUNCHER__"] = str(owner.PYTHON.resolve())
        environment["PYTHONPATH"] = str(owner.ROOTS[variant].resolve())
        environment.pop("PYTHONHOME", None)
        with (output / "child.log").open("xb") as log:
            process = subprocess.Popen(actual, cwd=owner.ROOTS[variant], env=environment, stdout=log, stderr=subprocess.STDOUT,
                                       creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)
            try:
                identity = owner.process_identity(process.pid)
                owner.require(identity["pid"] == process.pid and Path(identity["executable"]).resolve() == owner.PHYSICAL.resolve(), "Physical child identity differs")
                packet["process"] = identity
                job = owner.OwnedJob(process)
            except Exception:
                process.kill()  # retained Popen handle; wrapper remains pre-admission
                process.wait(timeout=5)
                raise
            owner.write(output / "native-profile-admission.json", {"process": identity, "owned_job_assigned": True})
            child_deadline = min(deadline - owner.CLEANUP_RESERVE, time.monotonic() + CHILD_SECONDS)
            while process.poll() is None:
                owner.require(time.monotonic() < child_deadline and not (output / "STOP").exists(), "Diagnostic timeout/operator stop")
                if bound is None:
                    bound = owner.inspect_owned(ownership, identity, deadline=child_deadline)
                time.sleep(.5)
            packet["child_exit_code"] = process.returncode
            aborted = process.returncode != 0
            owner.require(process.returncode == 0, "Diagnostic child failed; original packet/log retained")
    except (Exception, KeyboardInterrupt) as exc:
        packet["primary_failure"] = {"type": type(exc).__name__, "failure": str(exc)}
    finally:
        if process is not None:
            try:
                packet["process_cleanup"] = owner.stop_owned(process, identity, job, deadline=deadline)
            except Exception as exc:
                packet["process_cleanup"] = {"status": "unverified", "failure_type": type(exc).__name__}
            finally:
                if job is not None:
                    job.close()
            try:
                packet["container_cleanup"] = owner.cleanup_container(bound, ownership, identity, aborted=aborted, deadline=deadline)
            except Exception as exc:
                packet["container_cleanup"] = {"status": "unverified", "failure_type": type(exc).__name__}
        try:
            if time.monotonic() < deadline:
                packet["environment_after"] = owner.observe_scheme(deadline=deadline)
                packet["source_after"] = owner.source(owner.ROOTS[variant], owner.COMMITS[variant], deadline=deadline)
            raw = destination / "result.json"
            if raw.is_file():
                packet["original_result_sha256"] = owner.sha(raw)
                if "primary_failure" in packet:
                    packet["original_child_failure"] = owner.read(raw).get("failure")
            owner.require("primary_failure" not in packet and packet.get("child_exit_code") == 0
                          and packet.get("container_cleanup", {}).get("status") == "verified_absent"
                          and packet["source_after"] == packet["source_before"], "Incomplete diagnostic/source/cleanup")
            origins = owner.read(output / "native-profile-origins.json")
            owner.require(origins["status"] == "passed" and origins["process"] == identity, "Actual source-origin closure failed")
            packet["origin_closure_sha256"] = owner.sha(output / "native-profile-origins.json")
            packet["verification"] = verify(owner.read(raw), plan, reported)
            packet["status"] = "passed"
        except Exception as exc:
            packet["verification_failure"] = {"type": type(exc).__name__, "failure": str(exc)}
        packet.update(finished_at=datetime.now(UTC).isoformat(), wall_seconds=time.monotonic() - begin)
        owner.write(output / "profile.json", packet)
    return packet


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--action", choices=("prepare", "run"), required=True)
    parser.add_argument("--variant", choices=tuple(owner.COMMITS))
    parser.add_argument("--mode", choices=tuple(MODES))
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--plan-sha256")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.action == "prepare":
        result = prepare(args.plan.resolve(), args.variant, args.mode)
        print(json.dumps({"status": result["status"], "plan_sha256": owner.sha(args.plan), "no_workload_launched": True}))
        return 0
    owner.require(args.output is not None and args.plan_sha256 == owner.sha(args.plan), "Explicit trusted plan SHA/fresh output required")
    result = run(owner.read(args.plan), args.output.resolve())
    print(json.dumps({"status": result["status"], "output": str(args.output), "performance_comparison_accepted": False}))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
