"""Pure command/financial-population contracts; no application imports/workload."""
from __future__ import annotations

import copy
import unittest
from pathlib import Path
from unittest.mock import patch

import profile_final22 as p


class Contracts(unittest.TestCase):
    def test_same_frozen_protocol_harness_and_pins(self) -> None:
        for variant in p.owner.COMMITS:
            for mode, (workers, flags) in p.MODES.items():
                actual, reported = p.command({"variant": variant, "mode": mode}, Path("C:/synthetic-discovery") / variant / mode)
                self.assertEqual(actual[0], str(p.owner.PHYSICAL.resolve()))
                self.assertEqual(actual[2], str(p.V4 / "owned_child.py"))
                self.assertEqual(reported[0], str(p.owner.PYTHON.resolve()))
                self.assertEqual(reported[reported.index("--counts") + 1], "100")
                self.assertEqual(reported[reported.index("--workers") + 1], str(workers))
                self.assertEqual(reported[reported.index("--runtime-root") + 1], str(p.owner.ROOTS[variant].resolve()))
                self.assertEqual(reported[reported.index("--postgres-image") + 1], p.owner.IMAGE)
                self.assertEqual(reported[reported.index("--max-seconds") + 1], "600")
                self.assertTrue(all(flag in reported for flag in flags))
                self.assertEqual("--profile-database" in reported, mode == "four-worker")
                self.assertEqual("--profile-cpu" in reported, mode == "serial-cpu")
                self.assertIn("--admission", actual)

    def test_immutable_v4_changed_hash_refuses(self) -> None:
        with patch.object(p.owner, "sha", return_value="0" * 64), self.assertRaises(ValueError):
            p.frozen()

    def test_financial_oracle_and_population_checks_run_before_instrumentation_acceptance(self) -> None:
        # Deliberately incomplete synthetic report: valid source/command prefix,
        # then each malformed financial admission must refuse without app imports.
        v4 = p.frozen()
        root = p.owner.ROOTS["candidate"].resolve()
        plan = {"variant": "candidate", "mode": "four-worker"}
        _, command = p.command(plan, root / "output/synthetic-discovery-only")
        packet = {"status": "passed", "source_unchanged": True, "owned_container_removed": True,
                  "source_commit": p.owner.COMMITS["candidate"], "source_commit_after": p.owner.COMMITS["candidate"],
                  "source_sha256": v4["sources"]["candidate"]["tracked_sha256"], "source_sha256_after": v4["sources"]["candidate"]["tracked_sha256"],
                  "harness_sha256": v4["harness_sha256"], "harness_sha256_after": v4["harness_sha256"],
                  "command": command, "runtime_root": str(root), "launch_cwd": str(root), "counts": [100], "workers": 4,
                  "repetitions": 3, "posting_warmup_cycles": 20, "max_seconds": 600, "snapshot_lines": 0, "image": p.owner.IMAGE,
                  "runtime_role_flags": [False, False], "cost_per_transaction": None, "seed": "enterprise-native-v1",
                  "profile": "native-three-human-cash-equity-v1", "revision": "0136_pg_inventory_scope", "postgres_version": "17.11",
                  "postgres_configuration": {name: "on" for name in ("fsync", "full_page_writes", "synchronous_commit")},
                  "posting": {"requested_cycles": 100, "admitted_cycles": 100, "completed_cycles": 100,
                              "completed_indices": list(range(100)), "error_count": 0, "not_admitted_cycles": 0,
                              "failed_cycles": [], "expected": dict.fromkeys(("debit_minor", "credit_minor", "cash_minor", "equity_minor"), "46669102"),
                              "ordered_effect_ids": [f"effect-{i}" for i in range(100)]}}
        for path, value in ((("workers",), 4.0), (("posting", "expected", "debit_minor"), "46669103"),
                            (("counts",), [100.0]), (("posting", "requested_cycles"), 100.0),
                            (("posting", "admitted_cycles"), 100.0), (("posting", "completed_cycles"), 100.0),
                            (("posting", "error_count"), False), (("posting", "not_admitted_cycles"), 0.0),
                            (("posting", "completed_indices"), list(range(99))), (("source_unchanged",), False),
                            (("owned_container_removed",), False), (("image",), "postgres:17.11-alpine"),
                            (("postgres_configuration", "fsync"), "off"), (("runtime_role_flags",), [False, True]),
                            (("posting", "ordered_effect_ids"), ["same"] * 100)):
            with self.subTest(path=path):
                modified = copy.deepcopy(packet)
                target = modified
                for key in path[:-1]:
                    target = target[key]
                target[path[-1]] = value
                with self.assertRaises(ValueError):
                    p.verify(modified, plan, command)

    def test_complete_plan_envelope_refuses_before_output_or_process(self) -> None:
        plan = p.owner.read(p.HERE / "four-worker-candidate-plan.json")
        plan["launcher_sha256"] = p.owner.sha(Path(p.__file__))
        p.validate_plan(plan)
        changes = (("schema_version", "other"), ("status", "passed"), ("variant", "unknown"), ("mode", "unknown"),
                   ("business_seconds", 600.0), ("child_seconds", 901), ("overall_seconds", True),
                   ("cleanup_reserve_seconds", 120.0), ("commit", p.owner.COMMITS["baseline"]),
                   ("source_sha256", "0" * 64), ("harness_sha256", "0" * 64), ("v4_readiness_sha256", "0" * 64),
                   ("quiet_window", "assumed"), ("no_workload_launched", 1), ("performance_comparison_accepted", 0),
                   ("created_at", "2026-10-12T00:00:00"), ("unknown_envelope_field", "value"))
        for key, value in changes:
            with self.subTest(key=key):
                malformed = {**plan, key: value}
                with patch.object(Path, "mkdir") as mkdir, patch.object(p.subprocess, "Popen") as popen:
                    with self.assertRaises(ValueError):
                        p.run(malformed, Path("C:/uncreated-synthetic-profile"))
                    mkdir.assert_not_called()
                    popen.assert_not_called()
        missing = {key: value for key, value in plan.items() if key != "source_sha256"}
        with self.assertRaises(ValueError):
            p.validate_plan(missing)

    def test_exact_read_and_warm_population_types(self) -> None:
        for name, value in (("count", 100.0), ("repetition", True), ("error_count", False),
                            ("requested_effects", 100.0), ("effects", 100.0)):
            with self.subTest(name=name), self.assertRaises(ValueError):
                p.exact_ints({name: value}, (name,))
        warm = {"status": "passed", "completed_cycles": 20, "indices": list(range(100, 120)),
                "outside_measured_population": True, "effect_ids": [f"warm-{i}" for i in range(20)]}
        p.validate_warm(warm, ["measured-effect"])
        for key, value in (("completed_cycles", 20.0), ("indices", [100.0, *range(101, 120)]),
                           ("outside_measured_population", 1)):
            with self.subTest(key=key), self.assertRaises(ValueError):
                p.validate_warm({**warm, key: value}, [])

    def test_profile_phase_indices_and_timing_are_exact(self) -> None:
        rows = [{"index": index, "phase": f"{stage}.{phase}", "failure_type": None, "seconds": .01,
                 "thread_cpu_seconds": .002}
                for index in range(120) for stage in ("prepare", "review", "post")
                for phase in ("identity_enter", "business", "transaction_exit")]
        p.validate_phases(rows)
        for key, value in (("index", 0.0), ("index", False), ("seconds", True), ("seconds", float("nan")),
                           ("seconds", float("inf")), ("thread_cpu_seconds", -.1)):
            with self.subTest(key=key, value=value), self.assertRaises(ValueError):
                p.validate_phases([{**rows[0], key: value}, *rows[1:]])

    def test_no_automatic_acceptance_or_unbounded_budget(self) -> None:
        self.assertEqual((p.BUSINESS_SECONDS, p.CHILD_SECONDS, p.OVERALL_SECONDS), (600, 900, 1200))
        self.assertGreaterEqual(p.OVERALL_SECONDS - p.CHILD_SECONDS, p.owner.CLEANUP_RESERVE)
        self.assertEqual(p.owner.CLEANUP_RESERVE, 120)


if __name__ == "__main__":
    unittest.main()
