"""Stdlib, file-only audit of a completed quiet2 discovery population.

Never imports ReconForge, calls a shell/network/database, or reads live counters.
Original profile/native files must have separately supplied raw SHA256 anchors.
This is descriptive instrumentation evidence, never performance acceptance.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path
import re
import statistics


COMMITS = {
    "baseline": "6362724f2337a79c3d7569574f7bf9591a018524",
    "candidate": "22ebfd78e293aafa13d81b3a0bbf287491951115",
}
REVISIONS = {
    "baseline": "0132_pg_stock_inverse_dispatch",
    "candidate": "0136_pg_inventory_scope",
}
IMAGE = "postgres:17.11-alpine@sha256:aa90e97ee862e558111d34cfb8b2c4bec768c2b039fb791341686928560263b3"
HARNESS = "7bce2382df24d439d39386f0e02c07bf362c4f451649dbd8d7f225c8a920396b"
HEX = re.compile(r"[0-9a-f]{64}\Z")
STAGES = ("prepare", "review", "post")
PHASES = ("identity_enter", "business", "transaction_exit")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON member")
        result[key] = value
    return result


def decode(raw):
    return json.loads(raw, object_pairs_hook=unique_object,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Nonfinite JSON")))


def numeric(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def close(left, right):
    return math.isclose(left, right, rel_tol=1e-10, abs_tol=1e-8)


def percentile(values, q):
    return sorted(values)[max(0, math.ceil(len(values) * q) - 1)]


def summarize_phases(rows):
    groups = defaultdict(list)
    for row in rows:
        groups[row["phase"]].append(row)
    return {
        phase: {
            "observations": len(group),
            "wall_seconds_sum": sum(row["seconds"] for row in group),
            "thread_cpu_seconds_sum": sum(row["thread_cpu_seconds"] for row in group),
            "wall_seconds_median": statistics.median(row["seconds"] for row in group),
        }
        for phase, group in sorted(groups.items())
    }


def audit(packet, profile_pin, native_pin):
    inputs = []
    raw_inputs = {}

    def read(relative, expected=None, raw_only=False):
        path = packet / relative
        raw = path.read_bytes()
        value_hash = digest(raw)
        if expected is not None:
            require(value_hash == expected, f"Original SHA256 differs: {relative}")
        inputs.append({"path": str(path.resolve()), "relative": relative, "bytes": len(raw), "sha256": value_hash})
        raw_inputs[path] = raw
        return raw if raw_only else decode(raw)

    parent = read("profile.json", profile_pin)
    native = read("native-profile/result.json", native_pin)
    origin = read("native-profile-origins.json", parent["origin_closure_sha256"])
    admission = read("native-profile-admission.json")
    ownership = read("native-profile-ownership.json")
    created = read("native-profile-ownership.created.json")
    crosscheck = read("native-profile-ownership.audit-crosscheck.json")
    # Retain raw-file fingerprints without copying or exposing log contents.
    read("native-profile/migration.log", raw_only=True)
    read("child.log", raw_only=True)
    require(parent["status"] == native["status"] == "passed", "Population is not complete")
    require(parent["child_exit_code"] == 0 and parent["performance_comparison_accepted"] is False,
            "Diagnostic failure or invalid comparison claim")
    require(parent["original_result_sha256"] == native_pin, "Native original pin differs")
    variant, mode = parent["variant"], parent["mode"]
    require(variant in COMMITS and mode in ("four-worker", "serial-cpu"), "Unknown profile variant/mode")
    plan = parent["plan"]
    require(plan["variant"] == variant and plan["mode"] == mode and plan["commit"] == COMMITS[variant]
            and plan["performance_comparison_accepted"] is False, "Original plan differs")
    require((plan["business_seconds"], plan["child_seconds"], plan["overall_seconds"], plan["cleanup_reserve_seconds"])
            == (600, 900, 1200, 120), "Time-budget contract differs")
    before, after = parent["source_before"], parent["source_after"]
    require(before == after and before["commit"] == COMMITS[variant]
            and before["clean_tracked"] is True and before["nonignored_untracked_empty"] is True,
            "Original before/after source does not close")
    require(native["source_commit"] == native["source_commit_after"] == COMMITS[variant]
            and native["source_sha256"] == native["source_sha256_after"] == before["tracked_sha256"] == plan["source_sha256"]
            and native["source_unchanged"] is True, "Native source custody differs")
    require(native["harness_sha256"] == native["harness_sha256_after"] == plan["harness_sha256"] == HARNESS,
            "Common harness fingerprint differs")
    require(native["command"] == parent["reported_harness_command"], "Reported actual native command differs")
    root = Path(before["runtime_root"]).resolve()
    require(Path(native["runtime_root"]).resolve() == Path(native["launch_cwd"]).resolve() == root
            and Path(origin["runtime_root"]).resolve() == root, "Runtime roots differ")
    require(native["revision"] == REVISIONS[variant] and native["image"] == IMAGE
            and native["postgres_version"].startswith("17.11"), "Actual database profile differs")
    require(native["runtime_role_flags"] == [False, False]
            and all(type(value) is bool for value in native["runtime_role_flags"]), "Native role is elevated")
    require(all(native["postgres_configuration"][key] == "on" for key in ("fsync", "full_page_writes", "synchronous_commit")),
            "Durability disabled")
    process = parent["process"]
    require(type(process["pid"]) is int and process["pid"] > 0
            and type(process["birth"]) is int and process["birth"] > 0, "Invalid native process identity")
    require(admission["process"] == process and admission["owned_job_assigned"] is True
            and ownership["process"] == created["process"] == crosscheck["process"] == origin["process"] == process,
            "Retained process/Job custody differs")
    require(parent["process_cleanup"]["identity"] == process
            and parent["process_cleanup"]["status"] == "already_exited"
            and parent["process_cleanup"]["forced"] is False, "Normal process cleanup differs")
    require(origin["status"] == "passed" and origin["foreign_modules"] == []
            and origin["harness_sha256_after"] == HARNESS, "Foreign or unclosed module origins")
    modules = origin["origins"]
    require(len({row["module"] for row in modules}) == len(modules), "Duplicate module origin")
    require(all(Path(row["path"]).resolve().is_relative_to(root) for row in modules), "Foreign origin root")
    required_modules = {"reconforge.auth.service", "reconforge.infrastructure.postgres_finance_core",
                        "reconforge.infrastructure.postgres_finance_posting", "reconforge.infrastructure.postgres"}
    require(required_modules <= {row["module"] for row in modules}, "Missing critical runtime origins")
    cleanup = parent["container_cleanup"]
    cid = created["container_id"]
    require(HEX.fullmatch(cid) is not None and created["returncode"] == 0
            and ownership["pre_spawn_exact_name_absent"] is True, "Creation acknowledgement differs")
    require(created["audit_sha256"] == cleanup["ownership_audit_sha256"] == digest(raw_inputs[packet / "native-profile-ownership.json"])
            and cleanup["creation_response_sha256"] == digest(raw_inputs[packet / "native-profile-ownership.created.json"])
            and cleanup["native_audit_crosscheck_sha256"] == digest(raw_inputs[packet / "native-profile-ownership.audit-crosscheck.json"]),
            "Original container custody seals differ")
    require(crosscheck["status"] == "matched" and crosscheck["audit_argument_form"] == "str"
            and crosscheck["original_typed_command_sha256"] == ownership["command_sha256"], "Windows audit crosscheck differs")
    bound = cleanup["bound_inspection"]
    require(cleanup["status"] == "verified_absent" and cleanup["container_id"] == bound["Id"] == cid
            and bound["Name"] == "/" + ownership["name"]
            and bound["Config"]["Image"] == ownership["image"] == IMAGE
            and bound["Config"]["Labels"] == {"reconforge.owner": "enterprise-finance-benchmark"}
            and native["owned_container_removed"] is True, "Acknowledged container or normal cleanup differs")
    require(datetime.fromisoformat(bound["Created"].replace("Z", "+00:00")) >= datetime.fromisoformat(ownership["observed_at"]),
            "Container predates original creation intent")
    posting = native["posting"]
    expected_count = 100
    require(native["counts"] == [expected_count] and native["workers"] == (4 if mode == "four-worker" else 1)
            and native["posting_warmup_cycles"] == 20 and native["repetitions"] == 3,
            "Population/worker contract differs")
    for key in ("requested_cycles", "admitted_cycles", "completed_cycles"):
        require(type(posting[key]) is int and posting[key] == expected_count, "Incomplete posting count")
    require(posting["error_count"] == posting["not_admitted_cycles"] == 0 and posting["failed_cycles"] == []
            and posting["completed_indices"] == list(range(100)), "Failed or missing posting population")
    expected_minor = str(sum(1 + int.from_bytes(hashlib.sha256(f"enterprise-native-v1:{index}".encode()).digest()[:8], "big") % 1000000
                             for index in range(100)))
    require(native["seed"] == "enterprise-native-v1" and expected_minor == "46669102"
            and posting["expected"] == dict.fromkeys(("debit_minor", "credit_minor", "cash_minor", "equity_minor"), expected_minor),
            "Independent integer financial oracle differs")
    effects, warm = posting["ordered_effect_ids"], native["posting_warmup"]
    require(len(effects) == len(set(effects)) == 100 and warm["indices"] == list(range(100, 120))
            and len(warm["effect_ids"]) == len(set(warm["effect_ids"])) == 20
            and not set(effects) & set(warm["effect_ids"]) and warm["outside_measured_population"] is True,
            "Warm and measured effects are not disjoint")
    latencies = posting["raw_cycle_latency_seconds"]
    require(len(latencies) == 100 and all(numeric(value) for value in latencies), "Invalid raw cycle latencies")
    require(close(posting["native_postings_per_second"], 100 / posting["seconds"])
            and close(posting["client_cpu_seconds_per_completed_cycle"], posting["client_process_cpu_seconds"] / 100),
            "Posting time/CPU arithmetic differs")
    for key, q in (("p50", .5), ("p95", .95), ("p99", .99)):
        require(close(posting["cycle_latency_seconds"][key], percentile(latencies, q)), "Raw posting percentile differs")
    reads = native["verified_reads"]
    require(len(reads) == 1 and reads[0]["status"] == "passed" and reads[0]["count"] == 100, "Incomplete verified reads")
    read_profile = reads[0]
    expected_population_hash = digest(json.dumps(effects, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode())
    require(read_profile["dataset_effect_ids_sha256"] == expected_population_hash, "Read effect population differs")
    read_count = 0
    for label, samples in read_profile["samples"].items():
        require(label in ("per_effect_baseline", "bounded_batch") and [row["repetition"] for row in samples] == [0, 1, 2],
                "Incomplete read modes/repetitions")
        for sample in samples:
            require(sample["status"] == "complete" and sample["error_count"] == 0
                    and sample["effects"] == sample["requested_effects"] == 100
                    and sample["debit_minor"] == sample["credit_minor"] == expected_minor
                    and sample["effects_digest"] == read_profile["financial_effects_digest"], "Read financial evidence differs")
            values = sample["raw_request_latency_seconds"]
            require(len(values) == (100 if label == "per_effect_baseline" else 1), "Read request count differs")
            read_count += len(values)
            for key, q in (("p50", .5), ("p95", .95), ("p99", .99)):
                require(close(sample["request_latency_seconds"][key], percentile(values, q)), "Read percentile differs")
    require(read_count == 303, "Measured read count differs")
    retained = native["posting_profile"]
    observations = retained["raw_phase_observations"]
    expected_keys = {(index, f"{stage}.{phase}") for index in range(120) for stage in STAGES for phase in PHASES}
    require(len(observations) == len(expected_keys) == 1080
            and {(row["index"], row["phase"]) for row in observations} == expected_keys
            and all(type(row["index"]) is int and row["failure_type"] is None
                    and numeric(row["seconds"]) and numeric(row["thread_cpu_seconds"]) for row in observations),
            "Invalid/missing/duplicate phase observations")
    measured = summarize_phases([row for row in observations if row["index"] < 100])
    warm_phases = summarize_phases([row for row in observations if row["index"] >= 100])
    all_phases = summarize_phases(observations)
    for phase, values in all_phases.items():
        original = retained["phase_totals"][phase]
        require(original["observations"] == values["observations"] and original["failures"] == 0
                and close(original["seconds"], values["wall_seconds_sum"])
                and close(original["thread_cpu_seconds"], values["thread_cpu_seconds_sum"]), "Original phase totals differ")
    for phase, values in measured.items():
        original = parent["verification"]["measured_phase_aggregates"][phase]
        require(original["observations"] == values["observations"]
                and all(close(original[name], values[name]) for name in ("wall_seconds_sum", "thread_cpu_seconds_sum", "wall_seconds_median")),
                "Original measured phase aggregates differ")
    cpu_by_family = {family: sum(row["thread_cpu_seconds_sum"] for key, row in measured.items() if key.endswith("." + family))
                     for family in PHASES}
    phase_cpu = sum(cpu_by_family.values())
    function_profile = retained["function_profile"]
    require(function_profile["enabled"] is (mode == "serial-cpu") and function_profile["cycle_ceiling"] == 32,
            "Function instrumentation mode differs")
    db_review = None
    if mode == "four-worker":
        require(function_profile["functions"] == [], "Unexpected four-worker CPU function profile")
        database = native["posting_database_profile"]
        statements = database["statements"]
        require(database["status"] == "complete" and database["row_ceiling"] == 200
                and 0 < len(statements) <= 200, "Invalid server statement capture")
        require(len({(row["query_id"], row["toplevel"]) for row in statements}) == len(statements), "Duplicate queryid/toplevel")
        for row in statements:
            require(type(row["toplevel"]) is bool and type(row["query_id"]) is str
                    and re.fullmatch(r"-?\d+", row["query_id"]) is not None
                    and HEX.fullmatch(row["statement_sha256"]) is not None
                    and type(row["calls"]) is int and row["calls"] >= 0,
                    "Invalid SQL identity/counter")
            require(all(numeric(row[key]) for key in ("total_plan_ms", "total_exec_ms", "shared_blk_read_ms", "shared_blk_write_ms")),
                    "Invalid server time counter")
        require(all(statements[i]["total_exec_ms"] >= statements[i + 1]["total_exec_ms"] for i in range(len(statements) - 1)),
                "Statement capture ordering differs")
        projection_keys = ("query_id", "toplevel", "statement_sha256", "code_family", "calls", "total_plan_ms", "total_exec_ms",
                           "shared_blks_hit", "shared_blks_read", "shared_blk_read_ms", "shared_blk_write_ms")
        strata = {}
        for toplevel in (True, False):
            rows = [row for row in statements if row["toplevel"] is toplevel]
            strata["top_level" if toplevel else "nested"] = {
                "retained_rows": len(rows), "retained_calls": sum(row["calls"] for row in rows),
                "retained_plan_ms_sum": sum(row["total_plan_ms"] for row in rows),
                "retained_exec_ms_sum": sum(row["total_exec_ms"] for row in rows),
                "scope": "Retained stratum only; nested/top-level sums never combined into total SQL or elapsed time.",
            }
        db_review = {
            "retained_row_count": len(statements), "row_ceiling": 200,
            "at_ceiling": len(statements) == 200, "complete_population_proven": False,
            "runtime_role_and_db_filter_source_verified": True,
            "capture_window": "Source resets all pg_stat_statements after20warm; reads before read benchmarks and after100measured posting/counter probes; filtered to runtime role+current DB.",
            "query_identity": "query_id+toplevel+statement_sha256; query text was never retained, so digest preimage is not independently recomputed here.",
            "planning": "track_planning=on in admitted original Docker command; total_plan_ms/calls is amortized per execution, not per plan because plans counter is not captured.",
            "strata": strata,
            "top_exec_rows": [{key: row[key] for key in projection_keys} for row in statements[:10]],
            "top_plan_rows": [{key: row[key] for key in projection_keys} for row in sorted(statements, key=lambda value: -value["total_plan_ms"])[:10]],
            "code_family_rows": dict(Counter(row["code_family"] for row in statements)),
            "lock_family_rows": [{key: row[key] for key in projection_keys} for row in statements if row["code_family"] == "transaction_advisory_lock"],
            "no_lock_wait_attribution": True,
        }
    else:
        require(function_profile["functions"], "Missing bounded serial function rows")
    # Selected small source files only; do not rescan large tracked trees during live profiling.
    source_observations = []
    source_names = ("reconforge/benchmark/server_query_profile.py", "reconforge/benchmark/enterprise_posting_profile.py")
    for name in source_names:
        path = root / name
        raw = path.read_bytes()
        source_observations.append({"path": str(path), "relative": name, "bytes": len(raw), "sha256": digest(raw)})
    controls = packet.parent
    for relative, expected in (("profile/profile_final22.py", plan["launcher_sha256"]), ("pair/readiness-v4.json", plan["v4_readiness_sha256"])):
        raw = (controls / relative).read_bytes()
        require(digest(raw) == expected, "Original control source differs")
        source_observations.append({"path": str(controls / relative), "relative": relative, "bytes": len(raw), "sha256": expected})
    query_source = (root / source_names[0]).read_text(encoding="utf-8")
    require("ORDER BY total_exec_time DESC,queryid LIMIT 200" in query_source
            and "WHERE userid=(SELECT oid FROM pg_roles WHERE rolname=%s)" in query_source
            and "AND dbid=(SELECT oid FROM pg_database WHERE datname=current_database())" in query_source,
            "Server profiler filtering/cap source changed")
    command = parent["reported_harness_command"]
    require("--profile-stages" in command and ("--profile-database" in command if mode == "four-worker" else "--profile-cpu" in command),
            "Actual requested diagnostic instrumentation differs")
    if mode == "four-worker":
        read_only_harness = Path(native["harness_path"])
        harness_raw = read_only_harness.read_bytes()
        require(digest(harness_raw) == HARNESS, "Original common harness bytes differ")
        harness_text = harness_raw.decode()
        require("pg_stat_statements.track_planning=on" in harness_text
                and harness_text.index('SELECT pg_stat_statements_reset()') < harness_text.index('posting_started =')
                and harness_text.index('query_profile(diagnostic,') < harness_text.index('for count in counts:'),
                "Original SQL window source differs")
        source_observations.append({"path": str(read_only_harness), "bytes": len(harness_raw), "sha256": HARNESS})
    require(all(path.read_bytes() == raw for path, raw in raw_inputs.items()), "Original input changed during file-only audit")
    return {
        "schema_version": "quiet2-file-only-discovery-review-v1", "status": "passed",
        "variant": variant, "mode": mode, "source_commit": COMMITS[variant],
        "original_reported_source_sha256": before["tracked_sha256"],
        "source_fingerprint_recomputed_in_this_audit": False,
        "source_before_after_internal_bindings": "exact; selected source bytes inspected; original full-tree fingerprint retained, no live tree scan",
        "original_inputs": inputs, "selected_source_files": source_observations,
        "native_process": process, "full_container_id": cid,
        "origin_modules": len(modules), "origin_foreign_count": 0,
        "normal_cleanup": {"process": "already_exited", "container": "verified_absent", "forced": False},
        "financial": {"measured_cycles": 100, "warmup_disjoint_cycles": 20, "independent_minor": expected_minor,
                      "measured_read_requests": read_count, "raw_native_line_export_available": False},
        "posting": {key: posting[key] for key in ("seconds", "native_postings_per_second", "client_process_cpu_seconds", "cycle_latency_seconds")},
        "phase_measured": measured, "phase_warmup": warm_phases,
        "measured_phase_cpu": {"by_family_seconds": cpu_by_family, "total_seconds": phase_cpu,
                               "identity_fraction": cpu_by_family["identity_enter"] / phase_cpu,
                               "process_minus_phase_thread_cpu_seconds": posting["client_process_cpu_seconds"] - phase_cpu},
        "function_profile": function_profile if mode == "serial-cpu" else {"enabled": False},
        "database_profile": db_review,
        "interpretation_limits": [
            "Instrumented discovery only; no fair comparison/performance/cost acceptance.",
            "Four-worker phase wall sums overlap across workers, and phase CPU excludes work outside those scopes.",
            "Identity-enter contains connection/scope/password verification/permission setup; four-worker phase timing does not isolate its cause.",
            "Client wall minus thread CPU is not a direct SQL, lock, network or I/O wait meter.",
            "pg_stat_statements nested and top-level durations overlap; execution time is not exclusively server CPU.",
            "Server statement hashes cannot identify full SQL or prove query plans; code families are source-defined coarse labels.",
            "Original native financial checks+independent integer/read arithmetic are retained; no new independent ledger export or SQL-bypass/isolation test.",
        ],
        "performance_comparison_accepted": False, "causal_root_cause_proven": False,
        "application_imports": False, "database_calls": False, "network_calls": False,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--packet", required=True, type=Path)
    parser.add_argument("--expected-profile-sha256", required=True)
    parser.add_argument("--expected-native-sha256", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    require(HEX.fullmatch(args.expected_profile_sha256) is not None and HEX.fullmatch(args.expected_native_sha256) is not None,
            "Raw anchors require exact SHA256")
    require(not args.output.exists(), "Fresh immutable output path required")
    report = audit(args.packet.resolve(), args.expected_profile_sha256, args.expected_native_sha256)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    raw = (json.dumps(report, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()
    with args.output.open("xb") as handle:
        handle.write(raw)
    print(json.dumps({"status": "passed", "output": str(args.output.resolve()), "bytes": len(raw), "sha256": digest(raw),
                      "variant": report["variant"], "mode": report["mode"], "performance_comparison_accepted": False}))


if __name__ == "__main__":
    main()
