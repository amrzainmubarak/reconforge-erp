"""New immutable flat-record capsule; completed quiet2 diagnostics only.

Only stdlib file reads plus one local read-only Git object batch. No Docker,
database, application imports, network, whole-source rescans or running V5 data.
"""
from __future__ import annotations

import hashlib
import io
import json
from pathlib import Path
import subprocess
import zipfile
import zlib


OWN = Path(__file__).resolve().parents[1]
ROOT = Path("C:/Users/LOQ/.codex/worktrees/reconforge-integration-wave5/reconforge-erp")
SOURCE = ROOT / "output/wave5-quiet2-discovery-20261012"
AUDITS = OWN / "output/wave5-quiet2-independent"
OUT = OWN / "output/wave5-quiet2-discovery-public-capsule-20261012-v1"
COMMITS = {"baseline": "6362724f2337a79c3d7569574f7bf9591a018524",
           "candidate": "22ebfd78e293aafa13d81b3a0bbf287491951115"}
AUDIT_PINS = {
    "baseline-four-r1": "ec115431c1e4e8db09c892c1923e58da21baf8a29a18368b7df4033f57e855fa",
    "candidate-four-r1": "a93cf5c9b5d460c54a29e368cb6b809949083df44bdb2ba15fbfe7edb258899f",
    "baseline-serial-r1": "b654f30e10931eda9e2548928cb8834d1a12e31bc201df2f63575dfd5711aa99",
    "candidate-serial-r1": "54cfd988b66da610a6c12fddd43626a92af38443d32a1b3e77d82ac6edcace0d",
}
SOURCE_PATHS = (
    "reconforge/benchmark/server_query_profile.py",
    "reconforge/benchmark/enterprise_posting_profile.py",
    "reconforge/auth/passwords.py",
    "reconforge/infrastructure/postgres_identity.py",
    "reconforge/infrastructure/postgres.py",
    "reconforge/infrastructure/postgres_finance_core.py",
    "reconforge/infrastructure/postgres_finance_posting.py",
    "reconforge/infrastructure/postgres_finance_scope.py",
    "tests/test_postgres_inventory_receipt_posting.py",
    "alembic/versions/0095_postgres_finance_scope.py",
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    raw = (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode()
    with path.open("xb") as handle:
        handle.write(raw)
    return raw


def main():
    require(not OUT.exists(), "Fresh immutable capsule directory required")
    OUT.mkdir()
    selected = []
    profiles = {}
    for population, expected in AUDIT_PINS.items():
        left = AUDITS / (population + "-I.json")
        right = AUDITS / (population + "-IO.json")
        require(sha(left.read_bytes()) == sha(right.read_bytes()) == expected, "Original normal/optimized audit differs")
        audit = json.loads(left.read_bytes())
        require(audit["status"] == "passed", "Incomplete independent audit")
        original = json.loads((SOURCE / population / "profile.json").read_bytes())
        profiles[population] = original
        variant = original["variant"]
        for path in sorted((SOURCE / population).rglob("*")):
            if path.is_file() and "__pycache__" not in path.parts:
                require(path.suffix in (".json", ".log"), "Unexpected runtime evidence file")
                selected.append((path, "original/" + path.relative_to(SOURCE).as_posix(), COMMITS[variant],
                                 "Completed original diagnostic; own actual runtime/source/PID/CID headers retained; not current publication-head performance acceptance."))
    for path in sorted(SOURCE.rglob("*")):
        if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        relative = path.relative_to(SOURCE)
        if relative.parts[0] in AUDIT_PINS:
            continue
        require(relative.parts[0] in ("pair", "profile") or len(relative.parts) == 1,
                "Unknown/nonfinal runtime directory; ongoing V5 data refused")
        selected.append((path, "original-controls/" + relative.as_posix(), None,
                         "Exact ignored quiet2 controller/preflight/relocation checkpoint; original preparation/smoke/development source headers govern attribution."))
    for path in sorted(AUDITS.glob("*.json")):
        selected.append((path, "independent/" + path.name, None,
                         "File-only stdlib audit/cross-source analysis; earlier three-population report retained separately from completed four-population report."))
    for name in ("audit_wave5_quiet2_discovery.py", "compare_wave5_quiet2_discovery.py", Path(__file__).name):
        selected.append((OWN / "output" / name, "read-only-tools/" + name, None,
                         "Exact stdlib evidence review/builder checkpoint; no application/DB/network/workload imports/calls."))
    require(sha((AUDITS / "cross-source-four-populations-I.json").read_bytes())
            == sha((AUDITS / "cross-source-four-populations-IO.json").read_bytes())
            == "c35aaf8d404b650ea414ae93e9bb2d946d057e36157efb42e2ffa85807064595", "Final cross-source closure differs")

    # Public Git blobs and physical bytes are different custody subjects. Capture
    # both; do not pretend selected files recompute the complete3912-file tree.
    object_directory = OUT / "source-originals"
    object_directory.mkdir()
    requests, subjects = [], []
    for variant, commit in COMMITS.items():
        root = Path(profiles[variant + "-four-r1"]["source_before"]["runtime_root"]).resolve()
        for path in SOURCE_PATHS:
            requests.append(f"{commit}:{path}")
            subjects.append((variant, commit, root, path))
    requests.append(COMMITS["candidate"] + ":.github/scripts/benchmark_enterprise_finance.py")
    subjects.append(("common-harness", COMMITS["candidate"], None, ".github/scripts/benchmark_enterprise_finance.py"))
    completed = subprocess.run(["git", "-C", str(OWN), "cat-file", "--batch"],
                               input=("\n".join(requests) + "\n").encode(), capture_output=True, timeout=15, check=False)
    require(completed.returncode == 0 and completed.stderr == b"", "Local immutable Git object read failed")
    position = 0
    source_records = []
    for ordinal, (variant, commit, root, relative) in enumerate(subjects, 1):
        end = completed.stdout.index(b"\n", position)
        header = completed.stdout[position:end].decode().split()
        require(len(header) == 3 and header[1] == "blob", "Unexpected immutable object type/header")
        count = int(header[2])
        raw = completed.stdout[end + 1:end + 1 + count]
        require(len(raw) == count and completed.stdout[end + 1 + count:end + 2 + count] == b"\n", "Truncated Git object")
        require(hashlib.sha1(b"blob " + str(count).encode() + b"\0" + raw).hexdigest() == header[0], "Git blob identity differs")
        position = end + 2 + count
        name = f"{ordinal:04d}-{variant}-{Path(relative).name}"
        target = object_directory / name
        target.write_bytes(raw)
        selected.append((target, "git-originals/" + name, commit, "Exact immutable public Git blob; SHA1 verified with original Git blob header and raw bytes."))
        record = {"source_commit": commit, "variant": variant, "relative": relative,
                  "git_blob_sha1": header[0], "git_bytes": count, "git_raw_sha256": sha(raw)}
        if root is not None:
            path = root / relative
            physical = path.read_bytes()
            capture = object_directory / (f"{ordinal:04d}-physical-" + variant + "-" + Path(relative).name)
            capture.write_bytes(physical)
            require(physical.replace(b"\r\n", b"\n") == raw.replace(b"\r\n", b"\n"), "Selected physical source differs from original Git semantics")
            record.update(physical_path=str(path), physical_bytes=len(physical), physical_sha256=sha(physical),
                          normalized_lf_equals_git=True)
            selected.append((capture, "physical-originals/" + capture.name, commit,
                             "Selected actual runtime physical bytes; LF-normalized equality to exact original Git blob verified. Not a live full-tree rescan."))
        else:
            require(sha(raw) == "7bce2382df24d439d39386f0e02c07bf362c4f451649dbd8d7f225c8a920396b", "Common immutable harness differs")
        source_records.append(record)
    require(position == len(completed.stdout), "Extra immutable Git object output")
    source_manifest = object_directory / "source-bindings.json"
    save(source_manifest, {"schema_version": "quiet2-selected-physical-git-source-bindings-v1",
                           "records": source_records, "full_tree_rescan_performed": False,
                           "original_complete_source_fingerprints": {
                               variant: profiles[variant + "-four-r1"]["source_before"] for variant in COMMITS},
                           "accepted_source_headers_preserved": True,
                           "publication_head_does_not_rebind_measurements": True})
    selected.append((source_manifest, "source-bindings.json", None, "Selected physical/Git source custody; original full-tree fingerprints retained unchanged."))
    prior_extension = OWN / "output/wave5-native10k-public-capsule-20261012-v1/capsule-index-extension-native10k-62-20261012-v1.json"
    require(sha(prior_extension.read_bytes()) == "0c1cfdb6775f3bb2a4f86cfeede046872100afb47fa9d399f2d21c0d2471e25e", "Existing10K extension was changed")
    selected.append((prior_extension, "reference-only/prior-native10k-extension.json", None,
                     "Original existing capsule reference index only; no earlier archives embedded or rewritten, no historical acceptance rebinding."))

    records, contents = [], []
    for path, name, commit, scope in sorted(selected, key=lambda value: value[1]):
        raw = path.read_bytes()
        require(path.suffix.lower() not in (".pem", ".key", ".p12", ".pfx", ".env", ".dump", ".sql"), "Excluded input type")
        require(len(raw) < 2_000_000, "Unexpected large input")
        require("paired1k-v5" not in str(path) and "quiet2-final22-paired" not in str(path), "Active V5 evidence is not admitted")
        records.append({"entry_name": name, "original_path": str(path), "bytes": len(raw), "sha256": sha(raw),
                        "source_commit": commit, "source_attribution": scope,
                        "raw_header_policy": "Original byte-exact headers and source scopes unchanged."})
        contents.append((name, raw))
    require(len({row["entry_name"] for row in records}) == len(records), "Duplicate member name")
    coverage = {"completed_populations": list(AUDIT_PINS), "measured_cycles_per_population": 100,
                "disjoint_warmup_per_population": 20, "measured_read_requests_per_population": 303,
                "independent_minor_total_per_population": "46669102", "baseline_source": COMMITS["baseline"],
                "candidate_source": COMMITS["candidate"], "same_common_harness_sha256": "7bce2382df24d439d39386f0e02c07bf362c4f451649dbd8d7f225c8a920396b",
                "same_current_pinned_database": "postgres:17.11-alpine@sha256:aa90e97ee862e558111d34cfb8b2c4bec768c2b039fb791341686928560263b3",
                "independent_normal_optimized_pairs": 4, "cross_source_final_normal_optimized_identical": True,
                "server_profile_rows": "200 capped rows in each four-worker population;182exactquery_id+toplevel+SHA shared; top-level/nested kept separate.",
                "serial_functions": "First32measuredcycles perstage;96PBKDF2calls perpopulation; cProfile self-wall distinct from thread/process CPU.",
                "source_query_mapping": "Four exact public AST constants reproduce native SQL hashes; full query text/parameters were not captured.",
                "source_custody": "Original reported full fingerprints preserved;21publicGitblobs+20selectedactualphysicalfiles captured with raw hashes and normalized equality; no live full-tree scan.",
                "raw_logs": "All four short child logs and synthetic migration logs included byte-exact; no credential/DSN setup logs.",
                "new_unprofiled_v5_pair_included": False, "native_line_exports_included": False,
                "performance_comparison_accepted": False, "causal_rls_planner_root_cause_proven": False,
                "optimization_implemented_or_integrated": False}
    name = "wave5-quiet2-discovery-636-22-fourprofiles-v1.zip"
    manifest = {"schema_version": "reconforge-byte-exact-evidence-capsule-v1", "name": name,
                "capture_for_root_commit": COMMITS["candidate"],
                "acceptance_scope": "Original per-entry source headers govern; ignored diagnostic control bytes have no publication-commit attribution.",
                "coverage": coverage, "construction": {"compression": "ZIP_DEFLATED", "level": 1,
                    "date_time": [1980, 1, 1, 0, 0, 0], "unix_file_mode": "100644", "entries": "lexically sorted",
                    "zlib_version": zlib.ZLIB_VERSION, "json_index": "flat record list; no filename-to-hash dictionary"},
                "file_count": len(records), "raw_bytes": sum(row["bytes"] for row in records), "records": records}
    manifest_raw = (json.dumps(manifest, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode()
    contents.append(("capsule-manifest.json", manifest_raw))
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w") as archive:
        archive.comment = b""
        for name, raw in sorted(contents):
            info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            info.create_system, info.create_version, info.extract_version = 3, 20, 20
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            info.internal_attr = 0
            info.extra = info.comment = b""
            archive.writestr(info, raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=1)
    rawzip = stream.getvalue()
    with zipfile.ZipFile(io.BytesIO(rawzip)) as archive:
        require(set(archive.namelist()) == {name for name, _ in contents} and archive.testzip() is None, "ZIP member closure differs")
        require(all(archive.read(name) == raw for name, raw in contents), "ZIP transport changed an original")
    require(all(Path(row["original_path"]).read_bytes() == raw for row, (_, raw) in zip(records, contents[:-1], strict=True)),
            "Selected original input changed during assembly")
    target = OUT / manifest["name"]
    target.write_bytes(rawzip)
    index = target.with_suffix(".index.json")
    index.write_bytes(manifest_raw)
    record = {"file_name": target.name, "bytes": len(rawzip), "sha256": sha(rawzip),
              "file_count": len(records), "raw_bytes": manifest["raw_bytes"],
              "index_name": index.name, "index_sha256": sha(manifest_raw), "coverage": coverage}
    extension = OUT / "capsule-index-extension-quiet2-discovery-20261012-v1.json"
    extension_raw = save(extension, {"schema_version": "reconforge-flat-evidence-capsule-extension-v1",
                                     "original_runtime_sources": list(COMMITS.values()), "capsules": [record],
                                     "previous_native10k_extension_sha256": sha(prior_extension.read_bytes()),
                                     "previous_capsules_rewritten": False, "new_unprofiled_v5_pair_included": False,
                                     "performance_comparison_accepted": False})
    print(json.dumps({"directory": str(OUT), "capsule": record, "extension_index": extension.name,
                      "extension_index_sha256": sha(extension_raw)}, indent=2))


if __name__ == "__main__":
    main()
