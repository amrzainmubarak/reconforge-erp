"""File-only descriptive comparison of separately pinned quiet2 audit reports."""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
from pathlib import Path
import re


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load(path, expected):
    raw = path.read_bytes()
    require(sha(raw) == expected, "Trusted audit input differs")
    return json.loads(raw), {"path": str(path.resolve()), "bytes": len(raw), "sha256": expected}


def normalized_constant(value):
    """Only reproduce these public constant queries; no general SQL parser claim."""
    parameter_count = value.count("%s")
    parameters = iter(range(1, parameter_count + 1))
    result = re.sub(r"%s", lambda _: "$" + str(next(parameters)), value)
    literals = iter(range(parameter_count + 1, 1000))
    result = re.sub(r"(?<![\w$])(?:[0-9]+|\x27(?:[^\x27]|\x27\x27)*\x27)(?![\w])",
                    lambda _: "$" + str(next(literals)), result)
    return sha(result.encode())


def compare(paths):
    reports, inputs, natives = {}, [], {}
    for name, path, pin in paths:
        report, record = load(path, pin)
        require(report["status"] == "passed" and report["performance_comparison_accepted"] is False,
                "Unaccepted original audit")
        require(name not in reports, "Duplicate population name")
        reports[name] = report
        inputs.append(record)
        raw_reference = next(row for row in report["original_inputs"] if row["relative"] == "native-profile/result.json")
        native, original = load(Path(raw_reference["path"]), raw_reference["sha256"])
        inputs.append(original)
        natives[name] = native
    require({"baseline-four-r1", "candidate-four-r1"} <= set(reports), "Both completed four-worker populations required")
    baseline = natives["baseline-four-r1"]["posting_database_profile"]["statements"]
    candidate = natives["candidate-four-r1"]["posting_database_profile"]["statements"]
    key = lambda row: (row["query_id"], row["toplevel"], row["statement_sha256"])
    bmap, cmap = {key(row): row for row in baseline}, {key(row): row for row in candidate}
    common = bmap.keys() & cmap.keys()
    require(len(bmap) == len(baseline) and len(cmap) == len(candidate), "Duplicate server row identity")
    metrics = ("calls", "total_plan_ms", "total_exec_ms", "shared_blks_hit", "shared_blks_read",
               "shared_blk_read_ms", "shared_blk_write_ms")
    matched = []
    for identity in sorted(common):
        values = {}
        for label, mapping in (("baseline", bmap), ("candidate", cmap)):
            row = mapping[identity]
            values[label] = {name: row[name] for name in metrics}
            values[label]["amortized_plan_ms_per_call"] = row["total_plan_ms"] / row["calls"] if row["calls"] else None
            values[label]["exec_ms_per_call"] = row["total_exec_ms"] / row["calls"] if row["calls"] else None
        matched.append({"query_id": identity[0], "toplevel": identity[1], "statement_sha256": identity[2],
                        "code_family": cmap[identity]["code_family"], **values})
    wanted = {
        "81f9d84dd85691ce6ee15feb824c92b6fac8b7a4fa5ed9b00ee4c6274379a479",
        "8d92b3829aedb1318c972d7ba07729f92786d942195e798f5838a421cf1abf4e",
        "d474aac4353ef3bab82c720ec1f8e86aea25e5e65b7927a6e5a6352a123c0ac3",
        "90ee9f89ab18e59fcd15a5d171ccb963f1ffb786945dd9353fe07f52aa95bba6",
        "467f78f5cc69efd33b31cb6420b7c6b11acd092af6cae0ac44fe2a97aab1066c",
    }
    hot_rows = [row for row in matched if row["statement_sha256"] in wanted]
    require(len(hot_rows) == len(wanted) and all(row["toplevel"] is True for row in hot_rows), "Missing exact shared hot query")
    root = Path(natives["candidate-four-r1"]["runtime_root"]).resolve()
    mappings = []
    for filename, line, expected in (
        ("reconforge/infrastructure/postgres_finance_posting.py", 73,
         "81f9d84dd85691ce6ee15feb824c92b6fac8b7a4fa5ed9b00ee4c6274379a479"),
        ("reconforge/infrastructure/postgres_finance_core.py", 1704,
         "8d92b3829aedb1318c972d7ba07729f92786d942195e798f5838a421cf1abf4e"),
        ("reconforge/infrastructure/postgres_finance_core.py", 1693,
         "467f78f5cc69efd33b31cb6420b7c6b11acd092af6cae0ac44fe2a97aab1066c"),
        ("reconforge/infrastructure/postgres_finance_core.py", 1520,
         "90ee9f89ab18e59fcd15a5d171ccb963f1ffb786945dd9353fe07f52aa95bba6"),
    ):
        raw = (root / filename).read_bytes()
        constants = [node for node in ast.walk(ast.parse(raw)) if isinstance(node, ast.Constant)
                     and isinstance(node.value, str) and node.lineno == line]
        require(len(constants) == 1 and normalized_constant(constants[0].value) == expected,
                "Public constant does not reproduce the exact native SQL SHA")
        mappings.append({"path": str(root / filename), "line": line, "source_sha256": sha(raw),
                         "template_sha256": sha(constants[0].value.encode()), "native_statement_sha256": expected,
                         "method": "AST constant only; positional %s parameters and literal numbering reproduce this exact retained native SHA; no SQL execution"})
    serial = {}
    for name, report in reports.items():
        if report["mode"] != "serial-cpu":
            continue
        functions = report["function_profile"]["functions"]
        groups = {}
        for label, exact_function in (("pbkdf2_hmac", "<built-in method _hashlib.pbkdf2_hmac>"),
                                      ("select_select", "<built-in method select.select>")):
            rows = [row for row in functions if row["function"] == exact_function]
            require({row["phase"] for row in rows} == {"prepare", "review", "post"}, "Missing bounded serial function attribution")
            if label == "pbkdf2_hmac":
                require(all(row["calls"] == row["primitive_calls"] == 32 for row in rows), "PBKDF2 bounded call population differs")
            groups[label] = {
                "calls": sum(row["calls"] for row in rows),
                "self_wall_seconds_sum": sum(row["self_seconds"] for row in rows),
                "per_phase": [{key: row[key] for key in ("phase", "calls", "self_seconds", "cumulative_seconds")} for row in rows],
            }
        serial[name] = {"profiled_measured_cycle_ceiling": 32, "posting": report["posting"],
                        "measured_phase_cpu": report["measured_phase_cpu"], "functions": groups,
                        "timer_limit": "cProfile uses wall clock; self durations are not process CPU or isolated network/SQL/lock waits; nested cumulative rows are not summed."}
    return {
        "schema_version": "quiet2-descriptive-cross-source-review-v1", "status": "passed",
        "inputs": inputs, "exact_source_query_mappings": mappings,
        "population_headers": {name: {key: report[key] for key in ("source_commit", "original_reported_source_sha256", "mode", "financial", "normal_cleanup", "posting", "measured_phase_cpu")}
                               for name, report in sorted(reports.items())},
        "shared_server_statement_identity": "query_id+toplevel+statement_sha256",
        "shared_server_rows": len(common), "baseline_only_retained_rows": len(bmap.keys() - cmap.keys()),
        "candidate_only_retained_rows": len(cmap.keys() - bmap.keys()),
        "shared_hot_rows": hot_rows, "all_shared_rows": matched,
        "bounded_serial_functions": serial,
        "findings": [
            "Both four-worker variants spend over93% of recorded measured phase-thread CPU in identity entry; this is common to both source heads.",
            "Shared posting_snapshot and invalid-dimension queries have closely similar planner-heavy counters across B and C; this does not attribute new overhead to Wave5.",
            "Bounded serial profiles observe32 PBKDF2 calls per actor phase,96 total; PBKDF2 self-wall and select.select self-wall are separate function categories.",
            "The original ReceiptRuntime actor opens a fresh identity connection and a fresh scoped business connection for every actor; connection-local auto-prepare reuse is not established by these packets.",
            "The0095 restrictive RLS hierarchy expands dimension→line→entry→reference subqueries; it is a source-grounded optimization hypothesis, not a measured plan-tree attribution.",
        ],
        "future_candidate_contract": [
            "Before changing queries/policies, capture plans counter and selected actual-role EXPLAIN planning/plan trees using synthetic arguments; preserve SQL privacy and separate top-level/nested windows.",
            "A non-inlineable STABLE SECURITY INVOKER scope predicate may reduce planner expansion, but must retain every nested visibility condition, current GUC semantics, FORCE RLS, permissions and null denial; never mark it IMMUTABLE or use a privileged bypass.",
            "Prepared-statement or safe connection reuse must be measured on actual actor lifetimes with generic/custom plans and changing tenant/entity/GUC/role permissions; no cached financial authority or password iteration reduction.",
            "Any candidate requires direct SQL bypass attempts, authority revocation, OLD/NEW inverse ownership, concurrency, migration/catalog/ACL parity and populated restore before performance acceptance.",
        ],
        "limits": [
            "Each discovery variant/mode has one completed population here; no three-run fair performance acceptance.",
            "SQL capture reaches200rows each; unmatched retained rows are not proof that a query was absent, newly introduced or removed.",
            "Never combine top-level+nested SQL sums into elapsed time, total server CPU or whole-host ERP CPU.",
            "Observed Windows phase CPU increments are15.625ms; very small or zero phase CPU values are quantized counters.",
            "Source mappings cover only exact constant queries whose reproduced SHA matches; other coarse families remain unidentified.",
        ],
        "performance_comparison_accepted": False,
        "causal_rls_planner_root_cause_proven": False,
        "optimization_implemented_or_integrated": False,
        "network_database_or_application_calls": False,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--audited-report", action="append", required=True, help="name|absolute path|SHA256")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), "Fresh immutable report path required")
    paths = []
    for spec in args.audited_report:
        name, path, pin = spec.split("|")
        require(re.fullmatch(r"[0-9a-f]{64}", pin) is not None, "Invalid trusted SHA")
        paths.append((name, Path(path), pin))
    report = compare(paths)
    raw = (json.dumps(report, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("xb") as handle:
        handle.write(raw)
    print(json.dumps({"status": "passed", "path": str(args.output.resolve()), "bytes": len(raw), "sha256": sha(raw),
                      "populations": len(paths), "performance_comparison_accepted": False}))


if __name__ == "__main__":
    main()
