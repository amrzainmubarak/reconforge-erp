"""Exact terminal NEGATIVE V5 closure, stdlib and retained files only.

Never executes the six-complete comparator, apps, database, Docker or network.
Three complete children and one aborted child remain distinct evidence subjects.
"""
from __future__ import annotations

import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import types


OWNER = "3135177c777cf2e6023630551f212e4781e851cf06529fa9f2e81cd8e1133818"
PARTIAL = "2869d101a5eca762c3817a677791ab277c977234ae61a6eb9e804b74cc3afe7a"
READY = "7b904ff39d3db18634b581e83dde73d928d1e9d8783466749f9e42e3fbff33ca"
HARNESS = "7bce2382df24d439d39386f0e02c07bf362c4f451649dbd8d7f225c8a920396b"
VERIFIER = "b09575672dd79997e42afb1ade898a6e7b2448af3674ec5fc746f0120c167e58"
ORDER = [(1, "baseline"), (1, "candidate"), (2, "candidate"), (2, "baseline")]
HISTORICAL_SOURCE = "cf9a1280d9a3138ca6e908708fd393ec75268fa198140c070098aa3056723652"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON member")
        result[key] = value
    return result


def decode(raw):
    return json.loads(raw, object_pairs_hook=unique,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Nonfinite JSON")))


def integer_oracle(count):
    return str(sum(1 + int.from_bytes(hashlib.sha256(f"enterprise-native-v1:{index}".encode()).digest()[:8], "big") % 1_000_000
                   for index in range(count)))


def audit(packet, controls):
    records, captured = [], {}

    def read(path, expected=None, raw_only=False):
        raw = path.read_bytes()
        actual = sha(raw)
        require(expected is None or actual == expected, "Original raw input differs")
        records.append({"path": str(path.resolve()), "bytes": len(raw), "sha256": actual})
        captured[path] = raw
        return raw if raw_only else decode(raw)

    def reference(relative, expected=None):
        require(type(relative) is str and relative and ":" not in relative and "\\" not in relative
                and ".." not in Path(relative).parts, "Unsafe original evidence reference")
        path = (packet / relative).resolve()
        require(path.is_relative_to(packet.resolve()), "Original reference escapes")
        return read(path, expected)

    owner = read(packet / "pair.json", OWNER)
    ready = read(controls / "readiness-v4.json", READY)
    require(owner["status"] == "failed" and owner["performance_comparison_accepted"] is False
            and owner["financial_verification"] == "not_accepted_complete_population"
            and owner["observed_environment_verification"] == "not_accepted_complete_population",
            "Negative terminal owner was relabeled")
    require(owner["commits"] == ready["commits"] and owner["pairs"] == 3 and owner["count"] == 1000
            and [(row["repetition"], row["variant"]) for row in owner["runs"]] == ORDER,
            "Original four-attempt ordering differs")
    require(owner["failure_type"] == "ValueError" and owner["failure"] == "Observed AC/saver-off required"
            and owner["primary_child_failure"] == {"type": "ValueError", "failure": "Observed AC/saver-off required"},
            "Original primary power refusal differs")
    require(ready["sources"]["candidate"]["tracked_sha256"] == "dfdf4296eb27e088ae91790af2d2d280880fb70e4edb151e50f2b9f2940a4535"
            and ready["harness_sha256"] == HARNESS, "Current relocated source/harness differs")
    for relative, expected in ready["tool_sha256"].items():
        read(controls / relative, expected, raw_only=True)
    verifier_raw = captured[controls / "original-verifiers/verify_native_posting_pair.py"]
    require(sha(verifier_raw) == VERIFIER, "Retained stdlib financial oracle source differs")
    module = types.ModuleType("v5_negative_retained_financial_verifier")
    module.__file__ = str(controls / "original-verifiers/verify_native_posting_pair.py")
    exec(compile(verifier_raw, module.__file__, "exec"), module.__dict__)
    require(integer_oracle(100) == "46669102" and integer_oracle(1000) == "493671004", "Independent integer oracle differs")
    harness_raw = read(Path(ready["harness_path"]), HARNESS, raw_only=True)
    require(len(harness_raw) > 1000, "Missing common original harness")
    positive, aborted, cids, effects = [], None, set(), set()
    for ordinal, row in enumerate(owner["runs"]):
        repetition, variant = ORDER[ordinal]
        label = f"{repetition}-{variant}"
        expected_raw = row["report_sha256"] if ordinal < 3 else row["retained_raw_report_sha256"]
        require(ordinal < 3 or expected_raw == PARTIAL, "Wrong retained aborted native input")
        native = reference(row["report"], expected_raw)
        require(native["source_commit"] == ready["commits"][variant]
                and native["source_sha256"] == ready["sources"][variant]["tracked_sha256"]
                and native["harness_sha256"] == HARNESS and native["command"] == row["reported_harness_command"],
                "Original runtime source/harness/command differs")
        require(native["revision"] == ("0132_pg_stock_inverse_dispatch" if variant == "baseline" else "0136_pg_inventory_scope")
                and native["image"] == ready["image"] and native["postgres_version"].startswith("17.11")
                and native["runtime_role_flags"] == [False, False]
                and all(type(value) is bool for value in native["runtime_role_flags"]), "Native revision/image/role differs")
        require(native["posting_profile"]["enabled"] is False and native["posting_profile"]["raw_phase_observations"] == [],
                "Diagnostic instrumentation mixed into V5")
        process, cleanup = row["process"], row["cleanup"]
        owned = reference(label + "-ownership.json", cleanup["ownership_audit_sha256"])
        created = reference(label + "-ownership.created.json", cleanup["creation_response_sha256"])
        crosscheck = reference(label + "-ownership.audit-crosscheck.json", cleanup["native_audit_crosscheck_sha256"])
        admission = reference(label + "-admission.json")
        require(process == owned["process"] == created["process"] == crosscheck["process"] == admission["process"]
                and admission["owned_job_assigned"] is True
                and type(process["pid"]) is int and process["pid"] > 0
                and type(process["birth"]) is int and process["birth"] > 0
                and Path(process["executable"]).resolve() == Path(ready["physical_python_path"]).resolve(),
                "Captured physical PID/birth/Job custody differs")
        cid = cleanup["container_id"]
        inspection = cleanup["bound_inspection"]
        require(re.fullmatch(r"[0-9a-f]{64}", cid) is not None and cid not in cids
                and cid == created["container_id"] == inspection["Id"] and created["returncode"] == 0
                and created["audit_sha256"] == cleanup["ownership_audit_sha256"], "Exact acknowledged CID differs")
        cids.add(cid)
        require(owned["pre_spawn_exact_name_absent"] is True and owned["label"] == "reconforge.owner=enterprise-finance-benchmark"
                and inspection["Name"] == "/" + owned["name"]
                and owned["image"] == inspection["Config"]["Image"] == ready["image"]
                and inspection["Config"]["Labels"] == {"reconforge.owner": "enterprise-finance-benchmark"}, "Exact creation context differs")
        require(datetime.fromisoformat(inspection["Created"]) >= datetime.fromisoformat(owned["observed_at"]),
                "Captured container predates original intent")
        require(crosscheck["status"] == "matched" and crosscheck["audit_argument_form"] == "str"
                and crosscheck["original_typed_command_sha256"] == owned["command_sha256"], "Windows typed-command audit differs")
        require(cleanup["status"] == "verified_absent" and cleanup["action"] == "already_absent"
                and row["process_cleanup"]["forced"] is False and row["process_cleanup"]["identity"] == process,
                "Captured exact process/container cleanup differs")
        warm = native["posting_warmup"]
        require(warm["completed_cycles"] == 20 and warm["indices"] == list(range(1000, 1020))
                and warm["outside_measured_population"] is True, "Original warm population differs")
        if ordinal < 3:
            require(row["child_exit_code"] == 0 and row["financial_verification"] == "passed"
                    and row["process_cleanup"]["status"] == "already_exited", "Positive child not complete")
            financial = module.validate_measurement(native, ready["commits"][variant])
            require(native["source_sha256_after"] == native["source_sha256"] and native["harness_sha256_after"] == HARNESS,
                    "Completed source closure differs")
            origins = reference(row["origins"]["path"], row["origins"]["sha256"])
            root = Path(ready["sources"][variant]["runtime_root"]).resolve()
            require(origins["status"] == "passed" and origins["foreign_modules"] == [] and origins["process"] == process
                    and origins["harness_sha256_after"] == HARNESS
                    and all(Path(entry["path"]).resolve().is_relative_to(root) for entry in origins["origins"]), "Completed origin closure differs")
            for phase in ("before", "after"):
                sidecar = reference(row["environment_" + phase]["path"], row["environment_" + phase]["sha256"])
                require(sidecar["power"]["status"] == "available" and sidecar["power"]["ac_online"] is True
                        and sidecar["power"]["battery_saver_on"] is False, "Completed child power bookend differs")
            population = set(native["posting"]["ordered_effect_ids"]) | set(warm["effect_ids"])
            require(len(population) == 1020 and not population & effects, "Completed fresh native populations overlap")
            effects.update(population)
            positive.append({"run": label, "status": "passed_completed_child_only", "native_raw_sha256": expected_raw,
                             "source_commit": native["source_commit"], "source_sha256": native["source_sha256"],
                             "measured_cycles": financial["posting_cycles"], "warmup_disjoint_cycles": 20,
                             "measured_read_requests": financial["measured_read_requests"],
                             "verified_effect_visits": financial["verified_effect_visits"], "independent_minor_total": integer_oracle(1000),
                             "full_container_id": cid, "process": process, "cleanup": "normal_exited_and_exact_CID_absent"})
        else:
            require(native["status"] == "failed" and row["child_exit_code"] is None
                    and row["process_cleanup"]["status"] == "gracefully_stopped"
                    and row["primary_child_failure"] == owner["primary_child_failure"], "Aborted child was relabeled")
            require(not any(field in native for field in ("source_commit_after", "source_sha256_after", "source_unchanged")),
                    "Aborted source closure label differs")
            posting = native["posting"]
            require(all(type(posting[key]) is int for key in ("requested_cycles", "admitted_cycles", "completed_cycles", "error_count", "not_admitted_cycles"))
                    and posting["requested_cycles"] == posting["admitted_cycles"] == posting["completed_cycles"] == 1000
                    and posting["error_count"] == posting["not_admitted_cycles"] == 0
                    and posting["completed_indices"] == list(range(1000)), "Aborted posting metadata differs")
            rejected = False
            try:
                module.validate_measurement(native, ready["commits"][variant])
            except module.VerificationError:
                rejected = True
            require(rejected, "Partial native packet incorrectly accepted by complete verifier")
            summaries, requests, visits, failed_attempts = [], 0, 0, 0
            for profile in native["verified_reads"]:
                for mode, samples in profile["samples"].items():
                    for sample in samples:
                        durations = len(sample["raw_request_latency_seconds"])
                        requests += durations
                        visits += sample["effects"]
                        failed_attempts += int("failed_request" in sample)
                        summaries.append({"prefix": profile["count"], "prefix_status": profile["status"], "mode": mode,
                                          "repetition": sample["repetition"], "status": sample["status"],
                                          "successful_request_durations": durations, "verified_effects": sample["effects"],
                                          "failed_request_present": "failed_request" in sample})
            require(requests == 2489 and visits == 4766 and failed_attempts == 1
                    and [profile["status"] for profile in native["verified_reads"]] == ["passed", "failed"], "Exact aborted read population differs")
            failure = native["failure"]
            require(failure.startswith("OutOfOrderTransactionNesting:") and "password" not in failure.lower()
                    and re.search(r"[a-z][a-z0-9+.-]*://", failure, re.I) is None, "Unexpected secondary error/credential content")
            require(re.search(r"host=127\.0\.0\.1 port=\d+ user=enterprise_benchmark database=postgres", failure) is not None,
                    "Secondary connection repr is not known owned synthetic context")
            stopped = reference(row["environment_after_failure"]["path"], row["environment_after_failure"]["sha256"])
            require(stopped["power"]["ac_online"] is False, "Original stopped power bookend differs")
            aborted = {"run": label, "status": "failed_aborted_not_complete_financial_acceptance", "native_raw_sha256": PARTIAL,
                       "reported_posting_requested_admitted_completed": [1000, 1000, 1000], "reported_posting_error_count": 0,
                       "reported_warmup_completed": 20, "successful_request_latency_entries": requests,
                       "retained_failed_request_attempts": failed_attempts, "verified_effect_visits_retained": visits,
                       "read_samples": summaries, "full_read_population_3333_complete": False,
                       "source_after_and_source_unchanged_fields_present": False,
                       "complete_native_verifier_refused_partial": True,
                       "secondary_native_exception_type": "OutOfOrderTransactionNesting",
                       "secondary_error_privacy": "Original raw has owned synthetic loopback/user/port/database repr; no password, authentication material or URI DSN. Not a private/customer setup log.",
                       "secondary_error_cause_proven": False,
                       "full_container_id": cid, "process": process, "cleanup": "gracefully_stopped_without_force_and_exact_CID_absent"}
    bad_power = [value for value in owner["runs"][-1]["host_load_observations"]
                 if value["power"].get("ac_online") is not True or value["power"].get("battery_saver_on") is not False]
    require(len(bad_power) == 1 and bad_power[0]["observed_at"] == "2026-10-12T15:32:48.230589+00:00"
            and bad_power[0]["power"]["raw"]["ac"] == 0 and bad_power[0]["power"]["raw"]["percent"] == 98
            and bad_power[0]["power"]["ac_online"] is False and bad_power[0]["power"]["battery_saver_on"] is False,
            "Exact raw power interruption differs")
    require(len(positive) == 3 and len(cids) == 4 and len(effects) == 3060,
            "Three-positive/four-custody closure differs")
    require(not (packet / "manifest.json").exists() and not (packet / "offline-proof.json").exists(),
            "Unexpected six-complete acceptance artifacts")
    require(all(path.read_bytes() == raw for path, raw in captured.items()), "Original changed during file-only audit")
    return {"schema_version": "wave5-v5-negative-terminal-independent-v1", "status": "passed_negative_closure",
            "owner_status": "failed", "owner_original_sha256": OWNER, "readiness_sha256": READY,
            "common_harness_sha256": HARNESS, "current_source_bindings": ready["sources"],
            "historical_v4_candidate_full_source_sha256": HISTORICAL_SOURCE,
            "old_cf9_and_new_dfdf_populations_combined": False,
            "primary_failure": owner["primary_child_failure"], "failed_power_observation": bad_power[0],
            "owner_wall_seconds": owner["wall_seconds"], "completed_positive_children": positive, "aborted_child": aborted,
            "unperformed_children": ["3-baseline", "3-candidate"], "complete_six_run_population": False,
            "six_complete_comparator_or_replay_executed": False, "comparative_medians_computed": False,
            "all_four_acknowledged_container_cleanup_closed": True, "financial_benchmark_acceptance": False,
            "performance_comparison_accepted": False, "RPO_RTO_claimed": False,
            "original_input_records": records, "application_database_docker_network_calls": False,
            "limits": ["Three original complete child validations do not satisfy three populations per source.",
                       "Aborted B2 posting counters report1000 completed, but its read/source/owner-power completion contracts failed; it is not accepted as a full financial population.",
                       "Primary cause is observed AC loss; secondary read transaction error is retained without a proven causal diagnosis or financial-corruption inference.",
                       "Exact process/container cleanup is subsequent owned-lifecycle closure, not backup/restore or recovery timing evidence.",
                       "No independent original ledger-row export is added by this file-only arithmetic/source custody audit."]}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--packet", type=Path, required=True)
    parser.add_argument("--controls", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), "Fresh immutable negative output required")
    report = audit(args.packet.resolve(), args.controls.resolve())
    raw = (json.dumps(report, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("xb") as stream:
        stream.write(raw)
    print(json.dumps({"status": report["status"], "path": str(args.output.resolve()), "bytes": len(raw), "sha256": sha(raw),
                      "completed_children": 3, "aborted_children": 1, "unperformed_children": 2,
                      "performance_comparison_accepted": False}))


if __name__ == "__main__":
    main()
