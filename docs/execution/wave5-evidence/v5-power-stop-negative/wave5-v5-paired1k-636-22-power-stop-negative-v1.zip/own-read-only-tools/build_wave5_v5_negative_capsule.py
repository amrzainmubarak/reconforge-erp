"""Fresh lossless V5 negative capsule; no comparator, workloads or network."""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import re


OWN = Path(__file__).resolve().parents[1]
ROOT = Path("C:/Users/LOQ/.codex/worktrees/reconforge-integration-wave5/reconforge-erp")
PEER = Path("C:/Users/LOQ/.codex/worktrees/reconforge-manufacturing-wave5/reconforge-erp")
PACKET = ROOT / "output/wave5-quiet2-final22-paired1k-v5-20261012"
CONTROLS = ROOT / "output/wave5-quiet2-discovery-20261012"
PROOFS = OWN / "output/wave5-v5-negative-independent"
OUT = OWN / "output/wave5-v5-power-negative-public-capsule-20261012-v1"
CURRENT = "22ebfd78e293aafa13d81b3a0bbf287491951115"
BASELINE = "6362724f2337a79c3d7569574f7bf9591a018524"


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    require(not OUT.exists(), "Fresh immutable negative capsule directory required")
    require(sha((PACKET / "pair.json").read_bytes()) == "3135177c777cf2e6023630551f212e4781e851cf06529fa9f2e81cd8e1133818",
            "Original failed owner drift")
    require(sha((PROOFS / "negative-I.json").read_bytes()) == sha((PROOFS / "negative-IO.json").read_bytes())
            == "cd4dfac24375bc536df9d0eea4bd2e9679fa820a53621bdcc1b6227ede84a334", "Negative owner I/IO proof differs")
    require(sha((PEER / "output/wave5-v5-negative-originals-independent-I.json").read_bytes())
            == sha((PEER / "output/wave5-v5-negative-originals-independent-IO.json").read_bytes())
            == "4e7f20934c83ecaa4713882e5e04b4736f845c3ab43ef5b1a4c249409fe390c1", "Independent peer original closure differs")
    OUT.mkdir()
    builder_source = OWN / "output/wave5-evidence-capsules-20261012-v1/build_capsules.py"
    spec = importlib.util.spec_from_file_location("unchanged_flat_capsule_builder", builder_source)
    builder = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(builder)
    builder.OUT = OUT
    builder.CAPTURE_SOURCE = CURRENT
    selected, classification = [], []
    for path in sorted(PACKET.rglob("*")):
        if not path.is_file() or "__pycache__" in path.parts:
            continue
        relative = path.relative_to(PACKET).as_posix()
        require(path.suffix in (".json", ".log"), "Unexpected native input type")
        raw = path.read_bytes()
        # Finite original synthetic packet only. No secret scanner installation,
        # blanket allowance or source rewrite; no private setup logs selected.
        require(re.search(rb"postgres(?:ql)?://", raw, re.I) is None, "URI DSN is not public capsule input")
        require(b"-----BEGIN PRIVATE KEY-----" not in raw and b"-----BEGIN RSA PRIVATE KEY-----" not in raw,
                "Private key material refused")
        source = BASELINE if "baseline" in relative else CURRENT if "candidate" in relative else None
        selected.append((path, "original-v5/" + relative, source,
                         "Original terminal negative V5 bytes; B1/C1/C2 complete, B2 aborted/unaccepted, B3/C3 unperformed. Per-file source headers retained."))
        classification.append({"relative": relative, "bytes": len(raw), "sha256": sha(raw),
                               "uri_dsn_present": False, "private_setup_log": False,
                               "fixture_classification": "Owned synthetic cash/equity benchmark, safe numeric/system/source/ownership metadata; no real customer data."})
    for path in sorted((CONTROLS / "pair").rglob("*")):
        if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc":
            selected.append((path, "original-controls/pair/" + path.relative_to(CONTROLS / "pair").as_posix(), None,
                             "Original relocated readiness7b904/std-control/preflight/smoke bytes; no new launch or six-complete acceptance."))
    for name in ("launcher-bindings-development-v1.json", "relocation-development-v1.json", "prelaunch-load-power-v2.json"):
        selected.append((CONTROLS / name, "original-controls/" + name, None,
                         "Original quiet2 relocation/prelaunch source and power metadata retained; not new financial acceptance."))
    for path in sorted(PROOFS.iterdir()):
        if path.is_file():
            selected.append((path, "own-negative-proofs/" + path.name, None,
                             "Actual file-only negative I/IO closure plus original checker-assumption failure/source; not a native workload retry."))
    watches = OWN / "output/wave5-v5-sparse-custody"
    for path in sorted(watches.rglob("*")):
        if path.is_file():
            selected.append((path, "sparse-watch-originals/" + path.relative_to(watches).as_posix(), None,
                             "Earlier original owner captures/read-only completed-child checks; their actual running/failed headers retained without relabeling."))
    for name in ("audit_wave5_v5_negative.py", "watch_wave5_v5_completed.py", Path(__file__).name):
        selected.append((OWN / "output" / name, "own-read-only-tools/" + name, None,
                         "Executed negative/watch/capsule tool source; no six-complete auditor/replay executed or included."))
    for name in ("audit_wave5_v5_negative_originals.py", "wave5-v5-negative-originals-independent-I.json", "wave5-v5-negative-originals-independent-IO.json"):
        selected.append((PEER / "output" / name, "peer-negative-proof/" + name, None,
                         "Independently executed file-only original negative closure; normal/optimized outputs identical; no app/controller/DB/network imports/calls."))
    harness_path = Path(json.loads((CONTROLS / "pair/readiness-v4.json").read_bytes())["harness_path"])
    require(sha(harness_path.read_bytes()) == "7bce2382df24d439d39386f0e02c07bf362c4f451649dbd8d7f225c8a920396b", "Actual common native harness drift")
    selected.append((harness_path, "original-common-source/benchmark_enterprise_finance.py", CURRENT,
                     "Exact common final22 harness source; B/C runs use it unchanged. Literal source protocol/config strings are public Git source, not runtime credentials."))
    # Reference existing capsules, never embed/rewrite their archives again.
    references = []
    for directory, archive, expected in (
        (OWN / "output/wave5-quiet2-discovery-public-capsule-20261012-v1", "wave5-quiet2-discovery-636-22-fourprofiles-v1.zip",
         "3dc3b141f59b401366c80e42de425244bbc8f2af5779f65fdcacb7c60673ba16"),
        (OWN / "output/wave5-native10k-public-capsule-20261012-v1", "wave5-native10k-62-38252859442-v1.zip",
         "18f271117f6f88514ec4e73cc14ba0390dcf6653096b3d8cca24698e3f74cd9e"),
    ):
        path = directory / archive
        index = path.with_suffix(".index.json")
        require(sha(path.read_bytes()) == expected, "Earlier capsule changed")
        references.append({"file_name": archive, "bytes": path.stat().st_size, "sha256": expected,
                           "index_name": index.name, "index_sha256": sha(index.read_bytes()), "original_directory": str(directory)})
    reference_file = OUT / "prior-quiet2-native10k-reference-only.json"
    builder.save_json(reference_file, {"schema_version": "wave5-prior-immutable-capsule-reference-v1", "records": references,
                                     "prior_archives_embedded_again": False, "prior_capsules_modified": False,
                                     "prior_c4_scope": "Existing c4 acceptance capsule/docs were not touched or rebound by this negative capture."})
    selected.append((reference_file, "reference-only/prior-quiet2-native10k.json", None, "Existing archives referenced by exact trusted bytes/hashes only."))
    privacy = OUT / "finite-runtime-input-classification.json"
    builder.save_json(privacy, {"schema_version": "wave5-v5-finite-synthetic-runtime-privacy-v1", "records": classification,
                               "partial_exception_sha256": "2869d101a5eca762c3817a677791ab277c977234ae61a6eb9e804b74cc3afe7a",
                               "partial_exception_content": "Known synthetic owned loopback connection repr includes localhost/user/port/database; no password/authentication material or URI DSN. Original bytes retained unchanged.",
                               "no_source_or_scanner_allowance_added": True, "private_setup_logs_selected": False})
    selected.append((privacy, "finite-runtime-input-classification.json", None, "Closed finite synthetic input classification; no global policy/scanner changes."))
    coverage = {"owner_original_sha256": "3135177c777cf2e6023630551f212e4781e851cf06529fa9f2e81cd8e1133818",
                "owner_status": "failed", "primary_failure": "Observed AC/saver-off required",
                "power_breach_at": "2026-10-12T15:32:48.230589+00:00", "raw_ac": 0, "battery_percent": 98,
                "saver_on": False, "completed_positive_children": ["1-baseline", "1-candidate", "2-candidate"],
                "completed_positive_measured_cycles": 3000, "completed_positive_separate_warmups": 60,
                "completed_positive_verified_read_requests": 9999, "independent_minor_per_complete_child": "493671004",
                "aborted_child": "2-baseline", "aborted_raw_sha256": "2869d101a5eca762c3817a677791ab277c977234ae61a6eb9e804b74cc3afe7a",
                "aborted_reported_posting_completed": 1000, "aborted_reported_posting_errors": 0,
                "aborted_successful_request_duration_entries": 2489, "aborted_retained_effect_visits": 4766,
                "aborted_last_read_sample_status": "running166effects", "aborted_failed_request_markers": 0,
                "aborted_source_after_present": False, "aborted_secondary_exception": "OutOfOrderTransactionNesting",
                "aborted_complete_financial_acceptance": False, "secondary_error_cause_proven": False,
                "unperformed_children": ["3-baseline", "3-candidate"], "four_exact_owned_cleanup_closures": True,
                "aborted_process_cleanup": "gracefully_stopped_without_force", "all_four_acknowledged_CIDs": "verified_absent",
                "baseline_source": BASELINE, "accepted_candidate_source": CURRENT,
                "current_candidate_physical_source_sha256": "dfdf4296eb27e088ae91790af2d2d280880fb70e4edb151e50f2b9f2940a4535",
                "historical_cf9_populations_combined": False, "readiness_sha256": "7b904ff39d3db18634b581e83dde73d928d1e9d8783466749f9e42e3fbff33ca",
                "normal_optimized_negative_pairs": 2, "complete_six_run_population": False,
                "six_complete_comparator_or_replay_executed": False, "comparative_medians_computed": False,
                "performance_comparison_accepted": False, "RPO_RTO_claimed": False,
                "workload_retry": False, "partial_raw_or_prior_capsules_rewritten": False}
    result = builder.capsule("wave5-v5-paired1k-636-22-power-stop-negative-v1.zip", selected, coverage)
    extension = OUT / "capsule-index-extension-v5-power-negative-20261012-v1.json"
    builder.save_json(extension, {"schema_version": "reconforge-flat-evidence-capsule-extension-v1", "capsules": [result],
                                 "prior_capsule_references": references, "terminal_negative_subject": True,
                                 "source_subjects_rebound": False, "performance_comparison_accepted": False})
    print(json.dumps({"directory": str(OUT), "capsule": result, "extension_index": extension.name,
                      "extension_index_sha256": sha(extension.read_bytes())}, indent=2))


if __name__ == "__main__":
    main()
