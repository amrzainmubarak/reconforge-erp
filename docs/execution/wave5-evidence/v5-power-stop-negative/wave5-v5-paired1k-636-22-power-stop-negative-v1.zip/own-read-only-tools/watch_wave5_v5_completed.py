"""Sparse file-only snapshot of owner state and COMPLETED V5 children.

No live child/result reads, app imports, database, Docker, network or source scan.
Partial owner snapshots are diagnostic custody records, never six-run acceptance.
"""
from __future__ import annotations

import argparse
from datetime import UTC, datetime
import hashlib
import json
from pathlib import Path
import re
import types


READY_PIN = "7b904ff39d3db18634b581e83dde73d928d1e9d8783466749f9e42e3fbff33ca"
ORDER = [(1, "baseline"), (1, "candidate"), (2, "candidate"), (2, "baseline"), (3, "baseline"), (3, "candidate")]
OLD_CANDIDATE = "cf9a1280d9a3138ca6e908708fd393ec75268fa198140c070098aa3056723652"


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON member")
        result[key] = value
    return result


def decode(raw):
    return json.loads(raw, object_pairs_hook=unique,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Nonfinite JSON")))


def watch(packet, controls, destination):
    raw = (packet / "pair.json").read_bytes()
    state = decode(raw)
    ready_raw = (controls / "readiness-v4.json").read_bytes()
    require(sha(ready_raw) == READY_PIN, "New relocated readiness differs")
    ready = decode(ready_raw)
    require(state["commits"] == ready["commits"] and state["count"] == 1000 and state["pairs"] == 3,
            "Owner six-run subject differs")
    require(len(state["runs"]) <= 6 and [(row["repetition"], row["variant"]) for row in state["runs"]] == ORDER[:len(state["runs"])],
            "Unexpected owner ordering")
    name = "original-verifiers/verify_native_posting_pair.py"
    verifier_raw = (controls / name).read_bytes()
    require(sha(verifier_raw) == ready["tool_sha256"][name] == "b09575672dd79997e42afb1ade898a6e7b2448af3674ec5fc746f0120c167e58",
            "Original stdlib oracle source differs")
    verifier = types.ModuleType("retained_file_only_financial_oracle")
    verifier.__file__ = str(controls / name)
    # Execute exactly the same captured bytes whose SHA was checked. The known
    # immutable module imports only stdlib and its CLI guard is not entered.
    exec(compile(verifier_raw, verifier.__file__, "exec"), verifier.__dict__)
    inputs = [{"path": str(packet / "pair.json"), "bytes": len(raw), "sha256": sha(raw)},
              {"path": str(controls / "readiness-v4.json"), "bytes": len(ready_raw), "sha256": READY_PIN},
              {"path": str(controls / name), "bytes": len(verifier_raw), "sha256": sha(verifier_raw)}]

    def referenced(relative, expected=None):
        require(type(relative) is str and relative and ":" not in relative and "\\" not in relative
                and ".." not in Path(relative).parts, "Unsafe original reference")
        path = (packet / relative).resolve()
        require(path.is_relative_to(packet.resolve()), "Original reference escapes")
        value = path.read_bytes()
        if expected is not None:
            require(sha(value) == expected, "Completed original raw SHA differs")
        inputs.append({"path": str(path), "bytes": len(value), "sha256": sha(value)})
        return decode(value)

    completed = []
    for row in state["runs"]:
        if row.get("financial_verification") != "passed" or "report_sha256" not in row:
            continue
        variant, repetition = row["variant"], row["repetition"]
        label = f"{repetition}-{variant}"
        require(row["child_exit_code"] == 0, "Completed child failed")
        native = referenced(row["report"], row["report_sha256"])
        financial = verifier.validate_measurement(native, ready["commits"][variant])
        require(native["source_sha256"] == native["source_sha256_after"] == ready["sources"][variant]["tracked_sha256"]
                and native["harness_sha256"] == native["harness_sha256_after"] == ready["harness_sha256"], "Native source differs")
        require(native["revision"] == ("0132_pg_stock_inverse_dispatch" if variant == "baseline" else "0136_pg_inventory_scope")
                and native["image"] == ready["image"] and native["postgres_version"].startswith("17.11"), "Native database subject differs")
        require(native["command"] == row["reported_harness_command"]
                and Path(native["runtime_root"]).resolve() == Path(ready["sources"][variant]["runtime_root"]).resolve(), "Actual command/root differs")
        warm = native["posting_warmup"]
        require(warm["completed_cycles"] == 20 and warm["indices"] == list(range(1000, 1020))
                and warm["outside_measured_population"] is True
                and len(warm["effect_ids"]) == len(set(warm["effect_ids"])) == 20
                and not set(warm["effect_ids"]) & set(native["posting"]["ordered_effect_ids"]), "Warm population differs")
        process, cleanup = row["process"], row["cleanup"]
        owned = referenced(label + "-ownership.json", cleanup["ownership_audit_sha256"])
        created = referenced(label + "-ownership.created.json", cleanup["creation_response_sha256"])
        crosscheck = referenced(label + "-ownership.audit-crosscheck.json", cleanup["native_audit_crosscheck_sha256"])
        admission = referenced(label + "-admission.json")
        origins = referenced(row["origins"]["path"], row["origins"]["sha256"])
        require(owned["process"] == created["process"] == crosscheck["process"] == admission["process"] == origins["process"] == process
                and admission["owned_job_assigned"] is True, "Process/Job origin differs")
        require(type(process["pid"]) is int and type(process["birth"]) is int and process["pid"] > 0 and process["birth"] > 0,
                "Untyped process identity")
        cid = cleanup["container_id"]
        require(re.fullmatch(r"[0-9a-f]{64}", cid) is not None and cid == created["container_id"] == cleanup["bound_inspection"]["Id"]
                and created["returncode"] == 0 and created["audit_sha256"] == cleanup["ownership_audit_sha256"], "Immutable creation CID differs")
        require(owned["pre_spawn_exact_name_absent"] is True and owned["image"] == cleanup["bound_inspection"]["Config"]["Image"] == ready["image"]
                and cleanup["bound_inspection"]["Name"] == "/" + owned["name"], "Acknowledged creation configuration differs")
        require(crosscheck["status"] == "matched" and crosscheck["audit_argument_form"] == "str"
                and crosscheck["original_typed_command_sha256"] == owned["command_sha256"], "Native Windows audit differs")
        require(row["process_cleanup"]["status"] == "already_exited" and row["process_cleanup"]["forced"] is False
                and row["process_cleanup"]["identity"] == process and cleanup["status"] == "verified_absent"
                and cleanup["action"] == "already_absent", "Normal cleanup differs")
        require(origins["status"] == "passed" and origins["foreign_modules"] == []
                and origins["harness_sha256_after"] == ready["harness_sha256"]
                and all(Path(origin["path"]).resolve().is_relative_to(Path(native["runtime_root"]).resolve()) for origin in origins["origins"]),
                "Foreign runtime module origin")
        completed.append({"run": label, "variant": variant, "native_raw_sha256": row["report_sha256"],
                          "source_commit": native["source_commit"], "source_sha256": native["source_sha256"],
                          "full_container_id": cid, "process": process, "financial": financial,
                          "warmup_disjoint_cycles": 20, "normal_process_and_container_cleanup": True})
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%S%fZ")
    require(not destination.exists(), "Fresh watch capture directory required")
    destination.mkdir(parents=True)
    snapshot = destination / ("owner-original-" + stamp + ".json")
    snapshot.write_bytes(raw)
    report = {"schema_version": "wave5-v5-completed-child-file-watch-v1", "status": "passed",
              "captured_at": stamp, "owner_status": state["status"], "original_owner_sha256": sha(raw),
              "original_owner_snapshot": str(snapshot), "completed_children": completed,
              "admitted_child_records": len(state["runs"]), "live_or_partial_children_read": False,
              "new_candidate_source_sha256": ready["sources"]["candidate"]["tracked_sha256"],
              "historical_v4_candidate_source_sha256": OLD_CANDIDATE,
              "historical_and_new_full_source_fingerprints_equal": False,
              "same_accepted_candidate_commit": ready["commits"]["candidate"],
              "original_file_index": inputs, "application_database_network_calls": False,
              "performance_comparison_accepted": False,
              "limits": ["Sparse owner snapshot plus completed child custody only; not complete six-run comparison.",
                         "Full source fingerprints retained from original readiness/reports; no live full-source recomputation.",
                         "Do not combine priorCF9 populations with newDFDF populations or four-profile diagnostics."]}
    target = destination / "completed-custody-review.json"
    output = (json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()
    target.write_bytes(output)
    print(json.dumps({"status": "passed", "owner_status": state["status"], "completed_children": [row["run"] for row in completed],
                      "output": str(target), "sha256": sha(output), "performance_comparison_accepted": False}))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--packet", required=True, type=Path)
    parser.add_argument("--controls", required=True, type=Path)
    parser.add_argument("--output-directory", required=True, type=Path)
    args = parser.parse_args()
    watch(args.packet.resolve(), args.controls.resolve(), args.output_directory.resolve())


if __name__ == "__main__":
    main()
