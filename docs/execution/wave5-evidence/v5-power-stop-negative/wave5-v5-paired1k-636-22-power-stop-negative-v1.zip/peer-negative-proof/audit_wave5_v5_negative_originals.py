"""Independent file-only audit of the FAILED V5 original packet; no replay."""
import hashlib
import json
import math
import re
import sys
from datetime import datetime
from pathlib import Path

OWN = Path(__file__).resolve().parent
ROOT = Path(r"C:\Users\LOQ\.codex\worktrees\reconforge-integration-wave5\reconforge-erp")
PACKET = ROOT / "output/wave5-quiet2-final22-paired1k-v5-20261012"
CONTROLS = ROOT / "output/wave5-quiet2-discovery-20261012/pair"
PAIR_SHA = "3135177c777cf2e6023630551f212e4781e851cf06529fa9f2e81cd8e1133818"
READY_SHA = "7b904ff39d3db18634b581e83dde73d928d1e9d8783466749f9e42e3fbff33ca"
HARNESSSHA = "7bce2382df24d439d39386f0e02c07bf362c4f451649dbd8d7f225c8a920396b"
COMMITS = {"baseline": "6362724f2337a79c3d7569574f7bf9591a018524", "candidate": "22ebfd78e293aafa13d81b3a0bbf287491951115"}
SOURCE = {"baseline": "65911f44fdf66fe5100225a8538934a89c8788a15342fc2fb64a1a9b5b32f6c8", "candidate": "dfdf4296eb27e088ae91790af2d2d280880fb70e4edb151e50f2b9f2940a4535"}
INDEX = {}


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def pairs(values):
    result = {}
    for key, value in values:
        need(key not in result, "Duplicate JSON member")
        result[key] = value
    return result


def read(path, expected=None):
    raw = path.read_bytes()
    need(expected is None or sha(raw) == expected, "Original hash differs: " + str(path))
    INDEX[str(path)] = {"sha256": sha(raw), "bytes": len(raw)}
    value = json.loads(raw, object_pairs_hook=pairs,
                       parse_constant=lambda _: need(False, "Nonfinite JSON"))
    need(type(value) is dict, "Expected object")
    return value


def referenced(relative, expected=None):
    need(relative and ".." not in Path(relative).parts and ":" not in relative and "\\" not in relative, "Unsafe raw reference")
    path = (PACKET / relative).resolve()
    need(path.is_relative_to(PACKET), "Raw reference escaped packet")
    return read(path, expected)


def minor(count):
    return str(sum(1 + int.from_bytes(hashlib.sha256(f"enterprise-native-v1:{i}".encode()).digest()[:8], "big") % 1_000_000 for i in range(count)))


def quantiles(values):
    need(values and all(type(value) in (int, float) and math.isfinite(value) and value > 0 for value in values), "Bad raw latency")
    ordered = sorted(values)
    return {key: ordered[math.ceil(len(ordered) * fraction) - 1] for key, fraction in (("p50", .5), ("p95", .95), ("p99", .99))}


def custody(record, normal):
    label = f"{record['repetition']}-{record['variant']}"
    cleanup = record["cleanup"]
    cid = cleanup["container_id"]
    need(re.fullmatch(r"[0-9a-f]{64}", cid) and cleanup["status"] == "verified_absent", "Exact cleanup not proven")
    owned = referenced(label + "-ownership.json", cleanup["ownership_audit_sha256"])
    created = referenced(label + "-ownership.created.json", cleanup["creation_response_sha256"])
    audited = referenced(label + "-ownership.audit-crosscheck.json", cleanup["native_audit_crosscheck_sha256"])
    admitted = referenced(label + "-admission.json")
    need(owned["process"] == created["process"] == audited["process"] == admitted["process"] == record["process"], "PID/birth binding differs")
    need(admitted["owned_job_assigned"] is True and created["returncode"] == 0 and created["container_id"] == cid, "Acknowledged CID/Job admission differs")
    need(created["audit_sha256"] == cleanup["ownership_audit_sha256"] and owned["pre_spawn_exact_name_absent"] is True, "Pre-spawn ownership differs")
    need(audited["status"] == "matched" and audited["audit_argument_form"] == "str"
         and audited["original_typed_command_sha256"] == owned["command_sha256"], "Original typed Docker audit differs")
    need(cleanup["bound_inspection"]["Id"] == cid and cleanup["bound_inspection"]["Config"]["Image"] == owned["image"], "Immutable container image differs")
    process_cleanup = record["process_cleanup"]
    need(process_cleanup["identity"] == record["process"] and process_cleanup["forced"] is False,
         "Original process stop custody differs")
    need(process_cleanup["status"] == ("already_exited" if normal else "gracefully_stopped"), "Stop classification differs")
    return {"run": label, "container_id": cid, "process": record["process"], "container_cleanup": cleanup["status"], "process_cleanup": process_cleanup["status"], "forced": False}


pair = referenced("pair.json", PAIR_SHA)
need(pair["status"] == "failed" and pair["commits"] == COMMITS and pair["performance_comparison_accepted"] is False,
     "Original failed-population subject differs")
need(pair["financial_verification"] == pair["observed_environment_verification"] == "not_accepted_complete_population"
     and pair["cost_per_success_currency"] is None, "Incomplete population was accepted")
need(pair["failure_type"] == "ValueError" and pair["failure"] == "Observed AC/saver-off required", "Power failure classification differs")
order = [(1, "baseline"), (1, "candidate"), (2, "candidate"), (2, "baseline")]
need([(row["repetition"], row["variant"]) for row in pair["runs"]] == order, "Incomplete chronological order differs")
ready = read(CONTROLS / "readiness-v4.json", READY_SHA)
for relative, expected in ready["tool_sha256"].items():
    raw = (CONTROLS / relative).read_bytes()
    need(sha(raw) == expected, "Retained control source differs")
    INDEX[str(CONTROLS / relative)] = {"sha256": sha(raw), "bytes": len(raw)}
complete, owners, all_effects, all_requests, previous_end = [], [], set(), 0, None
for record in pair["runs"][:3]:
    variant = record["variant"]
    label = f"{record['repetition']}-{variant}"
    report = referenced(record["report"], record["report_sha256"])
    need(report["status"] == "passed" and record["child_exit_code"] == 0 and record["financial_verification"] == "passed", "Completed run admission differs")
    need(report["source_commit"] == report["source_commit_after"] == COMMITS[variant]
         and report["source_sha256"] == report["source_sha256_after"] == SOURCE[variant]
         and report["source_unchanged"] is True, "Completed source closure differs")
    need(report["harness_sha256"] == report["harness_sha256_after"] == HARNESSSHA and report["owned_container_removed"] is True, "Completed harness/cleanup differs")
    need(report["revision"] == ("0132_pg_stock_inverse_dispatch" if variant == "baseline" else "0136_pg_inventory_scope"), "Migration identity differs")
    start, end = [datetime.fromisoformat(report[key]) for key in ("started_at", "finished_at")]
    need(start.tzinfo and end.tzinfo and start < end and (previous_end is None or previous_end <= start), "Original populations overlap")
    previous_end = end
    posting, warm = report["posting"], report["posting_warmup"]
    need(posting["completed_indices"] == list(range(1000)) and posting["completed_cycles"] == posting["requested_cycles"] == posting["admitted_cycles"] == 1000,
         "Incomplete posting indices")
    need(posting["error_count"] == posting["not_admitted_cycles"] == 0 and posting["failed_cycles"] == [], "Completed posting failure")
    need(posting["expected"] == dict.fromkeys(("debit_minor", "credit_minor", "cash_minor", "equity_minor"), minor(1000)), "Independent integer total differs")
    need(warm["completed_cycles"] == 20 and warm["indices"] == list(range(1000, 1020)) and warm["outside_measured_population"] is True, "Disjoint warmup differs")
    effects = posting["ordered_effect_ids"] + warm["effect_ids"]
    need(len(effects) == len(set(effects)) == 1020 and not set(effects) & all_effects, "Repeated/lost source effects")
    all_effects.update(effects)
    need(len(posting["raw_cycle_latency_seconds"]) == 1000 and quantiles(posting["raw_cycle_latency_seconds"]) == posting["cycle_latency_seconds"], "Raw posting latencies differ")
    requests = 0
    for profile in report["verified_reads"]:
        count = profile["count"]
        need(count in (100, 1000) and profile["status"] == "passed"
             and profile["expected"] == dict.fromkeys(posting["expected"], minor(count)), "Read-prefix arithmetic differs")
        raw_prefix = json.dumps(posting["ordered_effect_ids"][:count], ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
        need(sha(raw_prefix) == profile["dataset_effect_ids_sha256"], "Original prefix membership differs")
        for mode, samples in profile["samples"].items():
            need([row["repetition"] for row in samples] == [0, 1, 2], "Missing complete read repeat")
            for sample in samples:
                need(sample["status"] == "complete" and sample["error_count"] == 0 and sample["effects"] == sample["requested_effects"] == count,
                     "Incomplete native read")
                need(sample["debit_minor"] == sample["credit_minor"] == minor(count)
                     and sample["effects_digest"] == profile["financial_effects_digest"], "Read financial digest differs")
                raw = sample["raw_request_latency_seconds"]
                need(len(raw) == (count if mode == "per_effect_baseline" else count // 100)
                     and quantiles(raw) == sample["request_latency_seconds"], "Raw native read request population differs")
                requests += len(raw)
    need(requests == 3333, "Complete native reads missing")
    all_requests += requests
    origins = referenced(record["origins"]["path"], record["origins"]["sha256"])
    need(origins["status"] == "passed" and origins["foreign_modules"] == [] and origins["process"] == record["process"], "Original loaded-source custody differs")
    owners.append(custody(record, True))
    complete.append({"run": label, "raw_report_sha256": record["report_sha256"], "measured_cycles": 1000,
                     "outside_measured_warmups": 20, "verified_read_requests": requests,
                     "independent_total_minor": minor(1000), "prefix100_minor": minor(100),
                     "financial_verification": "passed_original_per_run_only", "six_run_acceptance": False})
aborted = pair["runs"][3]
abort_report = referenced(aborted["report"], aborted["retained_raw_report_sha256"])
need(abort_report["status"] == "failed" and aborted["child_exit_code"] is None, "Interrupted run relabeled")
need(abort_report["posting"]["completed_cycles"] == 1000 and abort_report["posting"]["error_count"] == 0
     and abort_report["posting"]["completed_indices"] == list(range(1000)), "Reported interrupted posting stage differs")
need("OutOfOrderTransactionNesting" in abort_report["failure"] and abort_report["owned_container_removed"] is True,
     "Secondary interrupted error/cleanup not retained")
need([row["status"] for row in abort_report["verified_reads"]] == ["passed", "failed"], "Interrupted read boundary differs")
owners.append(custody(aborted, False))
failed_observation = aborted["host_load_observations"][-1]
power = failed_observation["power"]
need(failed_observation["observed_at"] == "2026-10-12T15:32:48.230589+00:00"
     and power["raw"]["ac"] == 0 and power["ac_online"] is False and power["raw"]["saver"] == 0
     and power["battery_saver_on"] is False, "Original AC gate failure not proven")
after_failure = referenced(aborted["environment_after_failure"]["path"], aborted["environment_after_failure"]["sha256"])
need(after_failure["power"]["ac_online"] is False, "Failure-side power field differs")
need(len({row["container_id"] for row in owners}) == 4 and len(all_effects) == 3060 and all_requests == 9999, "Negative complete subset or custody counts differ")
report = {"schema_version": "wave5-v5-negative-original-independent-file-review-v1", "status": "negative_evidence_verified",
          "original_owner_status": "failed", "original_pair_sha256": PAIR_SHA, "commits": COMMITS,
          "tracked_source_fingerprints": SOURCE, "readiness_sha256": READY_SHA,
          "completed_original_populations": complete,
          "complete_subset_counts": {"measured_cycles": 3000, "warmups": 60, "fresh_effects": 3060, "verified_native_read_requests": 9999},
          "interrupted_population": {"run": "2-baseline", "raw_report_sha256": aborted["retained_raw_report_sha256"],
              "status": "failed_not_accepted", "reported_posting_stage_cycles": 1000, "reported_posting_stage_errors": 0,
              "full_read_and_final_source_admission": False, "secondary_error_class": "OutOfOrderTransactionNesting",
              "zero_business_effects_claim": False, "complete_run_financial_acceptance": False},
          "unperformed_planned_populations": ["3-baseline", "3-candidate"], "original_failure_observation": failed_observation,
          "actual_owned_lifecycles": owners, "performance_comparison_accepted": False, "cost_per_success_currency": None,
          "six_complete_auditor_or_replay_executed": False,
          "limits": ["Only three complete raw per-run financial subsets are verified; the planned six-run population failed its AC gate.",
                     "Interrupted B2 reports1000 posting-stage cycles and partial reads but its failed raw report is not a fourth accepted financial/run population.",
                     "Secondary shutdown transaction error is retained; this review does not establish an independent kernel defect or new recovery guarantee.",
                     "No three-pair medians, fair performance claim, pooled latency, new resource gain or monetary cost is calculated.",
                     "Original source fingerprints and loaded-module evidence are checked; no live full-checkout scan or physical power attestation is performed.",
                     "Stdlib original-file-only audit; no application/controller imports, tests, workloads, network, DB, Docker or live observations."],
          "original_file_index": [{"path": path, **value} for path, value in sorted(INDEX.items())],
          "script_sha256": sha(Path(__file__).read_bytes())}
output = Path(sys.argv[1]).resolve()
need(output.parent == OWN and not output.exists(), "Fresh owned review output required")
raw = (json.dumps(report, indent=2, ensure_ascii=True, allow_nan=False) + "\n").encode()
with output.open("xb") as handle:
    handle.write(raw)
print(json.dumps({"status": report["status"], "output": str(output), "sha256": sha(raw), "script_sha256": report["script_sha256"]}))
